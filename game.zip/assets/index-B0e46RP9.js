var Ag=Object.defineProperty;var Tg=(n,e,t)=>e in n?Ag(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var ke=(n,e,t)=>Tg(n,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Ru="170",wg=0,Sf=1,Rg=2,Cu=1,Cg=2,si=3,Kn=0,sn=1,gn=2,ki=0,Qr=1,yf=2,Mf=3,Ef=4,Pg=5,rr=100,Ig=101,Lg=102,Dg=103,Ng=104,Ug=200,Og=201,Fg=202,kg=203,Ac=204,Tc=205,Bg=206,zg=207,Hg=208,Vg=209,Gg=210,Wg=211,Xg=212,qg=213,Yg=214,wc=0,Rc=1,Cc=2,us=3,Pc=4,Ic=5,Lc=6,Dc=7,Pu=0,Kg=1,Zg=2,Bi=0,$g=1,jg=2,Jg=3,Qg=4,e_=5,t_=6,n_=7,cp=300,fs=301,ds=302,Nc=303,Uc=304,$a=306,ho=1e3,ar=1001,Oc=1002,zt=1003,i_=1004,Co=1005,zn=1006,gl=1007,lr=1008,mi=1009,up=1010,fp=1011,po=1012,Iu=1013,fr=1014,Hn=1015,So=1016,Lu=1017,Du=1018,hs=1020,dp=35902,hp=1021,pp=1022,Ln=1023,mp=1024,gp=1025,es=1026,ps=1027,Nu=1028,Uu=1029,_p=1030,Ou=1031,Fu=1033,xa=33776,Sa=33777,ya=33778,Ma=33779,Fc=35840,kc=35841,Bc=35842,zc=35843,Hc=36196,Vc=37492,Gc=37496,Wc=37808,Xc=37809,qc=37810,Yc=37811,Kc=37812,Zc=37813,$c=37814,jc=37815,Jc=37816,Qc=37817,eu=37818,tu=37819,nu=37820,iu=37821,Ea=36492,ru=36494,su=36495,vp=36283,ou=36284,au=36285,lu=36286,r_=3200,s_=3201,xp=0,o_=1,Di="",jt="srgb",As="srgb-linear",ja="linear",gt="srgb",Ar=7680,bf=519,a_=512,l_=513,c_=514,Sp=515,u_=516,f_=517,d_=518,h_=519,cu=35044,Af=35048,Tf="300 es",ai=2e3,Ca=2001;class Ts{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,o=r.length;s<o;s++)r[s].call(this,e);e.target=null}}}const Kt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],_l=Math.PI/180,uu=180/Math.PI;function zi(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Kt[n&255]+Kt[n>>8&255]+Kt[n>>16&255]+Kt[n>>24&255]+"-"+Kt[e&255]+Kt[e>>8&255]+"-"+Kt[e>>16&15|64]+Kt[e>>24&255]+"-"+Kt[t&63|128]+Kt[t>>8&255]+"-"+Kt[t>>16&255]+Kt[t>>24&255]+Kt[i&255]+Kt[i>>8&255]+Kt[i>>16&255]+Kt[i>>24&255]).toLowerCase()}function an(n,e,t){return Math.max(e,Math.min(t,n))}function p_(n,e){return(n%e+e)%e}function vl(n,e,t){return(1-t)*n+t*e}function Bn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function vt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}class nt{constructor(e=0,t=0){nt.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(an(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*i-o*r+e.x,this.y=s*r+o*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class We{constructor(e,t,i,r,s,o,a,l,c){We.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,o,a,l,c)}set(e,t,i,r,s,o,a,l,c){const u=this.elements;return u[0]=e,u[1]=r,u[2]=a,u[3]=t,u[4]=s,u[5]=l,u[6]=i,u[7]=o,u[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,o=i[0],a=i[3],l=i[6],c=i[1],u=i[4],d=i[7],f=i[2],h=i[5],g=i[8],_=r[0],m=r[3],p=r[6],E=r[1],S=r[4],y=r[7],C=r[2],R=r[5],A=r[8];return s[0]=o*_+a*E+l*C,s[3]=o*m+a*S+l*R,s[6]=o*p+a*y+l*A,s[1]=c*_+u*E+d*C,s[4]=c*m+u*S+d*R,s[7]=c*p+u*y+d*A,s[2]=f*_+h*E+g*C,s[5]=f*m+h*S+g*R,s[8]=f*p+h*y+g*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],u=e[8];return t*o*u-t*a*c-i*s*u+i*a*l+r*s*c-r*o*l}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],u=e[8],d=u*o-a*c,f=a*l-u*s,h=c*s-o*l,g=t*d+i*f+r*h;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return e[0]=d*_,e[1]=(r*c-u*i)*_,e[2]=(a*i-r*o)*_,e[3]=f*_,e[4]=(u*t-r*l)*_,e[5]=(r*s-a*t)*_,e[6]=h*_,e[7]=(i*l-c*t)*_,e[8]=(o*t-i*s)*_,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,o,a){const l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*o+c*a)+o+e,-r*c,r*l,-r*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(xl.makeScale(e,t)),this}rotate(e){return this.premultiply(xl.makeRotation(-e)),this}translate(e,t){return this.premultiply(xl.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const xl=new We;function yp(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function Pa(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function m_(){const n=Pa("canvas");return n.style.display="block",n}const wf={};function Js(n){n in wf||(wf[n]=!0,console.warn(n))}function g_(n,e,t){return new Promise(function(i,r){function s(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:r();break;case n.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:i()}}setTimeout(s,t)})}function __(n){const e=n.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function v_(n){const e=n.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const at={enabled:!0,workingColorSpace:As,spaces:{},convert:function(n,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===gt&&(n.r=ci(n.r),n.g=ci(n.g),n.b=ci(n.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(n.applyMatrix3(this.spaces[e].toXYZ),n.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===gt&&(n.r=ts(n.r),n.g=ts(n.g),n.b=ts(n.b))),n},fromWorkingColorSpace:function(n,e){return this.convert(n,this.workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this.workingColorSpace)},getPrimaries:function(n){return this.spaces[n].primaries},getTransfer:function(n){return n===Di?ja:this.spaces[n].transfer},getLuminanceCoefficients:function(n,e=this.workingColorSpace){return n.fromArray(this.spaces[e].luminanceCoefficients)},define:function(n){Object.assign(this.spaces,n)},_getMatrix:function(n,e,t){return n.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(n){return this.spaces[n].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(n=this.workingColorSpace){return this.spaces[n].workingColorSpaceConfig.unpackColorSpace}};function ci(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function ts(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}const Rf=[.64,.33,.3,.6,.15,.06],Cf=[.2126,.7152,.0722],Pf=[.3127,.329],If=new We().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Lf=new We().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);at.define({[As]:{primaries:Rf,whitePoint:Pf,transfer:ja,toXYZ:If,fromXYZ:Lf,luminanceCoefficients:Cf,workingColorSpaceConfig:{unpackColorSpace:jt},outputColorSpaceConfig:{drawingBufferColorSpace:jt}},[jt]:{primaries:Rf,whitePoint:Pf,transfer:gt,toXYZ:If,fromXYZ:Lf,luminanceCoefficients:Cf,outputColorSpaceConfig:{drawingBufferColorSpace:jt}}});let Tr;class x_{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Tr===void 0&&(Tr=Pa("canvas")),Tr.width=e.width,Tr.height=e.height;const i=Tr.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=Tr}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Pa("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let o=0;o<s.length;o++)s[o]=ci(s[o]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(ci(t[i]/255)*255):t[i]=ci(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let S_=0;class Mp{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:S_++}),this.uuid=zi(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let o=0,a=r.length;o<a;o++)r[o].isDataTexture?s.push(Sl(r[o].image)):s.push(Sl(r[o]))}else s=Sl(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function Sl(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?x_.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let y_=0;class Qt extends Ts{constructor(e=Qt.DEFAULT_IMAGE,t=Qt.DEFAULT_MAPPING,i=ar,r=ar,s=zn,o=lr,a=Ln,l=mi,c=Qt.DEFAULT_ANISOTROPY,u=Di){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:y_++}),this.uuid=zi(),this.name="",this.source=new Mp(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new nt(0,0),this.repeat=new nt(1,1),this.center=new nt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new We,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==cp)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ho:e.x=e.x-Math.floor(e.x);break;case ar:e.x=e.x<0?0:1;break;case Oc:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case ho:e.y=e.y-Math.floor(e.y);break;case ar:e.y=e.y<0?0:1;break;case Oc:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Qt.DEFAULT_IMAGE=null;Qt.DEFAULT_MAPPING=cp;Qt.DEFAULT_ANISOTROPY=1;class Ut{constructor(e=0,t=0,i=0,r=1){Ut.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*i+o[8]*r+o[12]*s,this.y=o[1]*t+o[5]*i+o[9]*r+o[13]*s,this.z=o[2]*t+o[6]*i+o[10]*r+o[14]*s,this.w=o[3]*t+o[7]*i+o[11]*r+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const l=e.elements,c=l[0],u=l[4],d=l[8],f=l[1],h=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(u-f)<.01&&Math.abs(d-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(u+f)<.1&&Math.abs(d+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+h+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const S=(c+1)/2,y=(h+1)/2,C=(p+1)/2,R=(u+f)/4,A=(d+_)/4,P=(g+m)/4;return S>y&&S>C?S<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(S),r=R/i,s=A/i):y>C?y<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(y),i=R/r,s=P/r):C<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(C),i=A/s,r=P/s),this.set(i,r,s,t),this}let E=Math.sqrt((m-g)*(m-g)+(d-_)*(d-_)+(f-u)*(f-u));return Math.abs(E)<.001&&(E=1),this.x=(m-g)/E,this.y=(d-_)/E,this.z=(f-u)/E,this.w=Math.acos((c+h+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class M_ extends Ts{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new Ut(0,0,e,t),this.scissorTest=!1,this.viewport=new Ut(0,0,e,t);const r={width:e,height:t,depth:1};i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:zn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},i);const s=new Qt(r,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace);s.flipY=!1,s.generateMipmaps=i.generateMipmaps,s.internalFormat=i.internalFormat,this.textures=[];const o=i.count;for(let a=0;a<o;a++)this.textures[a]=s.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=i;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,r=e.textures.length;i<r;i++)this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new Mp(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class dr extends M_{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class ku extends Qt{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=zt,this.minFilter=zt,this.wrapR=ar,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class E_ extends Qt{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=zt,this.minFilter=zt,this.wrapR=ar,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class yo{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,o,a){let l=i[r+0],c=i[r+1],u=i[r+2],d=i[r+3];const f=s[o+0],h=s[o+1],g=s[o+2],_=s[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=u,e[t+3]=d;return}if(a===1){e[t+0]=f,e[t+1]=h,e[t+2]=g,e[t+3]=_;return}if(d!==_||l!==f||c!==h||u!==g){let m=1-a;const p=l*f+c*h+u*g+d*_,E=p>=0?1:-1,S=1-p*p;if(S>Number.EPSILON){const C=Math.sqrt(S),R=Math.atan2(C,p*E);m=Math.sin(m*R)/C,a=Math.sin(a*R)/C}const y=a*E;if(l=l*m+f*y,c=c*m+h*y,u=u*m+g*y,d=d*m+_*y,m===1-a){const C=1/Math.sqrt(l*l+c*c+u*u+d*d);l*=C,c*=C,u*=C,d*=C}}e[t]=l,e[t+1]=c,e[t+2]=u,e[t+3]=d}static multiplyQuaternionsFlat(e,t,i,r,s,o){const a=i[r],l=i[r+1],c=i[r+2],u=i[r+3],d=s[o],f=s[o+1],h=s[o+2],g=s[o+3];return e[t]=a*g+u*d+l*h-c*f,e[t+1]=l*g+u*f+c*d-a*h,e[t+2]=c*g+u*h+a*f-l*d,e[t+3]=u*g-a*d-l*f-c*h,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(i/2),u=a(r/2),d=a(s/2),f=l(i/2),h=l(r/2),g=l(s/2);switch(o){case"XYZ":this._x=f*u*d+c*h*g,this._y=c*h*d-f*u*g,this._z=c*u*g+f*h*d,this._w=c*u*d-f*h*g;break;case"YXZ":this._x=f*u*d+c*h*g,this._y=c*h*d-f*u*g,this._z=c*u*g-f*h*d,this._w=c*u*d+f*h*g;break;case"ZXY":this._x=f*u*d-c*h*g,this._y=c*h*d+f*u*g,this._z=c*u*g+f*h*d,this._w=c*u*d-f*h*g;break;case"ZYX":this._x=f*u*d-c*h*g,this._y=c*h*d+f*u*g,this._z=c*u*g-f*h*d,this._w=c*u*d+f*h*g;break;case"YZX":this._x=f*u*d+c*h*g,this._y=c*h*d+f*u*g,this._z=c*u*g-f*h*d,this._w=c*u*d-f*h*g;break;case"XZY":this._x=f*u*d-c*h*g,this._y=c*h*d-f*u*g,this._z=c*u*g+f*h*d,this._w=c*u*d+f*h*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],o=t[1],a=t[5],l=t[9],c=t[2],u=t[6],d=t[10],f=i+a+d;if(f>0){const h=.5/Math.sqrt(f+1);this._w=.25/h,this._x=(u-l)*h,this._y=(s-c)*h,this._z=(o-r)*h}else if(i>a&&i>d){const h=2*Math.sqrt(1+i-a-d);this._w=(u-l)/h,this._x=.25*h,this._y=(r+o)/h,this._z=(s+c)/h}else if(a>d){const h=2*Math.sqrt(1+a-i-d);this._w=(s-c)/h,this._x=(r+o)/h,this._y=.25*h,this._z=(l+u)/h}else{const h=2*Math.sqrt(1+d-i-a);this._w=(o-r)/h,this._x=(s+c)/h,this._y=(l+u)/h,this._z=.25*h}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(an(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,o=e._w,a=t._x,l=t._y,c=t._z,u=t._w;return this._x=i*u+o*a+r*c-s*l,this._y=r*u+o*l+s*a-i*c,this._z=s*u+o*c+i*l-r*a,this._w=o*u-i*a-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,r=this._y,s=this._z,o=this._w;let a=o*e._w+i*e._x+r*e._y+s*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=i,this._y=r,this._z=s,this;const l=1-a*a;if(l<=Number.EPSILON){const h=1-t;return this._w=h*o+t*this._w,this._x=h*i+t*this._x,this._y=h*r+t*this._y,this._z=h*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),u=Math.atan2(c,a),d=Math.sin((1-t)*u)/c,f=Math.sin(t*u)/c;return this._w=o*d+this._w*f,this._x=i*d+this._x*f,this._y=r*d+this._y*f,this._z=s*d+this._z*f,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),r=Math.sqrt(1-i),s=Math.sqrt(i);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class z{constructor(e=0,t=0,i=0){z.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Df.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Df.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,o=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*o,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*o,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*o,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*r-a*i),u=2*(a*t-s*r),d=2*(s*i-o*t);return this.x=t+l*c+o*d-a*u,this.y=i+l*u+a*c-s*d,this.z=r+l*d+s*u-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,o=t.x,a=t.y,l=t.z;return this.x=r*l-s*a,this.y=s*o-i*l,this.z=i*a-r*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return yl.copy(this).projectOnVector(e),this.sub(yl)}reflect(e){return this.sub(yl.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(an(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const yl=new z,Df=new yo;class vr{constructor(e=new z(1/0,1/0,1/0),t=new z(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Rn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Rn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=Rn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=s.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Rn):Rn.fromBufferAttribute(s,o),Rn.applyMatrix4(e.matrixWorld),this.expandByPoint(Rn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Po.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Po.copy(i.boundingBox)),Po.applyMatrix4(e.matrixWorld),this.union(Po)}const r=e.children;for(let s=0,o=r.length;s<o;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Rn),Rn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Ns),Io.subVectors(this.max,Ns),wr.subVectors(e.a,Ns),Rr.subVectors(e.b,Ns),Cr.subVectors(e.c,Ns),Si.subVectors(Rr,wr),yi.subVectors(Cr,Rr),Ki.subVectors(wr,Cr);let t=[0,-Si.z,Si.y,0,-yi.z,yi.y,0,-Ki.z,Ki.y,Si.z,0,-Si.x,yi.z,0,-yi.x,Ki.z,0,-Ki.x,-Si.y,Si.x,0,-yi.y,yi.x,0,-Ki.y,Ki.x,0];return!Ml(t,wr,Rr,Cr,Io)||(t=[1,0,0,0,1,0,0,0,1],!Ml(t,wr,Rr,Cr,Io))?!1:(Lo.crossVectors(Si,yi),t=[Lo.x,Lo.y,Lo.z],Ml(t,wr,Rr,Cr,Io))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Rn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Rn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ei[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ei[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ei[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ei[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ei[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ei[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ei[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ei[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ei),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const ei=[new z,new z,new z,new z,new z,new z,new z,new z],Rn=new z,Po=new vr,wr=new z,Rr=new z,Cr=new z,Si=new z,yi=new z,Ki=new z,Ns=new z,Io=new z,Lo=new z,Zi=new z;function Ml(n,e,t,i,r){for(let s=0,o=n.length-3;s<=o;s+=3){Zi.fromArray(n,s);const a=r.x*Math.abs(Zi.x)+r.y*Math.abs(Zi.y)+r.z*Math.abs(Zi.z),l=e.dot(Zi),c=t.dot(Zi),u=i.dot(Zi);if(Math.max(-Math.max(l,c,u),Math.min(l,c,u))>a)return!1}return!0}const b_=new vr,Us=new z,El=new z;class Mo{constructor(e=new z,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):b_.setFromPoints(e).getCenter(i);let r=0;for(let s=0,o=e.length;s<o;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Us.subVectors(e,this.center);const t=Us.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(Us,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(El.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Us.copy(e.center).add(El)),this.expandByPoint(Us.copy(e.center).sub(El))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const ti=new z,bl=new z,Do=new z,Mi=new z,Al=new z,No=new z,Tl=new z;class A_{constructor(e=new z,t=new z(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,ti)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=ti.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(ti.copy(this.origin).addScaledVector(this.direction,t),ti.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){bl.copy(e).add(t).multiplyScalar(.5),Do.copy(t).sub(e).normalize(),Mi.copy(this.origin).sub(bl);const s=e.distanceTo(t)*.5,o=-this.direction.dot(Do),a=Mi.dot(this.direction),l=-Mi.dot(Do),c=Mi.lengthSq(),u=Math.abs(1-o*o);let d,f,h,g;if(u>0)if(d=o*l-a,f=o*a-l,g=s*u,d>=0)if(f>=-g)if(f<=g){const _=1/u;d*=_,f*=_,h=d*(d+o*f+2*a)+f*(o*d+f+2*l)+c}else f=s,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*l)+c;else f=-s,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*l)+c;else f<=-g?(d=Math.max(0,-(-o*s+a)),f=d>0?-s:Math.min(Math.max(-s,-l),s),h=-d*d+f*(f+2*l)+c):f<=g?(d=0,f=Math.min(Math.max(-s,-l),s),h=f*(f+2*l)+c):(d=Math.max(0,-(o*s+a)),f=d>0?s:Math.min(Math.max(-s,-l),s),h=-d*d+f*(f+2*l)+c);else f=o>0?-s:s,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,d),r&&r.copy(bl).addScaledVector(Do,f),h}intersectSphere(e,t){ti.subVectors(e.center,this.origin);const i=ti.dot(this.direction),r=ti.dot(ti)-i*i,s=e.radius*e.radius;if(r>s)return null;const o=Math.sqrt(s-r),a=i-o,l=i+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,o,a,l;const c=1/this.direction.x,u=1/this.direction.y,d=1/this.direction.z,f=this.origin;return c>=0?(i=(e.min.x-f.x)*c,r=(e.max.x-f.x)*c):(i=(e.max.x-f.x)*c,r=(e.min.x-f.x)*c),u>=0?(s=(e.min.y-f.y)*u,o=(e.max.y-f.y)*u):(s=(e.max.y-f.y)*u,o=(e.min.y-f.y)*u),i>o||s>r||((s>i||isNaN(i))&&(i=s),(o<r||isNaN(r))&&(r=o),d>=0?(a=(e.min.z-f.z)*d,l=(e.max.z-f.z)*d):(a=(e.max.z-f.z)*d,l=(e.min.z-f.z)*d),i>l||a>r)||((a>i||i!==i)&&(i=a),(l<r||r!==r)&&(r=l),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,ti)!==null}intersectTriangle(e,t,i,r,s){Al.subVectors(t,e),No.subVectors(i,e),Tl.crossVectors(Al,No);let o=this.direction.dot(Tl),a;if(o>0){if(r)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Mi.subVectors(this.origin,e);const l=a*this.direction.dot(No.crossVectors(Mi,No));if(l<0)return null;const c=a*this.direction.dot(Al.cross(Mi));if(c<0||l+c>o)return null;const u=-a*Mi.dot(Tl);return u<0?null:this.at(u/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class St{constructor(e,t,i,r,s,o,a,l,c,u,d,f,h,g,_,m){St.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,o,a,l,c,u,d,f,h,g,_,m)}set(e,t,i,r,s,o,a,l,c,u,d,f,h,g,_,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=i,p[12]=r,p[1]=s,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=u,p[10]=d,p[14]=f,p[3]=h,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new St().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,r=1/Pr.setFromMatrixColumn(e,0).length(),s=1/Pr.setFromMatrixColumn(e,1).length(),o=1/Pr.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*o,t[9]=i[9]*o,t[10]=i[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,o=Math.cos(i),a=Math.sin(i),l=Math.cos(r),c=Math.sin(r),u=Math.cos(s),d=Math.sin(s);if(e.order==="XYZ"){const f=o*u,h=o*d,g=a*u,_=a*d;t[0]=l*u,t[4]=-l*d,t[8]=c,t[1]=h+g*c,t[5]=f-_*c,t[9]=-a*l,t[2]=_-f*c,t[6]=g+h*c,t[10]=o*l}else if(e.order==="YXZ"){const f=l*u,h=l*d,g=c*u,_=c*d;t[0]=f+_*a,t[4]=g*a-h,t[8]=o*c,t[1]=o*d,t[5]=o*u,t[9]=-a,t[2]=h*a-g,t[6]=_+f*a,t[10]=o*l}else if(e.order==="ZXY"){const f=l*u,h=l*d,g=c*u,_=c*d;t[0]=f-_*a,t[4]=-o*d,t[8]=g+h*a,t[1]=h+g*a,t[5]=o*u,t[9]=_-f*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){const f=o*u,h=o*d,g=a*u,_=a*d;t[0]=l*u,t[4]=g*c-h,t[8]=f*c+_,t[1]=l*d,t[5]=_*c+f,t[9]=h*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){const f=o*l,h=o*c,g=a*l,_=a*c;t[0]=l*u,t[4]=_-f*d,t[8]=g*d+h,t[1]=d,t[5]=o*u,t[9]=-a*u,t[2]=-c*u,t[6]=h*d+g,t[10]=f-_*d}else if(e.order==="XZY"){const f=o*l,h=o*c,g=a*l,_=a*c;t[0]=l*u,t[4]=-d,t[8]=c*u,t[1]=f*d+_,t[5]=o*u,t[9]=h*d-g,t[2]=g*d-h,t[6]=a*u,t[10]=_*d+f}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(T_,e,w_)}lookAt(e,t,i){const r=this.elements;return dn.subVectors(e,t),dn.lengthSq()===0&&(dn.z=1),dn.normalize(),Ei.crossVectors(i,dn),Ei.lengthSq()===0&&(Math.abs(i.z)===1?dn.x+=1e-4:dn.z+=1e-4,dn.normalize(),Ei.crossVectors(i,dn)),Ei.normalize(),Uo.crossVectors(dn,Ei),r[0]=Ei.x,r[4]=Uo.x,r[8]=dn.x,r[1]=Ei.y,r[5]=Uo.y,r[9]=dn.y,r[2]=Ei.z,r[6]=Uo.z,r[10]=dn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,o=i[0],a=i[4],l=i[8],c=i[12],u=i[1],d=i[5],f=i[9],h=i[13],g=i[2],_=i[6],m=i[10],p=i[14],E=i[3],S=i[7],y=i[11],C=i[15],R=r[0],A=r[4],P=r[8],x=r[12],v=r[1],w=r[5],k=r[9],B=r[13],X=r[2],J=r[6],H=r[10],te=r[14],I=r[3],Z=r[7],Q=r[11],se=r[15];return s[0]=o*R+a*v+l*X+c*I,s[4]=o*A+a*w+l*J+c*Z,s[8]=o*P+a*k+l*H+c*Q,s[12]=o*x+a*B+l*te+c*se,s[1]=u*R+d*v+f*X+h*I,s[5]=u*A+d*w+f*J+h*Z,s[9]=u*P+d*k+f*H+h*Q,s[13]=u*x+d*B+f*te+h*se,s[2]=g*R+_*v+m*X+p*I,s[6]=g*A+_*w+m*J+p*Z,s[10]=g*P+_*k+m*H+p*Q,s[14]=g*x+_*B+m*te+p*se,s[3]=E*R+S*v+y*X+C*I,s[7]=E*A+S*w+y*J+C*Z,s[11]=E*P+S*k+y*H+C*Q,s[15]=E*x+S*B+y*te+C*se,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],o=e[1],a=e[5],l=e[9],c=e[13],u=e[2],d=e[6],f=e[10],h=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+s*l*d-r*c*d-s*a*f+i*c*f+r*a*h-i*l*h)+_*(+t*l*h-t*c*f+s*o*f-r*o*h+r*c*u-s*l*u)+m*(+t*c*d-t*a*h-s*o*d+i*o*h+s*a*u-i*c*u)+p*(-r*a*u-t*l*d+t*a*f+r*o*d-i*o*f+i*l*u)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],u=e[8],d=e[9],f=e[10],h=e[11],g=e[12],_=e[13],m=e[14],p=e[15],E=d*m*c-_*f*c+_*l*h-a*m*h-d*l*p+a*f*p,S=g*f*c-u*m*c-g*l*h+o*m*h+u*l*p-o*f*p,y=u*_*c-g*d*c+g*a*h-o*_*h-u*a*p+o*d*p,C=g*d*l-u*_*l-g*a*f+o*_*f+u*a*m-o*d*m,R=t*E+i*S+r*y+s*C;if(R===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/R;return e[0]=E*A,e[1]=(_*f*s-d*m*s-_*r*h+i*m*h+d*r*p-i*f*p)*A,e[2]=(a*m*s-_*l*s+_*r*c-i*m*c-a*r*p+i*l*p)*A,e[3]=(d*l*s-a*f*s-d*r*c+i*f*c+a*r*h-i*l*h)*A,e[4]=S*A,e[5]=(u*m*s-g*f*s+g*r*h-t*m*h-u*r*p+t*f*p)*A,e[6]=(g*l*s-o*m*s-g*r*c+t*m*c+o*r*p-t*l*p)*A,e[7]=(o*f*s-u*l*s+u*r*c-t*f*c-o*r*h+t*l*h)*A,e[8]=y*A,e[9]=(g*d*s-u*_*s-g*i*h+t*_*h+u*i*p-t*d*p)*A,e[10]=(o*_*s-g*a*s+g*i*c-t*_*c-o*i*p+t*a*p)*A,e[11]=(u*a*s-o*d*s-u*i*c+t*d*c+o*i*h-t*a*h)*A,e[12]=C*A,e[13]=(u*_*r-g*d*r+g*i*f-t*_*f-u*i*m+t*d*m)*A,e[14]=(g*a*r-o*_*r-g*i*l+t*_*l+o*i*m-t*a*m)*A,e[15]=(o*d*r-u*a*r+u*i*l-t*d*l-o*i*f+t*a*f)*A,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,o=e.x,a=e.y,l=e.z,c=s*o,u=s*a;return this.set(c*o+i,c*a-r*l,c*l+r*a,0,c*a+r*l,u*a+i,u*l-r*o,0,c*l-r*a,u*l+r*o,s*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,o){return this.set(1,i,s,0,e,1,o,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,o=t._y,a=t._z,l=t._w,c=s+s,u=o+o,d=a+a,f=s*c,h=s*u,g=s*d,_=o*u,m=o*d,p=a*d,E=l*c,S=l*u,y=l*d,C=i.x,R=i.y,A=i.z;return r[0]=(1-(_+p))*C,r[1]=(h+y)*C,r[2]=(g-S)*C,r[3]=0,r[4]=(h-y)*R,r[5]=(1-(f+p))*R,r[6]=(m+E)*R,r[7]=0,r[8]=(g+S)*A,r[9]=(m-E)*A,r[10]=(1-(f+_))*A,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;let s=Pr.set(r[0],r[1],r[2]).length();const o=Pr.set(r[4],r[5],r[6]).length(),a=Pr.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],Cn.copy(this);const c=1/s,u=1/o,d=1/a;return Cn.elements[0]*=c,Cn.elements[1]*=c,Cn.elements[2]*=c,Cn.elements[4]*=u,Cn.elements[5]*=u,Cn.elements[6]*=u,Cn.elements[8]*=d,Cn.elements[9]*=d,Cn.elements[10]*=d,t.setFromRotationMatrix(Cn),i.x=s,i.y=o,i.z=a,this}makePerspective(e,t,i,r,s,o,a=ai){const l=this.elements,c=2*s/(t-e),u=2*s/(i-r),d=(t+e)/(t-e),f=(i+r)/(i-r);let h,g;if(a===ai)h=-(o+s)/(o-s),g=-2*o*s/(o-s);else if(a===Ca)h=-o/(o-s),g=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=u,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=h,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,r,s,o,a=ai){const l=this.elements,c=1/(t-e),u=1/(i-r),d=1/(o-s),f=(t+e)*c,h=(i+r)*u;let g,_;if(a===ai)g=(o+s)*d,_=-2*d;else if(a===Ca)g=s*d,_=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-f,l[1]=0,l[5]=2*u,l[9]=0,l[13]=-h,l[2]=0,l[6]=0,l[10]=_,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const Pr=new z,Cn=new St,T_=new z(0,0,0),w_=new z(1,1,1),Ei=new z,Uo=new z,dn=new z,Nf=new St,Uf=new yo;class Zn{constructor(e=0,t=0,i=0,r=Zn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],o=r[4],a=r[8],l=r[1],c=r[5],u=r[9],d=r[2],f=r[6],h=r[10];switch(t){case"XYZ":this._y=Math.asin(an(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,h),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(f,c),this._z=0);break;case"YXZ":this._x=Math.asin(-an(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,h),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(an(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-d,h),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-an(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(f,h),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(an(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-u,c),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(a,h));break;case"XZY":this._z=Math.asin(-an(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(f,c),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-u,h),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return Nf.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Nf,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Uf.setFromEuler(this),this.setFromQuaternion(Uf,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Zn.DEFAULT_ORDER="XYZ";class Ep{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let R_=0;const Of=new z,Ir=new yo,ni=new St,Oo=new z,Os=new z,C_=new z,P_=new yo,Ff=new z(1,0,0),kf=new z(0,1,0),Bf=new z(0,0,1),zf={type:"added"},I_={type:"removed"},Lr={type:"childadded",child:null},wl={type:"childremoved",child:null};class qt extends Ts{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:R_++}),this.uuid=zi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qt.DEFAULT_UP.clone();const e=new z,t=new Zn,i=new yo,r=new z(1,1,1);function s(){i.setFromEuler(t,!1)}function o(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new St},normalMatrix:{value:new We}}),this.matrix=new St,this.matrixWorld=new St,this.matrixAutoUpdate=qt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ep,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ir.setFromAxisAngle(e,t),this.quaternion.multiply(Ir),this}rotateOnWorldAxis(e,t){return Ir.setFromAxisAngle(e,t),this.quaternion.premultiply(Ir),this}rotateX(e){return this.rotateOnAxis(Ff,e)}rotateY(e){return this.rotateOnAxis(kf,e)}rotateZ(e){return this.rotateOnAxis(Bf,e)}translateOnAxis(e,t){return Of.copy(e).applyQuaternion(this.quaternion),this.position.add(Of.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Ff,e)}translateY(e){return this.translateOnAxis(kf,e)}translateZ(e){return this.translateOnAxis(Bf,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ni.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Oo.copy(e):Oo.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),Os.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ni.lookAt(Os,Oo,this.up):ni.lookAt(Oo,Os,this.up),this.quaternion.setFromRotationMatrix(ni),r&&(ni.extractRotation(r.matrixWorld),Ir.setFromRotationMatrix(ni),this.quaternion.premultiply(Ir.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(zf),Lr.child=e,this.dispatchEvent(Lr),Lr.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(I_),wl.child=e,this.dispatchEvent(wl),wl.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ni.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ni.multiply(e.parent.matrixWorld)),e.applyMatrix4(ni),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(zf),Lr.child=e,this.dispatchEvent(Lr),Lr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const o=this.children[i].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Os,e,C_),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Os,P_,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let c=0,u=l.length;c<u;c++){const d=l[c];s(e.shapes,d)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(s(e.materials,this.material[l]));r.material=a}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let a=0;a<this.children.length;a++)r.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];r.animations.push(s(e.animations,l))}}if(t){const a=o(e.geometries),l=o(e.materials),c=o(e.textures),u=o(e.images),d=o(e.shapes),f=o(e.skeletons),h=o(e.animations),g=o(e.nodes);a.length>0&&(i.geometries=a),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),u.length>0&&(i.images=u),d.length>0&&(i.shapes=d),f.length>0&&(i.skeletons=f),h.length>0&&(i.animations=h),g.length>0&&(i.nodes=g)}return i.object=r,i;function o(a){const l=[];for(const c in a){const u=a[c];delete u.metadata,l.push(u)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}qt.DEFAULT_UP=new z(0,1,0);qt.DEFAULT_MATRIX_AUTO_UPDATE=!0;qt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Pn=new z,ii=new z,Rl=new z,ri=new z,Dr=new z,Nr=new z,Hf=new z,Cl=new z,Pl=new z,Il=new z,Ll=new Ut,Dl=new Ut,Nl=new Ut;class En{constructor(e=new z,t=new z,i=new z){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),Pn.subVectors(e,t),r.cross(Pn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){Pn.subVectors(r,t),ii.subVectors(i,t),Rl.subVectors(e,t);const o=Pn.dot(Pn),a=Pn.dot(ii),l=Pn.dot(Rl),c=ii.dot(ii),u=ii.dot(Rl),d=o*c-a*a;if(d===0)return s.set(0,0,0),null;const f=1/d,h=(c*l-a*u)*f,g=(o*u-a*l)*f;return s.set(1-h-g,g,h)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,ri)===null?!1:ri.x>=0&&ri.y>=0&&ri.x+ri.y<=1}static getInterpolation(e,t,i,r,s,o,a,l){return this.getBarycoord(e,t,i,r,ri)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,ri.x),l.addScaledVector(o,ri.y),l.addScaledVector(a,ri.z),l)}static getInterpolatedAttribute(e,t,i,r,s,o){return Ll.setScalar(0),Dl.setScalar(0),Nl.setScalar(0),Ll.fromBufferAttribute(e,t),Dl.fromBufferAttribute(e,i),Nl.fromBufferAttribute(e,r),o.setScalar(0),o.addScaledVector(Ll,s.x),o.addScaledVector(Dl,s.y),o.addScaledVector(Nl,s.z),o}static isFrontFacing(e,t,i,r){return Pn.subVectors(i,t),ii.subVectors(e,t),Pn.cross(ii).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pn.subVectors(this.c,this.b),ii.subVectors(this.a,this.b),Pn.cross(ii).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return En.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return En.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,r,s){return En.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return En.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return En.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let o,a;Dr.subVectors(r,i),Nr.subVectors(s,i),Cl.subVectors(e,i);const l=Dr.dot(Cl),c=Nr.dot(Cl);if(l<=0&&c<=0)return t.copy(i);Pl.subVectors(e,r);const u=Dr.dot(Pl),d=Nr.dot(Pl);if(u>=0&&d<=u)return t.copy(r);const f=l*d-u*c;if(f<=0&&l>=0&&u<=0)return o=l/(l-u),t.copy(i).addScaledVector(Dr,o);Il.subVectors(e,s);const h=Dr.dot(Il),g=Nr.dot(Il);if(g>=0&&h<=g)return t.copy(s);const _=h*c-l*g;if(_<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(i).addScaledVector(Nr,a);const m=u*g-h*d;if(m<=0&&d-u>=0&&h-g>=0)return Hf.subVectors(s,r),a=(d-u)/(d-u+(h-g)),t.copy(r).addScaledVector(Hf,a);const p=1/(m+_+f);return o=_*p,a=f*p,t.copy(i).addScaledVector(Dr,o).addScaledVector(Nr,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const bp={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},bi={h:0,s:0,l:0},Fo={h:0,s:0,l:0};function Ul(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class et{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=jt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,at.toWorkingColorSpace(this,t),this}setRGB(e,t,i,r=at.workingColorSpace){return this.r=e,this.g=t,this.b=i,at.toWorkingColorSpace(this,r),this}setHSL(e,t,i,r=at.workingColorSpace){if(e=p_(e,1),t=an(t,0,1),i=an(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,o=2*i-s;this.r=Ul(o,s,e+1/3),this.g=Ul(o,s,e),this.b=Ul(o,s,e-1/3)}return at.toWorkingColorSpace(this,r),this}setStyle(e,t=jt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const o=r[1],a=r[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=jt){const i=bp[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ci(e.r),this.g=ci(e.g),this.b=ci(e.b),this}copyLinearToSRGB(e){return this.r=ts(e.r),this.g=ts(e.g),this.b=ts(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=jt){return at.fromWorkingColorSpace(Zt.copy(this),e),Math.round(an(Zt.r*255,0,255))*65536+Math.round(an(Zt.g*255,0,255))*256+Math.round(an(Zt.b*255,0,255))}getHexString(e=jt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=at.workingColorSpace){at.fromWorkingColorSpace(Zt.copy(this),t);const i=Zt.r,r=Zt.g,s=Zt.b,o=Math.max(i,r,s),a=Math.min(i,r,s);let l,c;const u=(a+o)/2;if(a===o)l=0,c=0;else{const d=o-a;switch(c=u<=.5?d/(o+a):d/(2-o-a),o){case i:l=(r-s)/d+(r<s?6:0);break;case r:l=(s-i)/d+2;break;case s:l=(i-r)/d+4;break}l/=6}return e.h=l,e.s=c,e.l=u,e}getRGB(e,t=at.workingColorSpace){return at.fromWorkingColorSpace(Zt.copy(this),t),e.r=Zt.r,e.g=Zt.g,e.b=Zt.b,e}getStyle(e=jt){at.fromWorkingColorSpace(Zt.copy(this),e);const t=Zt.r,i=Zt.g,r=Zt.b;return e!==jt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(bi),this.setHSL(bi.h+e,bi.s+t,bi.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(bi),e.getHSL(Fo);const i=vl(bi.h,Fo.h,t),r=vl(bi.s,Fo.s,t),s=vl(bi.l,Fo.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Zt=new et;et.NAMES=bp;let L_=0;class ws extends Ts{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:L_++}),this.uuid=zi(),this.name="",this.blending=Qr,this.side=Kn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Ac,this.blendDst=Tc,this.blendEquation=rr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new et(0,0,0),this.blendAlpha=0,this.depthFunc=us,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=bf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ar,this.stencilZFail=Ar,this.stencilZPass=Ar,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Qr&&(i.blending=this.blending),this.side!==Kn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Ac&&(i.blendSrc=this.blendSrc),this.blendDst!==Tc&&(i.blendDst=this.blendDst),this.blendEquation!==rr&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==us&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==bf&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ar&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Ar&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Ar&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const o=[];for(const a in s){const l=s[a];delete l.metadata,o.push(l)}return o}if(t){const s=r(e.textures),o=r(e.images);s.length>0&&(i.textures=s),o.length>0&&(i.images=o)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class Wi extends ws{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new et(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Zn,this.combine=Pu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Ft=new z,ko=new nt;class bt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=cu,this.updateRanges=[],this.gpuType=Hn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)ko.fromBufferAttribute(this,t),ko.applyMatrix3(e),this.setXY(t,ko.x,ko.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.applyMatrix3(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.applyMatrix4(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.applyNormalMatrix(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.transformDirection(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=Bn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=vt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Bn(t,this.array)),t}setX(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Bn(t,this.array)),t}setY(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Bn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Bn(t,this.array)),t}setW(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array),s=vt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==cu&&(e.usage=this.usage),e}}class Ap extends bt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class Tp extends bt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class Xn extends bt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let D_=0;const vn=new St,Ol=new qt,Ur=new z,hn=new vr,Fs=new vr,Gt=new z;class Jt extends Ts{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:D_++}),this.uuid=zi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(yp(e)?Tp:Ap)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new We().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return vn.makeRotationFromQuaternion(e),this.applyMatrix4(vn),this}rotateX(e){return vn.makeRotationX(e),this.applyMatrix4(vn),this}rotateY(e){return vn.makeRotationY(e),this.applyMatrix4(vn),this}rotateZ(e){return vn.makeRotationZ(e),this.applyMatrix4(vn),this}translate(e,t,i){return vn.makeTranslation(e,t,i),this.applyMatrix4(vn),this}scale(e,t,i){return vn.makeScale(e,t,i),this.applyMatrix4(vn),this}lookAt(e){return Ol.lookAt(e),Ol.updateMatrix(),this.applyMatrix4(Ol.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ur).negate(),this.translate(Ur.x,Ur.y,Ur.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const i=[];for(let r=0,s=e.length;r<s;r++){const o=e[r];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Xn(i,3))}else{for(let i=0,r=t.count;i<r;i++){const s=e[i];t.setXYZ(i,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new vr);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new z(-1/0,-1/0,-1/0),new z(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];hn.setFromBufferAttribute(s),this.morphTargetsRelative?(Gt.addVectors(this.boundingBox.min,hn.min),this.boundingBox.expandByPoint(Gt),Gt.addVectors(this.boundingBox.max,hn.max),this.boundingBox.expandByPoint(Gt)):(this.boundingBox.expandByPoint(hn.min),this.boundingBox.expandByPoint(hn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Mo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new z,1/0);return}if(e){const i=this.boundingSphere.center;if(hn.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){const a=t[s];Fs.setFromBufferAttribute(a),this.morphTargetsRelative?(Gt.addVectors(hn.min,Fs.min),hn.expandByPoint(Gt),Gt.addVectors(hn.max,Fs.max),hn.expandByPoint(Gt)):(hn.expandByPoint(Fs.min),hn.expandByPoint(Fs.max))}hn.getCenter(i);let r=0;for(let s=0,o=e.count;s<o;s++)Gt.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(Gt));if(t)for(let s=0,o=t.length;s<o;s++){const a=t[s],l=this.morphTargetsRelative;for(let c=0,u=a.count;c<u;c++)Gt.fromBufferAttribute(a,c),l&&(Ur.fromBufferAttribute(e,c),Gt.add(Ur)),r=Math.max(r,i.distanceToSquared(Gt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=t.position,r=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new bt(new Float32Array(4*i.count),4));const o=this.getAttribute("tangent"),a=[],l=[];for(let P=0;P<i.count;P++)a[P]=new z,l[P]=new z;const c=new z,u=new z,d=new z,f=new nt,h=new nt,g=new nt,_=new z,m=new z;function p(P,x,v){c.fromBufferAttribute(i,P),u.fromBufferAttribute(i,x),d.fromBufferAttribute(i,v),f.fromBufferAttribute(s,P),h.fromBufferAttribute(s,x),g.fromBufferAttribute(s,v),u.sub(c),d.sub(c),h.sub(f),g.sub(f);const w=1/(h.x*g.y-g.x*h.y);isFinite(w)&&(_.copy(u).multiplyScalar(g.y).addScaledVector(d,-h.y).multiplyScalar(w),m.copy(d).multiplyScalar(h.x).addScaledVector(u,-g.x).multiplyScalar(w),a[P].add(_),a[x].add(_),a[v].add(_),l[P].add(m),l[x].add(m),l[v].add(m))}let E=this.groups;E.length===0&&(E=[{start:0,count:e.count}]);for(let P=0,x=E.length;P<x;++P){const v=E[P],w=v.start,k=v.count;for(let B=w,X=w+k;B<X;B+=3)p(e.getX(B+0),e.getX(B+1),e.getX(B+2))}const S=new z,y=new z,C=new z,R=new z;function A(P){C.fromBufferAttribute(r,P),R.copy(C);const x=a[P];S.copy(x),S.sub(C.multiplyScalar(C.dot(x))).normalize(),y.crossVectors(R,x);const w=y.dot(l[P])<0?-1:1;o.setXYZW(P,S.x,S.y,S.z,w)}for(let P=0,x=E.length;P<x;++P){const v=E[P],w=v.start,k=v.count;for(let B=w,X=w+k;B<X;B+=3)A(e.getX(B+0)),A(e.getX(B+1)),A(e.getX(B+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new bt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let f=0,h=i.count;f<h;f++)i.setXYZ(f,0,0,0);const r=new z,s=new z,o=new z,a=new z,l=new z,c=new z,u=new z,d=new z;if(e)for(let f=0,h=e.count;f<h;f+=3){const g=e.getX(f+0),_=e.getX(f+1),m=e.getX(f+2);r.fromBufferAttribute(t,g),s.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),u.subVectors(o,s),d.subVectors(r,s),u.cross(d),a.fromBufferAttribute(i,g),l.fromBufferAttribute(i,_),c.fromBufferAttribute(i,m),a.add(u),l.add(u),c.add(u),i.setXYZ(g,a.x,a.y,a.z),i.setXYZ(_,l.x,l.y,l.z),i.setXYZ(m,c.x,c.y,c.z)}else for(let f=0,h=t.count;f<h;f+=3)r.fromBufferAttribute(t,f+0),s.fromBufferAttribute(t,f+1),o.fromBufferAttribute(t,f+2),u.subVectors(o,s),d.subVectors(r,s),u.cross(d),i.setXYZ(f+0,u.x,u.y,u.z),i.setXYZ(f+1,u.x,u.y,u.z),i.setXYZ(f+2,u.x,u.y,u.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Gt.fromBufferAttribute(e,t),Gt.normalize(),e.setXYZ(t,Gt.x,Gt.y,Gt.z)}toNonIndexed(){function e(a,l){const c=a.array,u=a.itemSize,d=a.normalized,f=new c.constructor(l.length*u);let h=0,g=0;for(let _=0,m=l.length;_<m;_++){a.isInterleavedBufferAttribute?h=l[_]*a.data.stride+a.offset:h=l[_]*u;for(let p=0;p<u;p++)f[g++]=c[h++]}return new bt(f,u,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Jt,i=this.index.array,r=this.attributes;for(const a in r){const l=r[a],c=e(l,i);t.setAttribute(a,c)}const s=this.morphAttributes;for(const a in s){const l=[],c=s[a];for(let u=0,d=c.length;u<d;u++){const f=c[u],h=e(f,i);l.push(h)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const l in i){const c=i[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],u=[];for(let d=0,f=c.length;d<f;d++){const h=c[d];u.push(h.toJSON(e.data))}u.length>0&&(r[l]=u,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const r=e.attributes;for(const c in r){const u=r[c];this.setAttribute(c,u.clone(t))}const s=e.morphAttributes;for(const c in s){const u=[],d=s[c];for(let f=0,h=d.length;f<h;f++)u.push(d[f].clone(t));this.morphAttributes[c]=u}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let c=0,u=o.length;c<u;c++){const d=o[c];this.addGroup(d.start,d.count,d.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Vf=new St,$i=new A_,Bo=new Mo,Gf=new z,zo=new z,Ho=new z,Vo=new z,Fl=new z,Go=new z,Wf=new z,Wo=new z;class je extends qt{constructor(e=new Jt,t=new Wi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){const a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,o=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const a=this.morphTargetInfluences;if(s&&a){Go.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const u=a[l],d=s[l];u!==0&&(Fl.fromBufferAttribute(d,e),o?Go.addScaledVector(Fl,u):Go.addScaledVector(Fl.sub(t),u))}t.add(Go)}return t}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Bo.copy(i.boundingSphere),Bo.applyMatrix4(s),$i.copy(e.ray).recast(e.near),!(Bo.containsPoint($i.origin)===!1&&($i.intersectSphere(Bo,Gf)===null||$i.origin.distanceToSquared(Gf)>(e.far-e.near)**2))&&(Vf.copy(s).invert(),$i.copy(e.ray).applyMatrix4(Vf),!(i.boundingBox!==null&&$i.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,$i)))}_computeIntersections(e,t,i){let r;const s=this.geometry,o=this.material,a=s.index,l=s.attributes.position,c=s.attributes.uv,u=s.attributes.uv1,d=s.attributes.normal,f=s.groups,h=s.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=f.length;g<_;g++){const m=f[g],p=o[m.materialIndex],E=Math.max(m.start,h.start),S=Math.min(a.count,Math.min(m.start+m.count,h.start+h.count));for(let y=E,C=S;y<C;y+=3){const R=a.getX(y),A=a.getX(y+1),P=a.getX(y+2);r=Xo(this,p,e,i,c,u,d,R,A,P),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,h.start),_=Math.min(a.count,h.start+h.count);for(let m=g,p=_;m<p;m+=3){const E=a.getX(m),S=a.getX(m+1),y=a.getX(m+2);r=Xo(this,o,e,i,c,u,d,E,S,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,_=f.length;g<_;g++){const m=f[g],p=o[m.materialIndex],E=Math.max(m.start,h.start),S=Math.min(l.count,Math.min(m.start+m.count,h.start+h.count));for(let y=E,C=S;y<C;y+=3){const R=y,A=y+1,P=y+2;r=Xo(this,p,e,i,c,u,d,R,A,P),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,h.start),_=Math.min(l.count,h.start+h.count);for(let m=g,p=_;m<p;m+=3){const E=m,S=m+1,y=m+2;r=Xo(this,o,e,i,c,u,d,E,S,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function N_(n,e,t,i,r,s,o,a){let l;if(e.side===sn?l=i.intersectTriangle(o,s,r,!0,a):l=i.intersectTriangle(r,s,o,e.side===Kn,a),l===null)return null;Wo.copy(a),Wo.applyMatrix4(n.matrixWorld);const c=t.ray.origin.distanceTo(Wo);return c<t.near||c>t.far?null:{distance:c,point:Wo.clone(),object:n}}function Xo(n,e,t,i,r,s,o,a,l,c){n.getVertexPosition(a,zo),n.getVertexPosition(l,Ho),n.getVertexPosition(c,Vo);const u=N_(n,e,t,i,zo,Ho,Vo,Wf);if(u){const d=new z;En.getBarycoord(Wf,zo,Ho,Vo,d),r&&(u.uv=En.getInterpolatedAttribute(r,a,l,c,d,new nt)),s&&(u.uv1=En.getInterpolatedAttribute(s,a,l,c,d,new nt)),o&&(u.normal=En.getInterpolatedAttribute(o,a,l,c,d,new z),u.normal.dot(i.direction)>0&&u.normal.multiplyScalar(-1));const f={a,b:l,c,normal:new z,materialIndex:0};En.getNormal(zo,Ho,Vo,f.normal),u.face=f,u.barycoord=d}return u}class rn extends Jt{constructor(e=1,t=1,i=1,r=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:o};const a=this;r=Math.floor(r),s=Math.floor(s),o=Math.floor(o);const l=[],c=[],u=[],d=[];let f=0,h=0;g("z","y","x",-1,-1,i,t,e,o,s,0),g("z","y","x",1,-1,i,t,-e,o,s,1),g("x","z","y",1,1,e,i,t,r,o,2),g("x","z","y",1,-1,e,i,-t,r,o,3),g("x","y","z",1,-1,e,t,i,r,s,4),g("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(l),this.setAttribute("position",new Xn(c,3)),this.setAttribute("normal",new Xn(u,3)),this.setAttribute("uv",new Xn(d,2));function g(_,m,p,E,S,y,C,R,A,P,x){const v=y/A,w=C/P,k=y/2,B=C/2,X=R/2,J=A+1,H=P+1;let te=0,I=0;const Z=new z;for(let Q=0;Q<H;Q++){const se=Q*w-B;for(let Me=0;Me<J;Me++){const Je=Me*v-k;Z[_]=Je*E,Z[m]=se*S,Z[p]=X,c.push(Z.x,Z.y,Z.z),Z[_]=0,Z[m]=0,Z[p]=R>0?1:-1,u.push(Z.x,Z.y,Z.z),d.push(Me/A),d.push(1-Q/P),te+=1}}for(let Q=0;Q<P;Q++)for(let se=0;se<A;se++){const Me=f+se+J*Q,Je=f+se+J*(Q+1),K=f+(se+1)+J*(Q+1),re=f+(se+1)+J*Q;l.push(Me,Je,re),l.push(Je,K,re),I+=6}a.addGroup(h,I,x),h+=I,f+=te}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new rn(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function ms(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone():Array.isArray(r)?e[t][i]=r.slice():e[t][i]=r}}return e}function nn(n){const e={};for(let t=0;t<n.length;t++){const i=ms(n[t]);for(const r in i)e[r]=i[r]}return e}function U_(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function wp(n){const e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:at.workingColorSpace}const O_={clone:ms,merge:nn};var F_=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,k_=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class gi extends ws{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=F_,this.fragmentShader=k_,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ms(e.uniforms),this.uniformsGroups=U_(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const o=this.uniforms[r].value;o&&o.isTexture?t.uniforms[r]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[r]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[r]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[r]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[r]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[r]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[r]={type:"m4",value:o.toArray()}:t.uniforms[r]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class Rp extends qt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new St,this.projectionMatrix=new St,this.projectionMatrixInverse=new St,this.coordinateSystem=ai}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Ai=new z,Xf=new nt,qf=new nt;class Mn extends Rp{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=uu*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(_l*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return uu*2*Math.atan(Math.tan(_l*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){Ai.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Ai.x,Ai.y).multiplyScalar(-e/Ai.z),Ai.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Ai.x,Ai.y).multiplyScalar(-e/Ai.z)}getViewSize(e,t){return this.getViewBounds(e,Xf,qf),t.subVectors(qf,Xf)}setViewOffset(e,t,i,r,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(_l*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,c=o.fullHeight;s+=o.offsetX*r/l,t-=o.offsetY*i/c,r*=o.width/l,i*=o.height/c}const a=this.filmOffset;a!==0&&(s+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Or=-90,Fr=1;class B_ extends qt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Mn(Or,Fr,e,t);r.layers=this.layers,this.add(r);const s=new Mn(Or,Fr,e,t);s.layers=this.layers,this.add(s);const o=new Mn(Or,Fr,e,t);o.layers=this.layers,this.add(o);const a=new Mn(Or,Fr,e,t);a.layers=this.layers,this.add(a);const l=new Mn(Or,Fr,e,t);l.layers=this.layers,this.add(l);const c=new Mn(Or,Fr,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,o,a,l]=t;for(const c of t)this.remove(c);if(e===ai)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Ca)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,o,a,l,c,u]=this.children,d=e.getRenderTarget(),f=e.getActiveCubeFace(),h=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const _=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,r),e.render(t,s),e.setRenderTarget(i,1,r),e.render(t,o),e.setRenderTarget(i,2,r),e.render(t,a),e.setRenderTarget(i,3,r),e.render(t,l),e.setRenderTarget(i,4,r),e.render(t,c),i.texture.generateMipmaps=_,e.setRenderTarget(i,5,r),e.render(t,u),e.setRenderTarget(d,f,h),e.xr.enabled=g,i.texture.needsPMREMUpdate=!0}}class Cp extends Qt{constructor(e,t,i,r,s,o,a,l,c,u){e=e!==void 0?e:[],t=t!==void 0?t:fs,super(e,t,i,r,s,o,a,l,c,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class z_ extends dr{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];this.texture=new Cp(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:zn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new rn(5,5,5),s=new gi({name:"CubemapFromEquirect",uniforms:ms(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:sn,blending:ki});s.uniforms.tEquirect.value=t;const o=new je(r,s),a=t.minFilter;return t.minFilter===lr&&(t.minFilter=zn),new B_(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,i,r){const s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,i,r);e.setRenderTarget(s)}}const kl=new z,H_=new z,V_=new We;class nr{constructor(e=new z(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=kl.subVectors(i,t).cross(H_.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(kl),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||V_.getNormalMatrix(e),r=this.coplanarPoint(kl).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ji=new Mo,qo=new z;class Bu{constructor(e=new nr,t=new nr,i=new nr,r=new nr,s=new nr,o=new nr){this.planes=[e,t,i,r,s,o]}set(e,t,i,r,s,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(i),a[3].copy(r),a[4].copy(s),a[5].copy(o),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=ai){const i=this.planes,r=e.elements,s=r[0],o=r[1],a=r[2],l=r[3],c=r[4],u=r[5],d=r[6],f=r[7],h=r[8],g=r[9],_=r[10],m=r[11],p=r[12],E=r[13],S=r[14],y=r[15];if(i[0].setComponents(l-s,f-c,m-h,y-p).normalize(),i[1].setComponents(l+s,f+c,m+h,y+p).normalize(),i[2].setComponents(l+o,f+u,m+g,y+E).normalize(),i[3].setComponents(l-o,f-u,m-g,y-E).normalize(),i[4].setComponents(l-a,f-d,m-_,y-S).normalize(),t===ai)i[5].setComponents(l+a,f+d,m+_,y+S).normalize();else if(t===Ca)i[5].setComponents(a,d,_,S).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ji.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ji.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ji)}intersectsSprite(e){return ji.center.set(0,0,0),ji.radius=.7071067811865476,ji.applyMatrix4(e.matrixWorld),this.intersectsSphere(ji)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(qo.x=r.normal.x>0?e.max.x:e.min.x,qo.y=r.normal.y>0?e.max.y:e.min.y,qo.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(qo)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Pp(){let n=null,e=!1,t=null,i=null;function r(s,o){t(s,o),i=n.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function G_(n){const e=new WeakMap;function t(a,l){const c=a.array,u=a.usage,d=c.byteLength,f=n.createBuffer();n.bindBuffer(l,f),n.bufferData(l,c,u),a.onUploadCallback();let h;if(c instanceof Float32Array)h=n.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?h=n.HALF_FLOAT:h=n.UNSIGNED_SHORT;else if(c instanceof Int16Array)h=n.SHORT;else if(c instanceof Uint32Array)h=n.UNSIGNED_INT;else if(c instanceof Int32Array)h=n.INT;else if(c instanceof Int8Array)h=n.BYTE;else if(c instanceof Uint8Array)h=n.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)h=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:f,type:h,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:d}}function i(a,l,c){const u=l.array,d=l.updateRanges;if(n.bindBuffer(c,a),d.length===0)n.bufferSubData(c,0,u);else{d.sort((h,g)=>h.start-g.start);let f=0;for(let h=1;h<d.length;h++){const g=d[f],_=d[h];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++f,d[f]=_)}d.length=f+1;for(let h=0,g=d.length;h<g;h++){const _=d[h];n.bufferSubData(c,_.start*u.BYTES_PER_ELEMENT,u,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=e.get(a);l&&(n.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const u=e.get(a);(!u||u.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,a,l),c.version=a.version}}return{get:r,remove:s,update:o}}class _i extends Jt{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,o=t/2,a=Math.floor(i),l=Math.floor(r),c=a+1,u=l+1,d=e/a,f=t/l,h=[],g=[],_=[],m=[];for(let p=0;p<u;p++){const E=p*f-o;for(let S=0;S<c;S++){const y=S*d-s;g.push(y,-E,0),_.push(0,0,1),m.push(S/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let E=0;E<a;E++){const S=E+c*p,y=E+c*(p+1),C=E+1+c*(p+1),R=E+1+c*p;h.push(S,y,R),h.push(y,C,R)}this.setIndex(h),this.setAttribute("position",new Xn(g,3)),this.setAttribute("normal",new Xn(_,3)),this.setAttribute("uv",new Xn(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new _i(e.width,e.height,e.widthSegments,e.heightSegments)}}var W_=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,X_=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,q_=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Y_=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,K_=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Z_=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,$_=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,j_=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,J_=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Q_=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,e0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,t0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,n0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,i0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,r0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,s0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,o0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,a0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,l0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,c0=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,u0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,f0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,d0=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,h0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,p0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,m0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,g0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,_0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,v0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,x0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,S0="gl_FragColor = linearToOutputTexel( gl_FragColor );",y0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,M0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,E0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,b0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,A0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,T0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,w0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,R0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,C0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,P0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,I0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,L0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,D0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,N0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,U0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,O0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,F0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,k0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,B0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,z0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,H0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,V0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,G0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,W0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,X0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,q0=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Y0=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,K0=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Z0=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,$0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,j0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,J0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Q0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,ev=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,tv=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,nv=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,iv=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,rv=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,sv=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,ov=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,av=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,lv=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,cv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,uv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,fv=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,dv=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,hv=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,pv=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,mv=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,gv=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,_v=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,vv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,xv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Sv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,yv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Mv=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Ev=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,bv=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Av=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Tv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,wv=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Rv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Cv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Pv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Iv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Lv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Dv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Nv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Uv=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Ov=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Fv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,kv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Bv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,zv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Hv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Vv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Gv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Wv=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,qv=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Yv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Kv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Zv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,$v=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,jv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Jv=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Qv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ex=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,tx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,nx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ix=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,rx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ox=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ax=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,lx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,cx=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,ux=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,fx=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,dx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,hx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,px=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mx=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,gx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_x=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,vx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,xx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Sx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,yx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Mx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:W_,alphahash_pars_fragment:X_,alphamap_fragment:q_,alphamap_pars_fragment:Y_,alphatest_fragment:K_,alphatest_pars_fragment:Z_,aomap_fragment:$_,aomap_pars_fragment:j_,batching_pars_vertex:J_,batching_vertex:Q_,begin_vertex:e0,beginnormal_vertex:t0,bsdfs:n0,iridescence_fragment:i0,bumpmap_pars_fragment:r0,clipping_planes_fragment:s0,clipping_planes_pars_fragment:o0,clipping_planes_pars_vertex:a0,clipping_planes_vertex:l0,color_fragment:c0,color_pars_fragment:u0,color_pars_vertex:f0,color_vertex:d0,common:h0,cube_uv_reflection_fragment:p0,defaultnormal_vertex:m0,displacementmap_pars_vertex:g0,displacementmap_vertex:_0,emissivemap_fragment:v0,emissivemap_pars_fragment:x0,colorspace_fragment:S0,colorspace_pars_fragment:y0,envmap_fragment:M0,envmap_common_pars_fragment:E0,envmap_pars_fragment:b0,envmap_pars_vertex:A0,envmap_physical_pars_fragment:O0,envmap_vertex:T0,fog_vertex:w0,fog_pars_vertex:R0,fog_fragment:C0,fog_pars_fragment:P0,gradientmap_pars_fragment:I0,lightmap_pars_fragment:L0,lights_lambert_fragment:D0,lights_lambert_pars_fragment:N0,lights_pars_begin:U0,lights_toon_fragment:F0,lights_toon_pars_fragment:k0,lights_phong_fragment:B0,lights_phong_pars_fragment:z0,lights_physical_fragment:H0,lights_physical_pars_fragment:V0,lights_fragment_begin:G0,lights_fragment_maps:W0,lights_fragment_end:X0,logdepthbuf_fragment:q0,logdepthbuf_pars_fragment:Y0,logdepthbuf_pars_vertex:K0,logdepthbuf_vertex:Z0,map_fragment:$0,map_pars_fragment:j0,map_particle_fragment:J0,map_particle_pars_fragment:Q0,metalnessmap_fragment:ev,metalnessmap_pars_fragment:tv,morphinstance_vertex:nv,morphcolor_vertex:iv,morphnormal_vertex:rv,morphtarget_pars_vertex:sv,morphtarget_vertex:ov,normal_fragment_begin:av,normal_fragment_maps:lv,normal_pars_fragment:cv,normal_pars_vertex:uv,normal_vertex:fv,normalmap_pars_fragment:dv,clearcoat_normal_fragment_begin:hv,clearcoat_normal_fragment_maps:pv,clearcoat_pars_fragment:mv,iridescence_pars_fragment:gv,opaque_fragment:_v,packing:vv,premultiplied_alpha_fragment:xv,project_vertex:Sv,dithering_fragment:yv,dithering_pars_fragment:Mv,roughnessmap_fragment:Ev,roughnessmap_pars_fragment:bv,shadowmap_pars_fragment:Av,shadowmap_pars_vertex:Tv,shadowmap_vertex:wv,shadowmask_pars_fragment:Rv,skinbase_vertex:Cv,skinning_pars_vertex:Pv,skinning_vertex:Iv,skinnormal_vertex:Lv,specularmap_fragment:Dv,specularmap_pars_fragment:Nv,tonemapping_fragment:Uv,tonemapping_pars_fragment:Ov,transmission_fragment:Fv,transmission_pars_fragment:kv,uv_pars_fragment:Bv,uv_pars_vertex:zv,uv_vertex:Hv,worldpos_vertex:Vv,background_vert:Gv,background_frag:Wv,backgroundCube_vert:Xv,backgroundCube_frag:qv,cube_vert:Yv,cube_frag:Kv,depth_vert:Zv,depth_frag:$v,distanceRGBA_vert:jv,distanceRGBA_frag:Jv,equirect_vert:Qv,equirect_frag:ex,linedashed_vert:tx,linedashed_frag:nx,meshbasic_vert:ix,meshbasic_frag:rx,meshlambert_vert:sx,meshlambert_frag:ox,meshmatcap_vert:ax,meshmatcap_frag:lx,meshnormal_vert:cx,meshnormal_frag:ux,meshphong_vert:fx,meshphong_frag:dx,meshphysical_vert:hx,meshphysical_frag:px,meshtoon_vert:mx,meshtoon_frag:gx,points_vert:_x,points_frag:vx,shadow_vert:xx,shadow_frag:Sx,sprite_vert:yx,sprite_frag:Mx},ue={common:{diffuse:{value:new et(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new We}},envmap:{envMap:{value:null},envMapRotation:{value:new We},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new We}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new We}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new We},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new We},normalScale:{value:new nt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new We},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new We}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new We}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new We}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new et(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new et(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0},uvTransform:{value:new We}},sprite:{diffuse:{value:new et(16777215)},opacity:{value:1},center:{value:new nt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}}},Fn={basic:{uniforms:nn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:nn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,ue.lights,{emissive:{value:new et(0)}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:nn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,ue.lights,{emissive:{value:new et(0)},specular:{value:new et(1118481)},shininess:{value:30}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:nn([ue.common,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.roughnessmap,ue.metalnessmap,ue.fog,ue.lights,{emissive:{value:new et(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:nn([ue.common,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.gradientmap,ue.fog,ue.lights,{emissive:{value:new et(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:nn([ue.common,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:nn([ue.points,ue.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:nn([ue.common,ue.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:nn([ue.common,ue.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:nn([ue.common,ue.bumpmap,ue.normalmap,ue.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:nn([ue.sprite,ue.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new We},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new We}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distanceRGBA:{uniforms:nn([ue.common,ue.displacementmap,{referencePosition:{value:new z},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distanceRGBA_vert,fragmentShader:qe.distanceRGBA_frag},shadow:{uniforms:nn([ue.lights,ue.fog,{color:{value:new et(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};Fn.physical={uniforms:nn([Fn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new We},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new We},clearcoatNormalScale:{value:new nt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new We},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new We},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new We},sheen:{value:0},sheenColor:{value:new et(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new We},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new We},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new We},transmissionSamplerSize:{value:new nt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new We},attenuationDistance:{value:0},attenuationColor:{value:new et(0)},specularColor:{value:new et(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new We},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new We},anisotropyVector:{value:new nt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new We}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const Yo={r:0,b:0,g:0},Ji=new Zn,Ex=new St;function bx(n,e,t,i,r,s,o){const a=new et(0);let l=s===!0?0:1,c,u,d=null,f=0,h=null;function g(E){let S=E.isScene===!0?E.background:null;return S&&S.isTexture&&(S=(E.backgroundBlurriness>0?t:e).get(S)),S}function _(E){let S=!1;const y=g(E);y===null?p(a,l):y&&y.isColor&&(p(y,1),S=!0);const C=n.xr.getEnvironmentBlendMode();C==="additive"?i.buffers.color.setClear(0,0,0,1,o):C==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,o),(n.autoClear||S)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function m(E,S){const y=g(S);y&&(y.isCubeTexture||y.mapping===$a)?(u===void 0&&(u=new je(new rn(1,1,1),new gi({name:"BackgroundCubeMaterial",uniforms:ms(Fn.backgroundCube.uniforms),vertexShader:Fn.backgroundCube.vertexShader,fragmentShader:Fn.backgroundCube.fragmentShader,side:sn,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(C,R,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(u)),Ji.copy(S.backgroundRotation),Ji.x*=-1,Ji.y*=-1,Ji.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(Ji.y*=-1,Ji.z*=-1),u.material.uniforms.envMap.value=y,u.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,u.material.uniforms.backgroundRotation.value.setFromMatrix4(Ex.makeRotationFromEuler(Ji)),u.material.toneMapped=at.getTransfer(y.colorSpace)!==gt,(d!==y||f!==y.version||h!==n.toneMapping)&&(u.material.needsUpdate=!0,d=y,f=y.version,h=n.toneMapping),u.layers.enableAll(),E.unshift(u,u.geometry,u.material,0,0,null)):y&&y.isTexture&&(c===void 0&&(c=new je(new _i(2,2),new gi({name:"BackgroundMaterial",uniforms:ms(Fn.background.uniforms),vertexShader:Fn.background.vertexShader,fragmentShader:Fn.background.fragmentShader,side:Kn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=y,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.toneMapped=at.getTransfer(y.colorSpace)!==gt,y.matrixAutoUpdate===!0&&y.updateMatrix(),c.material.uniforms.uvTransform.value.copy(y.matrix),(d!==y||f!==y.version||h!==n.toneMapping)&&(c.material.needsUpdate=!0,d=y,f=y.version,h=n.toneMapping),c.layers.enableAll(),E.unshift(c,c.geometry,c.material,0,0,null))}function p(E,S){E.getRGB(Yo,wp(n)),i.buffers.color.setClear(Yo.r,Yo.g,Yo.b,S,o)}return{getClearColor:function(){return a},setClearColor:function(E,S=1){a.set(E),l=S,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(E){l=E,p(a,l)},render:_,addToRenderList:m}}function Ax(n,e){const t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},r=f(null);let s=r,o=!1;function a(v,w,k,B,X){let J=!1;const H=d(B,k,w);s!==H&&(s=H,c(s.object)),J=h(v,B,k,X),J&&g(v,B,k,X),X!==null&&e.update(X,n.ELEMENT_ARRAY_BUFFER),(J||o)&&(o=!1,y(v,w,k,B),X!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(X).buffer))}function l(){return n.createVertexArray()}function c(v){return n.bindVertexArray(v)}function u(v){return n.deleteVertexArray(v)}function d(v,w,k){const B=k.wireframe===!0;let X=i[v.id];X===void 0&&(X={},i[v.id]=X);let J=X[w.id];J===void 0&&(J={},X[w.id]=J);let H=J[B];return H===void 0&&(H=f(l()),J[B]=H),H}function f(v){const w=[],k=[],B=[];for(let X=0;X<t;X++)w[X]=0,k[X]=0,B[X]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:w,enabledAttributes:k,attributeDivisors:B,object:v,attributes:{},index:null}}function h(v,w,k,B){const X=s.attributes,J=w.attributes;let H=0;const te=k.getAttributes();for(const I in te)if(te[I].location>=0){const Q=X[I];let se=J[I];if(se===void 0&&(I==="instanceMatrix"&&v.instanceMatrix&&(se=v.instanceMatrix),I==="instanceColor"&&v.instanceColor&&(se=v.instanceColor)),Q===void 0||Q.attribute!==se||se&&Q.data!==se.data)return!0;H++}return s.attributesNum!==H||s.index!==B}function g(v,w,k,B){const X={},J=w.attributes;let H=0;const te=k.getAttributes();for(const I in te)if(te[I].location>=0){let Q=J[I];Q===void 0&&(I==="instanceMatrix"&&v.instanceMatrix&&(Q=v.instanceMatrix),I==="instanceColor"&&v.instanceColor&&(Q=v.instanceColor));const se={};se.attribute=Q,Q&&Q.data&&(se.data=Q.data),X[I]=se,H++}s.attributes=X,s.attributesNum=H,s.index=B}function _(){const v=s.newAttributes;for(let w=0,k=v.length;w<k;w++)v[w]=0}function m(v){p(v,0)}function p(v,w){const k=s.newAttributes,B=s.enabledAttributes,X=s.attributeDivisors;k[v]=1,B[v]===0&&(n.enableVertexAttribArray(v),B[v]=1),X[v]!==w&&(n.vertexAttribDivisor(v,w),X[v]=w)}function E(){const v=s.newAttributes,w=s.enabledAttributes;for(let k=0,B=w.length;k<B;k++)w[k]!==v[k]&&(n.disableVertexAttribArray(k),w[k]=0)}function S(v,w,k,B,X,J,H){H===!0?n.vertexAttribIPointer(v,w,k,X,J):n.vertexAttribPointer(v,w,k,B,X,J)}function y(v,w,k,B){_();const X=B.attributes,J=k.getAttributes(),H=w.defaultAttributeValues;for(const te in J){const I=J[te];if(I.location>=0){let Z=X[te];if(Z===void 0&&(te==="instanceMatrix"&&v.instanceMatrix&&(Z=v.instanceMatrix),te==="instanceColor"&&v.instanceColor&&(Z=v.instanceColor)),Z!==void 0){const Q=Z.normalized,se=Z.itemSize,Me=e.get(Z);if(Me===void 0)continue;const Je=Me.buffer,K=Me.type,re=Me.bytesPerElement,ne=K===n.INT||K===n.UNSIGNED_INT||Z.gpuType===Iu;if(Z.isInterleavedBufferAttribute){const ce=Z.data,Re=ce.stride,De=Z.offset;if(ce.isInstancedInterleavedBuffer){for(let ye=0;ye<I.locationSize;ye++)p(I.location+ye,ce.meshPerAttribute);v.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=ce.meshPerAttribute*ce.count)}else for(let ye=0;ye<I.locationSize;ye++)m(I.location+ye);n.bindBuffer(n.ARRAY_BUFFER,Je);for(let ye=0;ye<I.locationSize;ye++)S(I.location+ye,se/I.locationSize,K,Q,Re*re,(De+se/I.locationSize*ye)*re,ne)}else{if(Z.isInstancedBufferAttribute){for(let ce=0;ce<I.locationSize;ce++)p(I.location+ce,Z.meshPerAttribute);v.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=Z.meshPerAttribute*Z.count)}else for(let ce=0;ce<I.locationSize;ce++)m(I.location+ce);n.bindBuffer(n.ARRAY_BUFFER,Je);for(let ce=0;ce<I.locationSize;ce++)S(I.location+ce,se/I.locationSize,K,Q,se*re,se/I.locationSize*ce*re,ne)}}else if(H!==void 0){const Q=H[te];if(Q!==void 0)switch(Q.length){case 2:n.vertexAttrib2fv(I.location,Q);break;case 3:n.vertexAttrib3fv(I.location,Q);break;case 4:n.vertexAttrib4fv(I.location,Q);break;default:n.vertexAttrib1fv(I.location,Q)}}}}E()}function C(){P();for(const v in i){const w=i[v];for(const k in w){const B=w[k];for(const X in B)u(B[X].object),delete B[X];delete w[k]}delete i[v]}}function R(v){if(i[v.id]===void 0)return;const w=i[v.id];for(const k in w){const B=w[k];for(const X in B)u(B[X].object),delete B[X];delete w[k]}delete i[v.id]}function A(v){for(const w in i){const k=i[w];if(k[v.id]===void 0)continue;const B=k[v.id];for(const X in B)u(B[X].object),delete B[X];delete k[v.id]}}function P(){x(),o=!0,s!==r&&(s=r,c(s.object))}function x(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:a,reset:P,resetDefaultState:x,dispose:C,releaseStatesOfGeometry:R,releaseStatesOfProgram:A,initAttributes:_,enableAttribute:m,disableUnusedAttributes:E}}function Tx(n,e,t){let i;function r(c){i=c}function s(c,u){n.drawArrays(i,c,u),t.update(u,i,1)}function o(c,u,d){d!==0&&(n.drawArraysInstanced(i,c,u,d),t.update(u,i,d))}function a(c,u,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,c,0,u,0,d);let h=0;for(let g=0;g<d;g++)h+=u[g];t.update(h,i,1)}function l(c,u,d,f){if(d===0)return;const h=e.get("WEBGL_multi_draw");if(h===null)for(let g=0;g<c.length;g++)o(c[g],u[g],f[g]);else{h.multiDrawArraysInstancedWEBGL(i,c,0,u,0,f,0,d);let g=0;for(let _=0;_<d;_++)g+=u[_]*f[_];t.update(g,i,1)}}this.setMode=r,this.render=s,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function wx(n,e,t,i){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");r=n.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function o(A){return!(A!==Ln&&i.convert(A)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(A){const P=A===So&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(A!==mi&&i.convert(A)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==Hn&&!P)}function l(A){if(A==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const u=l(c);u!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",u,"instead."),c=u);const d=t.logarithmicDepthBuffer===!0,f=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),h=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),g=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=n.getParameter(n.MAX_TEXTURE_SIZE),m=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),p=n.getParameter(n.MAX_VERTEX_ATTRIBS),E=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),S=n.getParameter(n.MAX_VARYING_VECTORS),y=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),C=g>0,R=n.getParameter(n.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:d,reverseDepthBuffer:f,maxTextures:h,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:E,maxVaryings:S,maxFragmentUniforms:y,vertexTextures:C,maxSamples:R}}function Rx(n){const e=this;let t=null,i=0,r=!1,s=!1;const o=new nr,a=new We,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(d,f){const h=d.length!==0||f||i!==0||r;return r=f,i=d.length,h},this.beginShadows=function(){s=!0,u(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,f){t=u(d,f,0)},this.setState=function(d,f,h){const g=d.clippingPlanes,_=d.clipIntersection,m=d.clipShadows,p=n.get(d);if(!r||g===null||g.length===0||s&&!m)s?u(null):c();else{const E=s?0:i,S=E*4;let y=p.clippingState||null;l.value=y,y=u(g,f,S,h);for(let C=0;C!==S;++C)y[C]=t[C];p.clippingState=y,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=E}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function u(d,f,h,g){const _=d!==null?d.length:0;let m=null;if(_!==0){if(m=l.value,g!==!0||m===null){const p=h+_*4,E=f.matrixWorldInverse;a.getNormalMatrix(E),(m===null||m.length<p)&&(m=new Float32Array(p));for(let S=0,y=h;S!==_;++S,y+=4)o.copy(d[S]).applyMatrix4(E,a),o.normal.toArray(m,y),m[y+3]=o.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function Cx(n){let e=new WeakMap;function t(o,a){return a===Nc?o.mapping=fs:a===Uc&&(o.mapping=ds),o}function i(o){if(o&&o.isTexture){const a=o.mapping;if(a===Nc||a===Uc)if(e.has(o)){const l=e.get(o).texture;return t(l,o.mapping)}else{const l=o.image;if(l&&l.height>0){const c=new z_(l.height);return c.fromEquirectangularTexture(n,o),e.set(o,c),o.addEventListener("dispose",r),t(c.texture,o.mapping)}else return null}}return o}function r(o){const a=o.target;a.removeEventListener("dispose",r);const l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function s(){e=new WeakMap}return{get:i,dispose:s}}class Ip extends Rp{constructor(e=-1,t=1,i=1,r=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,o=i+e,a=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,o=s+c*this.view.width,a-=u*this.view.offsetY,l=a-u*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Zr=4,Yf=[.125,.215,.35,.446,.526,.582],sr=20,Bl=new Ip,Kf=new et;let zl=null,Hl=0,Vl=0,Gl=!1;const ir=(1+Math.sqrt(5))/2,kr=1/ir,Zf=[new z(-ir,kr,0),new z(ir,kr,0),new z(-kr,0,ir),new z(kr,0,ir),new z(0,ir,-kr),new z(0,ir,kr),new z(-1,1,-1),new z(1,1,-1),new z(-1,1,1),new z(1,1,1)];class $f{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,r=100){zl=this._renderer.getRenderTarget(),Hl=this._renderer.getActiveCubeFace(),Vl=this._renderer.getActiveMipmapLevel(),Gl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Qf(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Jf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(zl,Hl,Vl),this._renderer.xr.enabled=Gl,e.scissorTest=!1,Ko(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===fs||e.mapping===ds?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),zl=this._renderer.getRenderTarget(),Hl=this._renderer.getActiveCubeFace(),Vl=this._renderer.getActiveMipmapLevel(),Gl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:zn,minFilter:zn,generateMipmaps:!1,type:So,format:Ln,colorSpace:As,depthBuffer:!1},r=jf(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=jf(e,t,i);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Px(s)),this._blurMaterial=Ix(s,e,t)}return r}_compileMaterial(e){const t=new je(this._lodPlanes[0],e);this._renderer.compile(t,Bl)}_sceneToCubeUV(e,t,i,r){const a=new Mn(90,1,t,i),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(Kf),u.toneMapping=Bi,u.autoClear=!1;const h=new Wi({name:"PMREM.Background",side:sn,depthWrite:!1,depthTest:!1}),g=new je(new rn,h);let _=!1;const m=e.background;m?m.isColor&&(h.color.copy(m),e.background=null,_=!0):(h.color.copy(Kf),_=!0);for(let p=0;p<6;p++){const E=p%3;E===0?(a.up.set(0,l[p],0),a.lookAt(c[p],0,0)):E===1?(a.up.set(0,0,l[p]),a.lookAt(0,c[p],0)):(a.up.set(0,l[p],0),a.lookAt(0,0,c[p]));const S=this._cubeSize;Ko(r,E*S,p>2?S:0,S,S),u.setRenderTarget(r),_&&u.render(g,a),u.render(e,a)}g.geometry.dispose(),g.material.dispose(),u.toneMapping=f,u.autoClear=d,e.background=m}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===fs||e.mapping===ds;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Qf()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Jf());const s=r?this._cubemapMaterial:this._equirectMaterial,o=new je(this._lodPlanes[0],s),a=s.uniforms;a.envMap.value=e;const l=this._cubeSize;Ko(t,0,0,3*l,2*l),i.setRenderTarget(t),i.render(o,Bl)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const r=this._lodPlanes.length;for(let s=1;s<r;s++){const o=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=Zf[(r-s-1)%Zf.length];this._blur(e,s-1,s,o,a)}t.autoClear=i}_blur(e,t,i,r,s){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,i,r,"latitudinal",s),this._halfBlur(o,e,i,i,r,"longitudinal",s)}_halfBlur(e,t,i,r,s,o,a){const l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const u=3,d=new je(this._lodPlanes[r],c),f=c.uniforms,h=this._sizeLods[i]-1,g=isFinite(s)?Math.PI/(2*h):2*Math.PI/(2*sr-1),_=s/g,m=isFinite(s)?1+Math.floor(u*_):sr;m>sr&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${sr}`);const p=[];let E=0;for(let A=0;A<sr;++A){const P=A/_,x=Math.exp(-P*P/2);p.push(x),A===0?E+=x:A<m&&(E+=2*x)}for(let A=0;A<p.length;A++)p[A]=p[A]/E;f.envMap.value=e.texture,f.samples.value=m,f.weights.value=p,f.latitudinal.value=o==="latitudinal",a&&(f.poleAxis.value=a);const{_lodMax:S}=this;f.dTheta.value=g,f.mipInt.value=S-i;const y=this._sizeLods[r],C=3*y*(r>S-Zr?r-S+Zr:0),R=4*(this._cubeSize-y);Ko(t,C,R,3*y,2*y),l.setRenderTarget(t),l.render(d,Bl)}}function Px(n){const e=[],t=[],i=[];let r=n;const s=n-Zr+1+Yf.length;for(let o=0;o<s;o++){const a=Math.pow(2,r);t.push(a);let l=1/a;o>n-Zr?l=Yf[o-n+Zr-1]:o===0&&(l=0),i.push(l);const c=1/(a-2),u=-c,d=1+c,f=[u,u,d,u,d,d,u,u,d,d,u,d],h=6,g=6,_=3,m=2,p=1,E=new Float32Array(_*g*h),S=new Float32Array(m*g*h),y=new Float32Array(p*g*h);for(let R=0;R<h;R++){const A=R%3*2/3-1,P=R>2?0:-1,x=[A,P,0,A+2/3,P,0,A+2/3,P+1,0,A,P,0,A+2/3,P+1,0,A,P+1,0];E.set(x,_*g*R),S.set(f,m*g*R);const v=[R,R,R,R,R,R];y.set(v,p*g*R)}const C=new Jt;C.setAttribute("position",new bt(E,_)),C.setAttribute("uv",new bt(S,m)),C.setAttribute("faceIndex",new bt(y,p)),e.push(C),r>Zr&&r--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function jf(n,e,t){const i=new dr(n,e,t);return i.texture.mapping=$a,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Ko(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function Ix(n,e,t){const i=new Float32Array(sr),r=new z(0,1,0);return new gi({name:"SphericalGaussianBlur",defines:{n:sr,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:zu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:ki,depthTest:!1,depthWrite:!1})}function Jf(){return new gi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:zu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:ki,depthTest:!1,depthWrite:!1})}function Qf(){return new gi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:zu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:ki,depthTest:!1,depthWrite:!1})}function zu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Lx(n){let e=new WeakMap,t=null;function i(a){if(a&&a.isTexture){const l=a.mapping,c=l===Nc||l===Uc,u=l===fs||l===ds;if(c||u){let d=e.get(a);const f=d!==void 0?d.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==f)return t===null&&(t=new $f(n)),d=c?t.fromEquirectangular(a,d):t.fromCubemap(a,d),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),d.texture;if(d!==void 0)return d.texture;{const h=a.image;return c&&h&&h.height>0||u&&h&&r(h)?(t===null&&(t=new $f(n)),d=c?t.fromEquirectangular(a):t.fromCubemap(a),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),a.addEventListener("dispose",s),d.texture):null}}}return a}function r(a){let l=0;const c=6;for(let u=0;u<c;u++)a[u]!==void 0&&l++;return l===c}function s(a){const l=a.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:o}}function Dx(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let r;switch(i){case"WEBGL_depth_texture":r=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=n.getExtension(i)}return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const r=t(i);return r===null&&Js("THREE.WebGLRenderer: "+i+" extension not supported."),r}}}function Nx(n,e,t,i){const r={},s=new WeakMap;function o(d){const f=d.target;f.index!==null&&e.remove(f.index);for(const g in f.attributes)e.remove(f.attributes[g]);for(const g in f.morphAttributes){const _=f.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)e.remove(_[m])}f.removeEventListener("dispose",o),delete r[f.id];const h=s.get(f);h&&(e.remove(h),s.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,t.memory.geometries--}function a(d,f){return r[f.id]===!0||(f.addEventListener("dispose",o),r[f.id]=!0,t.memory.geometries++),f}function l(d){const f=d.attributes;for(const g in f)e.update(f[g],n.ARRAY_BUFFER);const h=d.morphAttributes;for(const g in h){const _=h[g];for(let m=0,p=_.length;m<p;m++)e.update(_[m],n.ARRAY_BUFFER)}}function c(d){const f=[],h=d.index,g=d.attributes.position;let _=0;if(h!==null){const E=h.array;_=h.version;for(let S=0,y=E.length;S<y;S+=3){const C=E[S+0],R=E[S+1],A=E[S+2];f.push(C,R,R,A,A,C)}}else if(g!==void 0){const E=g.array;_=g.version;for(let S=0,y=E.length/3-1;S<y;S+=3){const C=S+0,R=S+1,A=S+2;f.push(C,R,R,A,A,C)}}else return;const m=new(yp(f)?Tp:Ap)(f,1);m.version=_;const p=s.get(d);p&&e.remove(p),s.set(d,m)}function u(d){const f=s.get(d);if(f){const h=d.index;h!==null&&f.version<h.version&&c(d)}else c(d);return s.get(d)}return{get:a,update:l,getWireframeAttribute:u}}function Ux(n,e,t){let i;function r(f){i=f}let s,o;function a(f){s=f.type,o=f.bytesPerElement}function l(f,h){n.drawElements(i,h,s,f*o),t.update(h,i,1)}function c(f,h,g){g!==0&&(n.drawElementsInstanced(i,h,s,f*o,g),t.update(h,i,g))}function u(f,h,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,s,f,0,g);let m=0;for(let p=0;p<g;p++)m+=h[p];t.update(m,i,1)}function d(f,h,g,_){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<f.length;p++)c(f[p]/o,h[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(i,h,0,s,f,0,_,0,g);let p=0;for(let E=0;E<g;E++)p+=h[E]*_[E];t.update(p,i,1)}}this.setMode=r,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=u,this.renderMultiDrawInstances=d}function Ox(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,o,a){switch(t.calls++,o){case n.TRIANGLES:t.triangles+=a*(s/3);break;case n.LINES:t.lines+=a*(s/2);break;case n.LINE_STRIP:t.lines+=a*(s-1);break;case n.LINE_LOOP:t.lines+=a*s;break;case n.POINTS:t.points+=a*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function Fx(n,e,t){const i=new WeakMap,r=new Ut;function s(o,a,l){const c=o.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=u!==void 0?u.length:0;let f=i.get(a);if(f===void 0||f.count!==d){let x=function(){A.dispose(),i.delete(a),a.removeEventListener("dispose",x)};f!==void 0&&f.texture.dispose();const h=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],E=a.morphAttributes.color||[];let S=0;h===!0&&(S=1),g===!0&&(S=2),_===!0&&(S=3);let y=a.attributes.position.count*S,C=1;y>e.maxTextureSize&&(C=Math.ceil(y/e.maxTextureSize),y=e.maxTextureSize);const R=new Float32Array(y*C*4*d),A=new ku(R,y,C,d);A.type=Hn,A.needsUpdate=!0;const P=S*4;for(let v=0;v<d;v++){const w=m[v],k=p[v],B=E[v],X=y*C*4*v;for(let J=0;J<w.count;J++){const H=J*P;h===!0&&(r.fromBufferAttribute(w,J),R[X+H+0]=r.x,R[X+H+1]=r.y,R[X+H+2]=r.z,R[X+H+3]=0),g===!0&&(r.fromBufferAttribute(k,J),R[X+H+4]=r.x,R[X+H+5]=r.y,R[X+H+6]=r.z,R[X+H+7]=0),_===!0&&(r.fromBufferAttribute(B,J),R[X+H+8]=r.x,R[X+H+9]=r.y,R[X+H+10]=r.z,R[X+H+11]=B.itemSize===4?r.w:1)}}f={count:d,texture:A,size:new nt(y,C)},i.set(a,f),a.addEventListener("dispose",x)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(n,"morphTexture",o.morphTexture,t);else{let h=0;for(let _=0;_<c.length;_++)h+=c[_];const g=a.morphTargetsRelative?1:1-h;l.getUniforms().setValue(n,"morphTargetBaseInfluence",g),l.getUniforms().setValue(n,"morphTargetInfluences",c)}l.getUniforms().setValue(n,"morphTargetsTexture",f.texture,t),l.getUniforms().setValue(n,"morphTargetsTextureSize",f.size)}return{update:s}}function kx(n,e,t,i){let r=new WeakMap;function s(l){const c=i.render.frame,u=l.geometry,d=e.get(l,u);if(r.get(d)!==c&&(e.update(d),r.set(d,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),r.get(l)!==c&&(t.update(l.instanceMatrix,n.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,n.ARRAY_BUFFER),r.set(l,c))),l.isSkinnedMesh){const f=l.skeleton;r.get(f)!==c&&(f.update(),r.set(f,c))}return d}function o(){r=new WeakMap}function a(l){const c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:o}}class Lp extends Qt{constructor(e,t,i,r,s,o,a,l,c,u=es){if(u!==es&&u!==ps)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&u===es&&(i=fr),i===void 0&&u===ps&&(i=hs),super(null,r,s,o,a,l,u,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:zt,this.minFilter=l!==void 0?l:zt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const Dp=new Qt,ed=new Lp(1,1),Np=new ku,Up=new E_,Op=new Cp,td=[],nd=[],id=new Float32Array(16),rd=new Float32Array(9),sd=new Float32Array(4);function Rs(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=td[r];if(s===void 0&&(s=new Float32Array(r),td[r]=s),e!==0){i.toArray(s,0);for(let o=1,a=0;o!==e;++o)a+=t,n[o].toArray(s,a)}return s}function Ht(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function Vt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Ja(n,e){let t=nd[e];t===void 0&&(t=new Int32Array(e),nd[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function Bx(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function zx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ht(t,e))return;n.uniform2fv(this.addr,e),Vt(t,e)}}function Hx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Ht(t,e))return;n.uniform3fv(this.addr,e),Vt(t,e)}}function Vx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ht(t,e))return;n.uniform4fv(this.addr,e),Vt(t,e)}}function Gx(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Ht(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),Vt(t,e)}else{if(Ht(t,i))return;sd.set(i),n.uniformMatrix2fv(this.addr,!1,sd),Vt(t,i)}}function Wx(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Ht(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),Vt(t,e)}else{if(Ht(t,i))return;rd.set(i),n.uniformMatrix3fv(this.addr,!1,rd),Vt(t,i)}}function Xx(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Ht(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),Vt(t,e)}else{if(Ht(t,i))return;id.set(i),n.uniformMatrix4fv(this.addr,!1,id),Vt(t,i)}}function qx(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function Yx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ht(t,e))return;n.uniform2iv(this.addr,e),Vt(t,e)}}function Kx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ht(t,e))return;n.uniform3iv(this.addr,e),Vt(t,e)}}function Zx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ht(t,e))return;n.uniform4iv(this.addr,e),Vt(t,e)}}function $x(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function jx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ht(t,e))return;n.uniform2uiv(this.addr,e),Vt(t,e)}}function Jx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ht(t,e))return;n.uniform3uiv(this.addr,e),Vt(t,e)}}function Qx(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ht(t,e))return;n.uniform4uiv(this.addr,e),Vt(t,e)}}function eS(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);let s;this.type===n.SAMPLER_2D_SHADOW?(ed.compareFunction=Sp,s=ed):s=Dp,t.setTexture2D(e||s,r)}function tS(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||Up,r)}function nS(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||Op,r)}function iS(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||Np,r)}function rS(n){switch(n){case 5126:return Bx;case 35664:return zx;case 35665:return Hx;case 35666:return Vx;case 35674:return Gx;case 35675:return Wx;case 35676:return Xx;case 5124:case 35670:return qx;case 35667:case 35671:return Yx;case 35668:case 35672:return Kx;case 35669:case 35673:return Zx;case 5125:return $x;case 36294:return jx;case 36295:return Jx;case 36296:return Qx;case 35678:case 36198:case 36298:case 36306:case 35682:return eS;case 35679:case 36299:case 36307:return tS;case 35680:case 36300:case 36308:case 36293:return nS;case 36289:case 36303:case 36311:case 36292:return iS}}function sS(n,e){n.uniform1fv(this.addr,e)}function oS(n,e){const t=Rs(e,this.size,2);n.uniform2fv(this.addr,t)}function aS(n,e){const t=Rs(e,this.size,3);n.uniform3fv(this.addr,t)}function lS(n,e){const t=Rs(e,this.size,4);n.uniform4fv(this.addr,t)}function cS(n,e){const t=Rs(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function uS(n,e){const t=Rs(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function fS(n,e){const t=Rs(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function dS(n,e){n.uniform1iv(this.addr,e)}function hS(n,e){n.uniform2iv(this.addr,e)}function pS(n,e){n.uniform3iv(this.addr,e)}function mS(n,e){n.uniform4iv(this.addr,e)}function gS(n,e){n.uniform1uiv(this.addr,e)}function _S(n,e){n.uniform2uiv(this.addr,e)}function vS(n,e){n.uniform3uiv(this.addr,e)}function xS(n,e){n.uniform4uiv(this.addr,e)}function SS(n,e,t){const i=this.cache,r=e.length,s=Ja(t,r);Ht(i,s)||(n.uniform1iv(this.addr,s),Vt(i,s));for(let o=0;o!==r;++o)t.setTexture2D(e[o]||Dp,s[o])}function yS(n,e,t){const i=this.cache,r=e.length,s=Ja(t,r);Ht(i,s)||(n.uniform1iv(this.addr,s),Vt(i,s));for(let o=0;o!==r;++o)t.setTexture3D(e[o]||Up,s[o])}function MS(n,e,t){const i=this.cache,r=e.length,s=Ja(t,r);Ht(i,s)||(n.uniform1iv(this.addr,s),Vt(i,s));for(let o=0;o!==r;++o)t.setTextureCube(e[o]||Op,s[o])}function ES(n,e,t){const i=this.cache,r=e.length,s=Ja(t,r);Ht(i,s)||(n.uniform1iv(this.addr,s),Vt(i,s));for(let o=0;o!==r;++o)t.setTexture2DArray(e[o]||Np,s[o])}function bS(n){switch(n){case 5126:return sS;case 35664:return oS;case 35665:return aS;case 35666:return lS;case 35674:return cS;case 35675:return uS;case 35676:return fS;case 5124:case 35670:return dS;case 35667:case 35671:return hS;case 35668:case 35672:return pS;case 35669:case 35673:return mS;case 5125:return gS;case 36294:return _S;case 36295:return vS;case 36296:return xS;case 35678:case 36198:case 36298:case 36306:case 35682:return SS;case 35679:case 36299:case 36307:return yS;case 35680:case 36300:case 36308:case 36293:return MS;case 36289:case 36303:case 36311:case 36292:return ES}}class AS{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=rS(t.type)}}class TS{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=bS(t.type)}}class wS{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,o=r.length;s!==o;++s){const a=r[s];a.setValue(e,t[a.id],i)}}}const Wl=/(\w+)(\])?(\[|\.)?/g;function od(n,e){n.seq.push(e),n.map[e.id]=e}function RS(n,e,t){const i=n.name,r=i.length;for(Wl.lastIndex=0;;){const s=Wl.exec(i),o=Wl.lastIndex;let a=s[1];const l=s[2]==="]",c=s[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===r){od(t,c===void 0?new AS(a,n,e):new TS(a,n,e));break}else{let d=t.map[a];d===void 0&&(d=new wS(a),od(t,d)),t=d}}}class ba{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<i;++r){const s=e.getActiveUniform(t,r),o=e.getUniformLocation(t,s.name);RS(s,o,this)}}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,o=t.length;s!==o;++s){const a=t[s],l=i[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const o=e[r];o.id in t&&i.push(o)}return i}}function ad(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const CS=37297;let PS=0;function IS(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=r;o<s;o++){const a=o+1;i.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return i.join(`
`)}const ld=new We;function LS(n){at._getMatrix(ld,at.workingColorSpace,n);const e=`mat3( ${ld.elements.map(t=>t.toFixed(4))} )`;switch(at.getTransfer(n)){case ja:return[e,"LinearTransferOETF"];case gt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function cd(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=n.getShaderInfoLog(e).trim();if(i&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const o=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+IS(n.getShaderSource(e),o)}else return r}function DS(n,e){const t=LS(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function NS(n,e){let t;switch(e){case $g:t="Linear";break;case jg:t="Reinhard";break;case Jg:t="Cineon";break;case Qg:t="ACESFilmic";break;case t_:t="AgX";break;case n_:t="Neutral";break;case e_:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Zo=new z;function US(){at.getLuminanceCoefficients(Zo);const n=Zo.x.toFixed(4),e=Zo.y.toFixed(4),t=Zo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function OS(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Qs).join(`
`)}function FS(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function kS(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),o=s.name;let a=1;s.type===n.FLOAT_MAT2&&(a=2),s.type===n.FLOAT_MAT3&&(a=3),s.type===n.FLOAT_MAT4&&(a=4),t[o]={type:s.type,location:n.getAttribLocation(e,o),locationSize:a}}return t}function Qs(n){return n!==""}function ud(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function fd(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const BS=/^[ \t]*#include +<([\w\d./]+)>/gm;function fu(n){return n.replace(BS,HS)}const zS=new Map;function HS(n,e){let t=qe[e];if(t===void 0){const i=zS.get(e);if(i!==void 0)t=qe[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return fu(t)}const VS=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function dd(n){return n.replace(VS,GS)}function GS(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function hd(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function WS(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Cu?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===Cg?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===si&&(e="SHADOWMAP_TYPE_VSM"),e}function XS(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case fs:case ds:e="ENVMAP_TYPE_CUBE";break;case $a:e="ENVMAP_TYPE_CUBE_UV";break}return e}function qS(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case ds:e="ENVMAP_MODE_REFRACTION";break}return e}function YS(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Pu:e="ENVMAP_BLENDING_MULTIPLY";break;case Kg:e="ENVMAP_BLENDING_MIX";break;case Zg:e="ENVMAP_BLENDING_ADD";break}return e}function KS(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:i,maxMip:t}}function ZS(n,e,t,i){const r=n.getContext(),s=t.defines;let o=t.vertexShader,a=t.fragmentShader;const l=WS(t),c=XS(t),u=qS(t),d=YS(t),f=KS(t),h=OS(t),g=FS(s),_=r.createProgram();let m,p,E=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Qs).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Qs).join(`
`),p.length>0&&(p+=`
`)):(m=[hd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Qs).join(`
`),p=[hd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+u:"",t.envMap?"#define "+d:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Bi?"#define TONE_MAPPING":"",t.toneMapping!==Bi?qe.tonemapping_pars_fragment:"",t.toneMapping!==Bi?NS("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,DS("linearToOutputTexel",t.outputColorSpace),US(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Qs).join(`
`)),o=fu(o),o=ud(o,t),o=fd(o,t),a=fu(a),a=ud(a,t),a=fd(a,t),o=dd(o),a=dd(a),t.isRawShaderMaterial!==!0&&(E=`#version 300 es
`,m=[h,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===Tf?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Tf?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const S=E+m+o,y=E+p+a,C=ad(r,r.VERTEX_SHADER,S),R=ad(r,r.FRAGMENT_SHADER,y);r.attachShader(_,C),r.attachShader(_,R),t.index0AttributeName!==void 0?r.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(_,0,"position"),r.linkProgram(_);function A(w){if(n.debug.checkShaderErrors){const k=r.getProgramInfoLog(_).trim(),B=r.getShaderInfoLog(C).trim(),X=r.getShaderInfoLog(R).trim();let J=!0,H=!0;if(r.getProgramParameter(_,r.LINK_STATUS)===!1)if(J=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,_,C,R);else{const te=cd(r,C,"vertex"),I=cd(r,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(_,r.VALIDATE_STATUS)+`

Material Name: `+w.name+`
Material Type: `+w.type+`

Program Info Log: `+k+`
`+te+`
`+I)}else k!==""?console.warn("THREE.WebGLProgram: Program Info Log:",k):(B===""||X==="")&&(H=!1);H&&(w.diagnostics={runnable:J,programLog:k,vertexShader:{log:B,prefix:m},fragmentShader:{log:X,prefix:p}})}r.deleteShader(C),r.deleteShader(R),P=new ba(r,_),x=kS(r,_)}let P;this.getUniforms=function(){return P===void 0&&A(this),P};let x;this.getAttributes=function(){return x===void 0&&A(this),x};let v=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return v===!1&&(v=r.getProgramParameter(_,CS)),v},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=PS++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=C,this.fragmentShader=R,this}let $S=0;class jS{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(i),o=this._getShaderCacheForMaterial(e);return o.has(r)===!1&&(o.add(r),r.usedTimes++),o.has(s)===!1&&(o.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new JS(e),t.set(e,i)),i}}class JS{constructor(e){this.id=$S++,this.code=e,this.usedTimes=0}}function QS(n,e,t,i,r,s,o){const a=new Ep,l=new jS,c=new Set,u=[],d=r.logarithmicDepthBuffer,f=r.vertexTextures;let h=r.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(x){return c.add(x),x===0?"uv":`uv${x}`}function m(x,v,w,k,B){const X=k.fog,J=B.geometry,H=x.isMeshStandardMaterial?k.environment:null,te=(x.isMeshStandardMaterial?t:e).get(x.envMap||H),I=te&&te.mapping===$a?te.image.height:null,Z=g[x.type];x.precision!==null&&(h=r.getMaxPrecision(x.precision),h!==x.precision&&console.warn("THREE.WebGLProgram.getParameters:",x.precision,"not supported, using",h,"instead."));const Q=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,se=Q!==void 0?Q.length:0;let Me=0;J.morphAttributes.position!==void 0&&(Me=1),J.morphAttributes.normal!==void 0&&(Me=2),J.morphAttributes.color!==void 0&&(Me=3);let Je,K,re,ne;if(Z){const pt=Fn[Z];Je=pt.vertexShader,K=pt.fragmentShader}else Je=x.vertexShader,K=x.fragmentShader,l.update(x),re=l.getVertexShaderID(x),ne=l.getFragmentShaderID(x);const ce=n.getRenderTarget(),Re=n.state.buffers.depth.getReversed(),De=B.isInstancedMesh===!0,ye=B.isBatchedMesh===!0,xt=!!x.map,Ke=!!x.matcap,yt=!!te,D=!!x.aoMap,Ot=!!x.lightMap,Ze=!!x.bumpMap,ze=!!x.normalMap,Te=!!x.displacementMap,ct=!!x.emissiveMap,Pe=!!x.metalnessMap,T=!!x.roughnessMap,M=x.anisotropy>0,F=x.clearcoat>0,Y=x.dispersion>0,$=x.iridescence>0,q=x.sheen>0,ve=x.transmission>0,de=M&&!!x.anisotropyMap,_e=F&&!!x.clearcoatMap,ot=F&&!!x.clearcoatNormalMap,oe=F&&!!x.clearcoatRoughnessMap,xe=$&&!!x.iridescenceMap,Le=$&&!!x.iridescenceThicknessMap,Oe=q&&!!x.sheenColorMap,Se=q&&!!x.sheenRoughnessMap,rt=!!x.specularMap,Xe=!!x.specularColorMap,Mt=!!x.specularIntensityMap,L=ve&&!!x.transmissionMap,fe=ve&&!!x.thicknessMap,W=!!x.gradientMap,ee=!!x.alphaMap,me=x.alphaTest>0,he=!!x.alphaHash,Ve=!!x.extensions;let Lt=Bi;x.toneMapped&&(ce===null||ce.isXRRenderTarget===!0)&&(Lt=n.toneMapping);const Yt={shaderID:Z,shaderType:x.type,shaderName:x.name,vertexShader:Je,fragmentShader:K,defines:x.defines,customVertexShaderID:re,customFragmentShaderID:ne,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:h,batching:ye,batchingColor:ye&&B._colorsTexture!==null,instancing:De,instancingColor:De&&B.instanceColor!==null,instancingMorph:De&&B.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:ce===null?n.outputColorSpace:ce.isXRRenderTarget===!0?ce.texture.colorSpace:As,alphaToCoverage:!!x.alphaToCoverage,map:xt,matcap:Ke,envMap:yt,envMapMode:yt&&te.mapping,envMapCubeUVHeight:I,aoMap:D,lightMap:Ot,bumpMap:Ze,normalMap:ze,displacementMap:f&&Te,emissiveMap:ct,normalMapObjectSpace:ze&&x.normalMapType===o_,normalMapTangentSpace:ze&&x.normalMapType===xp,metalnessMap:Pe,roughnessMap:T,anisotropy:M,anisotropyMap:de,clearcoat:F,clearcoatMap:_e,clearcoatNormalMap:ot,clearcoatRoughnessMap:oe,dispersion:Y,iridescence:$,iridescenceMap:xe,iridescenceThicknessMap:Le,sheen:q,sheenColorMap:Oe,sheenRoughnessMap:Se,specularMap:rt,specularColorMap:Xe,specularIntensityMap:Mt,transmission:ve,transmissionMap:L,thicknessMap:fe,gradientMap:W,opaque:x.transparent===!1&&x.blending===Qr&&x.alphaToCoverage===!1,alphaMap:ee,alphaTest:me,alphaHash:he,combine:x.combine,mapUv:xt&&_(x.map.channel),aoMapUv:D&&_(x.aoMap.channel),lightMapUv:Ot&&_(x.lightMap.channel),bumpMapUv:Ze&&_(x.bumpMap.channel),normalMapUv:ze&&_(x.normalMap.channel),displacementMapUv:Te&&_(x.displacementMap.channel),emissiveMapUv:ct&&_(x.emissiveMap.channel),metalnessMapUv:Pe&&_(x.metalnessMap.channel),roughnessMapUv:T&&_(x.roughnessMap.channel),anisotropyMapUv:de&&_(x.anisotropyMap.channel),clearcoatMapUv:_e&&_(x.clearcoatMap.channel),clearcoatNormalMapUv:ot&&_(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:oe&&_(x.clearcoatRoughnessMap.channel),iridescenceMapUv:xe&&_(x.iridescenceMap.channel),iridescenceThicknessMapUv:Le&&_(x.iridescenceThicknessMap.channel),sheenColorMapUv:Oe&&_(x.sheenColorMap.channel),sheenRoughnessMapUv:Se&&_(x.sheenRoughnessMap.channel),specularMapUv:rt&&_(x.specularMap.channel),specularColorMapUv:Xe&&_(x.specularColorMap.channel),specularIntensityMapUv:Mt&&_(x.specularIntensityMap.channel),transmissionMapUv:L&&_(x.transmissionMap.channel),thicknessMapUv:fe&&_(x.thicknessMap.channel),alphaMapUv:ee&&_(x.alphaMap.channel),vertexTangents:!!J.attributes.tangent&&(ze||M),vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,pointsUvs:B.isPoints===!0&&!!J.attributes.uv&&(xt||ee),fog:!!X,useFog:x.fog===!0,fogExp2:!!X&&X.isFogExp2,flatShading:x.flatShading===!0,sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:d,reverseDepthBuffer:Re,skinning:B.isSkinnedMesh===!0,morphTargets:J.morphAttributes.position!==void 0,morphNormals:J.morphAttributes.normal!==void 0,morphColors:J.morphAttributes.color!==void 0,morphTargetsCount:se,morphTextureStride:Me,numDirLights:v.directional.length,numPointLights:v.point.length,numSpotLights:v.spot.length,numSpotLightMaps:v.spotLightMap.length,numRectAreaLights:v.rectArea.length,numHemiLights:v.hemi.length,numDirLightShadows:v.directionalShadowMap.length,numPointLightShadows:v.pointShadowMap.length,numSpotLightShadows:v.spotShadowMap.length,numSpotLightShadowsWithMaps:v.numSpotLightShadowsWithMaps,numLightProbes:v.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:x.dithering,shadowMapEnabled:n.shadowMap.enabled&&w.length>0,shadowMapType:n.shadowMap.type,toneMapping:Lt,decodeVideoTexture:xt&&x.map.isVideoTexture===!0&&at.getTransfer(x.map.colorSpace)===gt,decodeVideoTextureEmissive:ct&&x.emissiveMap.isVideoTexture===!0&&at.getTransfer(x.emissiveMap.colorSpace)===gt,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===gn,flipSided:x.side===sn,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:Ve&&x.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ve&&x.extensions.multiDraw===!0||ye)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Yt.vertexUv1s=c.has(1),Yt.vertexUv2s=c.has(2),Yt.vertexUv3s=c.has(3),c.clear(),Yt}function p(x){const v=[];if(x.shaderID?v.push(x.shaderID):(v.push(x.customVertexShaderID),v.push(x.customFragmentShaderID)),x.defines!==void 0)for(const w in x.defines)v.push(w),v.push(x.defines[w]);return x.isRawShaderMaterial===!1&&(E(v,x),S(v,x),v.push(n.outputColorSpace)),v.push(x.customProgramCacheKey),v.join()}function E(x,v){x.push(v.precision),x.push(v.outputColorSpace),x.push(v.envMapMode),x.push(v.envMapCubeUVHeight),x.push(v.mapUv),x.push(v.alphaMapUv),x.push(v.lightMapUv),x.push(v.aoMapUv),x.push(v.bumpMapUv),x.push(v.normalMapUv),x.push(v.displacementMapUv),x.push(v.emissiveMapUv),x.push(v.metalnessMapUv),x.push(v.roughnessMapUv),x.push(v.anisotropyMapUv),x.push(v.clearcoatMapUv),x.push(v.clearcoatNormalMapUv),x.push(v.clearcoatRoughnessMapUv),x.push(v.iridescenceMapUv),x.push(v.iridescenceThicknessMapUv),x.push(v.sheenColorMapUv),x.push(v.sheenRoughnessMapUv),x.push(v.specularMapUv),x.push(v.specularColorMapUv),x.push(v.specularIntensityMapUv),x.push(v.transmissionMapUv),x.push(v.thicknessMapUv),x.push(v.combine),x.push(v.fogExp2),x.push(v.sizeAttenuation),x.push(v.morphTargetsCount),x.push(v.morphAttributeCount),x.push(v.numDirLights),x.push(v.numPointLights),x.push(v.numSpotLights),x.push(v.numSpotLightMaps),x.push(v.numHemiLights),x.push(v.numRectAreaLights),x.push(v.numDirLightShadows),x.push(v.numPointLightShadows),x.push(v.numSpotLightShadows),x.push(v.numSpotLightShadowsWithMaps),x.push(v.numLightProbes),x.push(v.shadowMapType),x.push(v.toneMapping),x.push(v.numClippingPlanes),x.push(v.numClipIntersection),x.push(v.depthPacking)}function S(x,v){a.disableAll(),v.supportsVertexTextures&&a.enable(0),v.instancing&&a.enable(1),v.instancingColor&&a.enable(2),v.instancingMorph&&a.enable(3),v.matcap&&a.enable(4),v.envMap&&a.enable(5),v.normalMapObjectSpace&&a.enable(6),v.normalMapTangentSpace&&a.enable(7),v.clearcoat&&a.enable(8),v.iridescence&&a.enable(9),v.alphaTest&&a.enable(10),v.vertexColors&&a.enable(11),v.vertexAlphas&&a.enable(12),v.vertexUv1s&&a.enable(13),v.vertexUv2s&&a.enable(14),v.vertexUv3s&&a.enable(15),v.vertexTangents&&a.enable(16),v.anisotropy&&a.enable(17),v.alphaHash&&a.enable(18),v.batching&&a.enable(19),v.dispersion&&a.enable(20),v.batchingColor&&a.enable(21),x.push(a.mask),a.disableAll(),v.fog&&a.enable(0),v.useFog&&a.enable(1),v.flatShading&&a.enable(2),v.logarithmicDepthBuffer&&a.enable(3),v.reverseDepthBuffer&&a.enable(4),v.skinning&&a.enable(5),v.morphTargets&&a.enable(6),v.morphNormals&&a.enable(7),v.morphColors&&a.enable(8),v.premultipliedAlpha&&a.enable(9),v.shadowMapEnabled&&a.enable(10),v.doubleSided&&a.enable(11),v.flipSided&&a.enable(12),v.useDepthPacking&&a.enable(13),v.dithering&&a.enable(14),v.transmission&&a.enable(15),v.sheen&&a.enable(16),v.opaque&&a.enable(17),v.pointsUvs&&a.enable(18),v.decodeVideoTexture&&a.enable(19),v.decodeVideoTextureEmissive&&a.enable(20),v.alphaToCoverage&&a.enable(21),x.push(a.mask)}function y(x){const v=g[x.type];let w;if(v){const k=Fn[v];w=O_.clone(k.uniforms)}else w=x.uniforms;return w}function C(x,v){let w;for(let k=0,B=u.length;k<B;k++){const X=u[k];if(X.cacheKey===v){w=X,++w.usedTimes;break}}return w===void 0&&(w=new ZS(n,v,x,s),u.push(w)),w}function R(x){if(--x.usedTimes===0){const v=u.indexOf(x);u[v]=u[u.length-1],u.pop(),x.destroy()}}function A(x){l.remove(x)}function P(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:y,acquireProgram:C,releaseProgram:R,releaseShaderCache:A,programs:u,dispose:P}}function ey(){let n=new WeakMap;function e(o){return n.has(o)}function t(o){let a=n.get(o);return a===void 0&&(a={},n.set(o,a)),a}function i(o){n.delete(o)}function r(o,a,l){n.get(o)[a]=l}function s(){n=new WeakMap}return{has:e,get:t,remove:i,update:r,dispose:s}}function ty(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function pd(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function md(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function o(d,f,h,g,_,m){let p=n[e];return p===void 0?(p={id:d.id,object:d,geometry:f,material:h,groupOrder:g,renderOrder:d.renderOrder,z:_,group:m},n[e]=p):(p.id=d.id,p.object=d,p.geometry=f,p.material=h,p.groupOrder=g,p.renderOrder=d.renderOrder,p.z=_,p.group=m),e++,p}function a(d,f,h,g,_,m){const p=o(d,f,h,g,_,m);h.transmission>0?i.push(p):h.transparent===!0?r.push(p):t.push(p)}function l(d,f,h,g,_,m){const p=o(d,f,h,g,_,m);h.transmission>0?i.unshift(p):h.transparent===!0?r.unshift(p):t.unshift(p)}function c(d,f){t.length>1&&t.sort(d||ty),i.length>1&&i.sort(f||pd),r.length>1&&r.sort(f||pd)}function u(){for(let d=e,f=n.length;d<f;d++){const h=n[d];if(h.id===null)break;h.id=null,h.object=null,h.geometry=null,h.material=null,h.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:a,unshift:l,finish:u,sort:c}}function ny(){let n=new WeakMap;function e(i,r){const s=n.get(i);let o;return s===void 0?(o=new md,n.set(i,[o])):r>=s.length?(o=new md,s.push(o)):o=s[r],o}function t(){n=new WeakMap}return{get:e,dispose:t}}function iy(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new z,color:new et};break;case"SpotLight":t={position:new z,direction:new z,color:new et,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new z,color:new et,distance:0,decay:0};break;case"HemisphereLight":t={direction:new z,skyColor:new et,groundColor:new et};break;case"RectAreaLight":t={color:new et,position:new z,halfWidth:new z,halfHeight:new z};break}return n[e.id]=t,t}}}function ry(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new nt};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new nt};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new nt,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let sy=0;function oy(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function ay(n){const e=new iy,t=ry(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new z);const r=new z,s=new St,o=new St;function a(c){let u=0,d=0,f=0;for(let x=0;x<9;x++)i.probe[x].set(0,0,0);let h=0,g=0,_=0,m=0,p=0,E=0,S=0,y=0,C=0,R=0,A=0;c.sort(oy);for(let x=0,v=c.length;x<v;x++){const w=c[x],k=w.color,B=w.intensity,X=w.distance,J=w.shadow&&w.shadow.map?w.shadow.map.texture:null;if(w.isAmbientLight)u+=k.r*B,d+=k.g*B,f+=k.b*B;else if(w.isLightProbe){for(let H=0;H<9;H++)i.probe[H].addScaledVector(w.sh.coefficients[H],B);A++}else if(w.isDirectionalLight){const H=e.get(w);if(H.color.copy(w.color).multiplyScalar(w.intensity),w.castShadow){const te=w.shadow,I=t.get(w);I.shadowIntensity=te.intensity,I.shadowBias=te.bias,I.shadowNormalBias=te.normalBias,I.shadowRadius=te.radius,I.shadowMapSize=te.mapSize,i.directionalShadow[h]=I,i.directionalShadowMap[h]=J,i.directionalShadowMatrix[h]=w.shadow.matrix,E++}i.directional[h]=H,h++}else if(w.isSpotLight){const H=e.get(w);H.position.setFromMatrixPosition(w.matrixWorld),H.color.copy(k).multiplyScalar(B),H.distance=X,H.coneCos=Math.cos(w.angle),H.penumbraCos=Math.cos(w.angle*(1-w.penumbra)),H.decay=w.decay,i.spot[_]=H;const te=w.shadow;if(w.map&&(i.spotLightMap[C]=w.map,C++,te.updateMatrices(w),w.castShadow&&R++),i.spotLightMatrix[_]=te.matrix,w.castShadow){const I=t.get(w);I.shadowIntensity=te.intensity,I.shadowBias=te.bias,I.shadowNormalBias=te.normalBias,I.shadowRadius=te.radius,I.shadowMapSize=te.mapSize,i.spotShadow[_]=I,i.spotShadowMap[_]=J,y++}_++}else if(w.isRectAreaLight){const H=e.get(w);H.color.copy(k).multiplyScalar(B),H.halfWidth.set(w.width*.5,0,0),H.halfHeight.set(0,w.height*.5,0),i.rectArea[m]=H,m++}else if(w.isPointLight){const H=e.get(w);if(H.color.copy(w.color).multiplyScalar(w.intensity),H.distance=w.distance,H.decay=w.decay,w.castShadow){const te=w.shadow,I=t.get(w);I.shadowIntensity=te.intensity,I.shadowBias=te.bias,I.shadowNormalBias=te.normalBias,I.shadowRadius=te.radius,I.shadowMapSize=te.mapSize,I.shadowCameraNear=te.camera.near,I.shadowCameraFar=te.camera.far,i.pointShadow[g]=I,i.pointShadowMap[g]=J,i.pointShadowMatrix[g]=w.shadow.matrix,S++}i.point[g]=H,g++}else if(w.isHemisphereLight){const H=e.get(w);H.skyColor.copy(w.color).multiplyScalar(B),H.groundColor.copy(w.groundColor).multiplyScalar(B),i.hemi[p]=H,p++}}m>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ue.LTC_FLOAT_1,i.rectAreaLTC2=ue.LTC_FLOAT_2):(i.rectAreaLTC1=ue.LTC_HALF_1,i.rectAreaLTC2=ue.LTC_HALF_2)),i.ambient[0]=u,i.ambient[1]=d,i.ambient[2]=f;const P=i.hash;(P.directionalLength!==h||P.pointLength!==g||P.spotLength!==_||P.rectAreaLength!==m||P.hemiLength!==p||P.numDirectionalShadows!==E||P.numPointShadows!==S||P.numSpotShadows!==y||P.numSpotMaps!==C||P.numLightProbes!==A)&&(i.directional.length=h,i.spot.length=_,i.rectArea.length=m,i.point.length=g,i.hemi.length=p,i.directionalShadow.length=E,i.directionalShadowMap.length=E,i.pointShadow.length=S,i.pointShadowMap.length=S,i.spotShadow.length=y,i.spotShadowMap.length=y,i.directionalShadowMatrix.length=E,i.pointShadowMatrix.length=S,i.spotLightMatrix.length=y+C-R,i.spotLightMap.length=C,i.numSpotLightShadowsWithMaps=R,i.numLightProbes=A,P.directionalLength=h,P.pointLength=g,P.spotLength=_,P.rectAreaLength=m,P.hemiLength=p,P.numDirectionalShadows=E,P.numPointShadows=S,P.numSpotShadows=y,P.numSpotMaps=C,P.numLightProbes=A,i.version=sy++)}function l(c,u){let d=0,f=0,h=0,g=0,_=0;const m=u.matrixWorldInverse;for(let p=0,E=c.length;p<E;p++){const S=c[p];if(S.isDirectionalLight){const y=i.directional[d];y.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),y.direction.sub(r),y.direction.transformDirection(m),d++}else if(S.isSpotLight){const y=i.spot[h];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),y.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),y.direction.sub(r),y.direction.transformDirection(m),h++}else if(S.isRectAreaLight){const y=i.rectArea[g];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),o.identity(),s.copy(S.matrixWorld),s.premultiply(m),o.extractRotation(s),y.halfWidth.set(S.width*.5,0,0),y.halfHeight.set(0,S.height*.5,0),y.halfWidth.applyMatrix4(o),y.halfHeight.applyMatrix4(o),g++}else if(S.isPointLight){const y=i.point[f];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),f++}else if(S.isHemisphereLight){const y=i.hemi[_];y.direction.setFromMatrixPosition(S.matrixWorld),y.direction.transformDirection(m),_++}}}return{setup:a,setupView:l,state:i}}function gd(n){const e=new ay(n),t=[],i=[];function r(u){c.camera=u,t.length=0,i.length=0}function s(u){t.push(u)}function o(u){i.push(u)}function a(){e.setup(t)}function l(u){e.setupView(t,u)}const c={lightsArray:t,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:c,setupLights:a,setupLightsView:l,pushLight:s,pushShadow:o}}function ly(n){let e=new WeakMap;function t(r,s=0){const o=e.get(r);let a;return o===void 0?(a=new gd(n),e.set(r,[a])):s>=o.length?(a=new gd(n),o.push(a)):a=o[s],a}function i(){e=new WeakMap}return{get:t,dispose:i}}class cy extends ws{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=r_,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class uy extends ws{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const fy=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,dy=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function hy(n,e,t){let i=new Bu;const r=new nt,s=new nt,o=new Ut,a=new cy({depthPacking:s_}),l=new uy,c={},u=t.maxTextureSize,d={[Kn]:sn,[sn]:Kn,[gn]:gn},f=new gi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new nt},radius:{value:4}},vertexShader:fy,fragmentShader:dy}),h=f.clone();h.defines.HORIZONTAL_PASS=1;const g=new Jt;g.setAttribute("position",new bt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new je(g,f),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Cu;let p=this.type;this.render=function(R,A,P){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||R.length===0)return;const x=n.getRenderTarget(),v=n.getActiveCubeFace(),w=n.getActiveMipmapLevel(),k=n.state;k.setBlending(ki),k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);const B=p!==si&&this.type===si,X=p===si&&this.type!==si;for(let J=0,H=R.length;J<H;J++){const te=R[J],I=te.shadow;if(I===void 0){console.warn("THREE.WebGLShadowMap:",te,"has no shadow.");continue}if(I.autoUpdate===!1&&I.needsUpdate===!1)continue;r.copy(I.mapSize);const Z=I.getFrameExtents();if(r.multiply(Z),s.copy(I.mapSize),(r.x>u||r.y>u)&&(r.x>u&&(s.x=Math.floor(u/Z.x),r.x=s.x*Z.x,I.mapSize.x=s.x),r.y>u&&(s.y=Math.floor(u/Z.y),r.y=s.y*Z.y,I.mapSize.y=s.y)),I.map===null||B===!0||X===!0){const se=this.type!==si?{minFilter:zt,magFilter:zt}:{};I.map!==null&&I.map.dispose(),I.map=new dr(r.x,r.y,se),I.map.texture.name=te.name+".shadowMap",I.camera.updateProjectionMatrix()}n.setRenderTarget(I.map),n.clear();const Q=I.getViewportCount();for(let se=0;se<Q;se++){const Me=I.getViewport(se);o.set(s.x*Me.x,s.y*Me.y,s.x*Me.z,s.y*Me.w),k.viewport(o),I.updateMatrices(te,se),i=I.getFrustum(),y(A,P,I.camera,te,this.type)}I.isPointLightShadow!==!0&&this.type===si&&E(I,P),I.needsUpdate=!1}p=this.type,m.needsUpdate=!1,n.setRenderTarget(x,v,w)};function E(R,A){const P=e.update(_);f.defines.VSM_SAMPLES!==R.blurSamples&&(f.defines.VSM_SAMPLES=R.blurSamples,h.defines.VSM_SAMPLES=R.blurSamples,f.needsUpdate=!0,h.needsUpdate=!0),R.mapPass===null&&(R.mapPass=new dr(r.x,r.y)),f.uniforms.shadow_pass.value=R.map.texture,f.uniforms.resolution.value=R.mapSize,f.uniforms.radius.value=R.radius,n.setRenderTarget(R.mapPass),n.clear(),n.renderBufferDirect(A,null,P,f,_,null),h.uniforms.shadow_pass.value=R.mapPass.texture,h.uniforms.resolution.value=R.mapSize,h.uniforms.radius.value=R.radius,n.setRenderTarget(R.map),n.clear(),n.renderBufferDirect(A,null,P,h,_,null)}function S(R,A,P,x){let v=null;const w=P.isPointLight===!0?R.customDistanceMaterial:R.customDepthMaterial;if(w!==void 0)v=w;else if(v=P.isPointLight===!0?l:a,n.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const k=v.uuid,B=A.uuid;let X=c[k];X===void 0&&(X={},c[k]=X);let J=X[B];J===void 0&&(J=v.clone(),X[B]=J,A.addEventListener("dispose",C)),v=J}if(v.visible=A.visible,v.wireframe=A.wireframe,x===si?v.side=A.shadowSide!==null?A.shadowSide:A.side:v.side=A.shadowSide!==null?A.shadowSide:d[A.side],v.alphaMap=A.alphaMap,v.alphaTest=A.alphaTest,v.map=A.map,v.clipShadows=A.clipShadows,v.clippingPlanes=A.clippingPlanes,v.clipIntersection=A.clipIntersection,v.displacementMap=A.displacementMap,v.displacementScale=A.displacementScale,v.displacementBias=A.displacementBias,v.wireframeLinewidth=A.wireframeLinewidth,v.linewidth=A.linewidth,P.isPointLight===!0&&v.isMeshDistanceMaterial===!0){const k=n.properties.get(v);k.light=P}return v}function y(R,A,P,x,v){if(R.visible===!1)return;if(R.layers.test(A.layers)&&(R.isMesh||R.isLine||R.isPoints)&&(R.castShadow||R.receiveShadow&&v===si)&&(!R.frustumCulled||i.intersectsObject(R))){R.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,R.matrixWorld);const B=e.update(R),X=R.material;if(Array.isArray(X)){const J=B.groups;for(let H=0,te=J.length;H<te;H++){const I=J[H],Z=X[I.materialIndex];if(Z&&Z.visible){const Q=S(R,Z,x,v);R.onBeforeShadow(n,R,A,P,B,Q,I),n.renderBufferDirect(P,null,B,Q,R,I),R.onAfterShadow(n,R,A,P,B,Q,I)}}}else if(X.visible){const J=S(R,X,x,v);R.onBeforeShadow(n,R,A,P,B,J,null),n.renderBufferDirect(P,null,B,J,R,null),R.onAfterShadow(n,R,A,P,B,J,null)}}const k=R.children;for(let B=0,X=k.length;B<X;B++)y(k[B],A,P,x,v)}function C(R){R.target.removeEventListener("dispose",C);for(const P in c){const x=c[P],v=R.target.uuid;v in x&&(x[v].dispose(),delete x[v])}}}const py={[wc]:Rc,[Cc]:Lc,[Pc]:Dc,[us]:Ic,[Rc]:wc,[Lc]:Cc,[Dc]:Pc,[Ic]:us};function my(n,e){function t(){let L=!1;const fe=new Ut;let W=null;const ee=new Ut(0,0,0,0);return{setMask:function(me){W!==me&&!L&&(n.colorMask(me,me,me,me),W=me)},setLocked:function(me){L=me},setClear:function(me,he,Ve,Lt,Yt){Yt===!0&&(me*=Lt,he*=Lt,Ve*=Lt),fe.set(me,he,Ve,Lt),ee.equals(fe)===!1&&(n.clearColor(me,he,Ve,Lt),ee.copy(fe))},reset:function(){L=!1,W=null,ee.set(-1,0,0,0)}}}function i(){let L=!1,fe=!1,W=null,ee=null,me=null;return{setReversed:function(he){if(fe!==he){const Ve=e.get("EXT_clip_control");fe?Ve.clipControlEXT(Ve.LOWER_LEFT_EXT,Ve.ZERO_TO_ONE_EXT):Ve.clipControlEXT(Ve.LOWER_LEFT_EXT,Ve.NEGATIVE_ONE_TO_ONE_EXT);const Lt=me;me=null,this.setClear(Lt)}fe=he},getReversed:function(){return fe},setTest:function(he){he?ce(n.DEPTH_TEST):Re(n.DEPTH_TEST)},setMask:function(he){W!==he&&!L&&(n.depthMask(he),W=he)},setFunc:function(he){if(fe&&(he=py[he]),ee!==he){switch(he){case wc:n.depthFunc(n.NEVER);break;case Rc:n.depthFunc(n.ALWAYS);break;case Cc:n.depthFunc(n.LESS);break;case us:n.depthFunc(n.LEQUAL);break;case Pc:n.depthFunc(n.EQUAL);break;case Ic:n.depthFunc(n.GEQUAL);break;case Lc:n.depthFunc(n.GREATER);break;case Dc:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}ee=he}},setLocked:function(he){L=he},setClear:function(he){me!==he&&(fe&&(he=1-he),n.clearDepth(he),me=he)},reset:function(){L=!1,W=null,ee=null,me=null,fe=!1}}}function r(){let L=!1,fe=null,W=null,ee=null,me=null,he=null,Ve=null,Lt=null,Yt=null;return{setTest:function(pt){L||(pt?ce(n.STENCIL_TEST):Re(n.STENCIL_TEST))},setMask:function(pt){fe!==pt&&!L&&(n.stencilMask(pt),fe=pt)},setFunc:function(pt,Tn,Jn){(W!==pt||ee!==Tn||me!==Jn)&&(n.stencilFunc(pt,Tn,Jn),W=pt,ee=Tn,me=Jn)},setOp:function(pt,Tn,Jn){(he!==pt||Ve!==Tn||Lt!==Jn)&&(n.stencilOp(pt,Tn,Jn),he=pt,Ve=Tn,Lt=Jn)},setLocked:function(pt){L=pt},setClear:function(pt){Yt!==pt&&(n.clearStencil(pt),Yt=pt)},reset:function(){L=!1,fe=null,W=null,ee=null,me=null,he=null,Ve=null,Lt=null,Yt=null}}}const s=new t,o=new i,a=new r,l=new WeakMap,c=new WeakMap;let u={},d={},f=new WeakMap,h=[],g=null,_=!1,m=null,p=null,E=null,S=null,y=null,C=null,R=null,A=new et(0,0,0),P=0,x=!1,v=null,w=null,k=null,B=null,X=null;const J=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let H=!1,te=0;const I=n.getParameter(n.VERSION);I.indexOf("WebGL")!==-1?(te=parseFloat(/^WebGL (\d)/.exec(I)[1]),H=te>=1):I.indexOf("OpenGL ES")!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(I)[1]),H=te>=2);let Z=null,Q={};const se=n.getParameter(n.SCISSOR_BOX),Me=n.getParameter(n.VIEWPORT),Je=new Ut().fromArray(se),K=new Ut().fromArray(Me);function re(L,fe,W,ee){const me=new Uint8Array(4),he=n.createTexture();n.bindTexture(L,he),n.texParameteri(L,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(L,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Ve=0;Ve<W;Ve++)L===n.TEXTURE_3D||L===n.TEXTURE_2D_ARRAY?n.texImage3D(fe,0,n.RGBA,1,1,ee,0,n.RGBA,n.UNSIGNED_BYTE,me):n.texImage2D(fe+Ve,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,me);return he}const ne={};ne[n.TEXTURE_2D]=re(n.TEXTURE_2D,n.TEXTURE_2D,1),ne[n.TEXTURE_CUBE_MAP]=re(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),ne[n.TEXTURE_2D_ARRAY]=re(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),ne[n.TEXTURE_3D]=re(n.TEXTURE_3D,n.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ce(n.DEPTH_TEST),o.setFunc(us),Ze(!1),ze(Sf),ce(n.CULL_FACE),D(ki);function ce(L){u[L]!==!0&&(n.enable(L),u[L]=!0)}function Re(L){u[L]!==!1&&(n.disable(L),u[L]=!1)}function De(L,fe){return d[L]!==fe?(n.bindFramebuffer(L,fe),d[L]=fe,L===n.DRAW_FRAMEBUFFER&&(d[n.FRAMEBUFFER]=fe),L===n.FRAMEBUFFER&&(d[n.DRAW_FRAMEBUFFER]=fe),!0):!1}function ye(L,fe){let W=h,ee=!1;if(L){W=f.get(fe),W===void 0&&(W=[],f.set(fe,W));const me=L.textures;if(W.length!==me.length||W[0]!==n.COLOR_ATTACHMENT0){for(let he=0,Ve=me.length;he<Ve;he++)W[he]=n.COLOR_ATTACHMENT0+he;W.length=me.length,ee=!0}}else W[0]!==n.BACK&&(W[0]=n.BACK,ee=!0);ee&&n.drawBuffers(W)}function xt(L){return g!==L?(n.useProgram(L),g=L,!0):!1}const Ke={[rr]:n.FUNC_ADD,[Ig]:n.FUNC_SUBTRACT,[Lg]:n.FUNC_REVERSE_SUBTRACT};Ke[Dg]=n.MIN,Ke[Ng]=n.MAX;const yt={[Ug]:n.ZERO,[Og]:n.ONE,[Fg]:n.SRC_COLOR,[Ac]:n.SRC_ALPHA,[Gg]:n.SRC_ALPHA_SATURATE,[Hg]:n.DST_COLOR,[Bg]:n.DST_ALPHA,[kg]:n.ONE_MINUS_SRC_COLOR,[Tc]:n.ONE_MINUS_SRC_ALPHA,[Vg]:n.ONE_MINUS_DST_COLOR,[zg]:n.ONE_MINUS_DST_ALPHA,[Wg]:n.CONSTANT_COLOR,[Xg]:n.ONE_MINUS_CONSTANT_COLOR,[qg]:n.CONSTANT_ALPHA,[Yg]:n.ONE_MINUS_CONSTANT_ALPHA};function D(L,fe,W,ee,me,he,Ve,Lt,Yt,pt){if(L===ki){_===!0&&(Re(n.BLEND),_=!1);return}if(_===!1&&(ce(n.BLEND),_=!0),L!==Pg){if(L!==m||pt!==x){if((p!==rr||y!==rr)&&(n.blendEquation(n.FUNC_ADD),p=rr,y=rr),pt)switch(L){case Qr:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case yf:n.blendFunc(n.ONE,n.ONE);break;case Mf:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ef:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}else switch(L){case Qr:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case yf:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case Mf:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ef:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}E=null,S=null,C=null,R=null,A.set(0,0,0),P=0,m=L,x=pt}return}me=me||fe,he=he||W,Ve=Ve||ee,(fe!==p||me!==y)&&(n.blendEquationSeparate(Ke[fe],Ke[me]),p=fe,y=me),(W!==E||ee!==S||he!==C||Ve!==R)&&(n.blendFuncSeparate(yt[W],yt[ee],yt[he],yt[Ve]),E=W,S=ee,C=he,R=Ve),(Lt.equals(A)===!1||Yt!==P)&&(n.blendColor(Lt.r,Lt.g,Lt.b,Yt),A.copy(Lt),P=Yt),m=L,x=!1}function Ot(L,fe){L.side===gn?Re(n.CULL_FACE):ce(n.CULL_FACE);let W=L.side===sn;fe&&(W=!W),Ze(W),L.blending===Qr&&L.transparent===!1?D(ki):D(L.blending,L.blendEquation,L.blendSrc,L.blendDst,L.blendEquationAlpha,L.blendSrcAlpha,L.blendDstAlpha,L.blendColor,L.blendAlpha,L.premultipliedAlpha),o.setFunc(L.depthFunc),o.setTest(L.depthTest),o.setMask(L.depthWrite),s.setMask(L.colorWrite);const ee=L.stencilWrite;a.setTest(ee),ee&&(a.setMask(L.stencilWriteMask),a.setFunc(L.stencilFunc,L.stencilRef,L.stencilFuncMask),a.setOp(L.stencilFail,L.stencilZFail,L.stencilZPass)),ct(L.polygonOffset,L.polygonOffsetFactor,L.polygonOffsetUnits),L.alphaToCoverage===!0?ce(n.SAMPLE_ALPHA_TO_COVERAGE):Re(n.SAMPLE_ALPHA_TO_COVERAGE)}function Ze(L){v!==L&&(L?n.frontFace(n.CW):n.frontFace(n.CCW),v=L)}function ze(L){L!==wg?(ce(n.CULL_FACE),L!==w&&(L===Sf?n.cullFace(n.BACK):L===Rg?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Re(n.CULL_FACE),w=L}function Te(L){L!==k&&(H&&n.lineWidth(L),k=L)}function ct(L,fe,W){L?(ce(n.POLYGON_OFFSET_FILL),(B!==fe||X!==W)&&(n.polygonOffset(fe,W),B=fe,X=W)):Re(n.POLYGON_OFFSET_FILL)}function Pe(L){L?ce(n.SCISSOR_TEST):Re(n.SCISSOR_TEST)}function T(L){L===void 0&&(L=n.TEXTURE0+J-1),Z!==L&&(n.activeTexture(L),Z=L)}function M(L,fe,W){W===void 0&&(Z===null?W=n.TEXTURE0+J-1:W=Z);let ee=Q[W];ee===void 0&&(ee={type:void 0,texture:void 0},Q[W]=ee),(ee.type!==L||ee.texture!==fe)&&(Z!==W&&(n.activeTexture(W),Z=W),n.bindTexture(L,fe||ne[L]),ee.type=L,ee.texture=fe)}function F(){const L=Q[Z];L!==void 0&&L.type!==void 0&&(n.bindTexture(L.type,null),L.type=void 0,L.texture=void 0)}function Y(){try{n.compressedTexImage2D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function $(){try{n.compressedTexImage3D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function q(){try{n.texSubImage2D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function ve(){try{n.texSubImage3D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function de(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function _e(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function ot(){try{n.texStorage2D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function oe(){try{n.texStorage3D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function xe(){try{n.texImage2D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function Le(){try{n.texImage3D.apply(n,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function Oe(L){Je.equals(L)===!1&&(n.scissor(L.x,L.y,L.z,L.w),Je.copy(L))}function Se(L){K.equals(L)===!1&&(n.viewport(L.x,L.y,L.z,L.w),K.copy(L))}function rt(L,fe){let W=c.get(fe);W===void 0&&(W=new WeakMap,c.set(fe,W));let ee=W.get(L);ee===void 0&&(ee=n.getUniformBlockIndex(fe,L.name),W.set(L,ee))}function Xe(L,fe){const ee=c.get(fe).get(L);l.get(fe)!==ee&&(n.uniformBlockBinding(fe,ee,L.__bindingPointIndex),l.set(fe,ee))}function Mt(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),o.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),u={},Z=null,Q={},d={},f=new WeakMap,h=[],g=null,_=!1,m=null,p=null,E=null,S=null,y=null,C=null,R=null,A=new et(0,0,0),P=0,x=!1,v=null,w=null,k=null,B=null,X=null,Je.set(0,0,n.canvas.width,n.canvas.height),K.set(0,0,n.canvas.width,n.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:ce,disable:Re,bindFramebuffer:De,drawBuffers:ye,useProgram:xt,setBlending:D,setMaterial:Ot,setFlipSided:Ze,setCullFace:ze,setLineWidth:Te,setPolygonOffset:ct,setScissorTest:Pe,activeTexture:T,bindTexture:M,unbindTexture:F,compressedTexImage2D:Y,compressedTexImage3D:$,texImage2D:xe,texImage3D:Le,updateUBOMapping:rt,uniformBlockBinding:Xe,texStorage2D:ot,texStorage3D:oe,texSubImage2D:q,texSubImage3D:ve,compressedTexSubImage2D:de,compressedTexSubImage3D:_e,scissor:Oe,viewport:Se,reset:Mt}}function _d(n,e,t,i){const r=gy(i);switch(t){case hp:return n*e;case mp:return n*e;case gp:return n*e*2;case Nu:return n*e/r.components*r.byteLength;case Uu:return n*e/r.components*r.byteLength;case _p:return n*e*2/r.components*r.byteLength;case Ou:return n*e*2/r.components*r.byteLength;case pp:return n*e*3/r.components*r.byteLength;case Ln:return n*e*4/r.components*r.byteLength;case Fu:return n*e*4/r.components*r.byteLength;case xa:case Sa:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case ya:case Ma:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case kc:case zc:return Math.max(n,16)*Math.max(e,8)/4;case Fc:case Bc:return Math.max(n,8)*Math.max(e,8)/2;case Hc:case Vc:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case Gc:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Wc:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Xc:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case qc:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case Yc:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case Kc:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case Zc:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case $c:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case jc:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case Jc:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case Qc:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case eu:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case tu:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case nu:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case iu:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case Ea:case ru:case su:return Math.ceil(n/4)*Math.ceil(e/4)*16;case vp:case ou:return Math.ceil(n/4)*Math.ceil(e/4)*8;case au:case lu:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function gy(n){switch(n){case mi:case up:return{byteLength:1,components:1};case po:case fp:case So:return{byteLength:2,components:1};case Lu:case Du:return{byteLength:2,components:4};case fr:case Iu:case Hn:return{byteLength:4,components:1};case dp:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${n}.`)}function _y(n,e,t,i,r,s,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new nt,u=new WeakMap;let d;const f=new WeakMap;let h=!1;try{h=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(T,M){return h?new OffscreenCanvas(T,M):Pa("canvas")}function _(T,M,F){let Y=1;const $=Pe(T);if(($.width>F||$.height>F)&&(Y=F/Math.max($.width,$.height)),Y<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const q=Math.floor(Y*$.width),ve=Math.floor(Y*$.height);d===void 0&&(d=g(q,ve));const de=M?g(q,ve):d;return de.width=q,de.height=ve,de.getContext("2d").drawImage(T,0,0,q,ve),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+$.width+"x"+$.height+") to ("+q+"x"+ve+")."),de}else return"data"in T&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+$.width+"x"+$.height+")."),T;return T}function m(T){return T.generateMipmaps}function p(T){n.generateMipmap(T)}function E(T){return T.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?n.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function S(T,M,F,Y,$=!1){if(T!==null){if(n[T]!==void 0)return n[T];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let q=M;if(M===n.RED&&(F===n.FLOAT&&(q=n.R32F),F===n.HALF_FLOAT&&(q=n.R16F),F===n.UNSIGNED_BYTE&&(q=n.R8)),M===n.RED_INTEGER&&(F===n.UNSIGNED_BYTE&&(q=n.R8UI),F===n.UNSIGNED_SHORT&&(q=n.R16UI),F===n.UNSIGNED_INT&&(q=n.R32UI),F===n.BYTE&&(q=n.R8I),F===n.SHORT&&(q=n.R16I),F===n.INT&&(q=n.R32I)),M===n.RG&&(F===n.FLOAT&&(q=n.RG32F),F===n.HALF_FLOAT&&(q=n.RG16F),F===n.UNSIGNED_BYTE&&(q=n.RG8)),M===n.RG_INTEGER&&(F===n.UNSIGNED_BYTE&&(q=n.RG8UI),F===n.UNSIGNED_SHORT&&(q=n.RG16UI),F===n.UNSIGNED_INT&&(q=n.RG32UI),F===n.BYTE&&(q=n.RG8I),F===n.SHORT&&(q=n.RG16I),F===n.INT&&(q=n.RG32I)),M===n.RGB_INTEGER&&(F===n.UNSIGNED_BYTE&&(q=n.RGB8UI),F===n.UNSIGNED_SHORT&&(q=n.RGB16UI),F===n.UNSIGNED_INT&&(q=n.RGB32UI),F===n.BYTE&&(q=n.RGB8I),F===n.SHORT&&(q=n.RGB16I),F===n.INT&&(q=n.RGB32I)),M===n.RGBA_INTEGER&&(F===n.UNSIGNED_BYTE&&(q=n.RGBA8UI),F===n.UNSIGNED_SHORT&&(q=n.RGBA16UI),F===n.UNSIGNED_INT&&(q=n.RGBA32UI),F===n.BYTE&&(q=n.RGBA8I),F===n.SHORT&&(q=n.RGBA16I),F===n.INT&&(q=n.RGBA32I)),M===n.RGB&&F===n.UNSIGNED_INT_5_9_9_9_REV&&(q=n.RGB9_E5),M===n.RGBA){const ve=$?ja:at.getTransfer(Y);F===n.FLOAT&&(q=n.RGBA32F),F===n.HALF_FLOAT&&(q=n.RGBA16F),F===n.UNSIGNED_BYTE&&(q=ve===gt?n.SRGB8_ALPHA8:n.RGBA8),F===n.UNSIGNED_SHORT_4_4_4_4&&(q=n.RGBA4),F===n.UNSIGNED_SHORT_5_5_5_1&&(q=n.RGB5_A1)}return(q===n.R16F||q===n.R32F||q===n.RG16F||q===n.RG32F||q===n.RGBA16F||q===n.RGBA32F)&&e.get("EXT_color_buffer_float"),q}function y(T,M){let F;return T?M===null||M===fr||M===hs?F=n.DEPTH24_STENCIL8:M===Hn?F=n.DEPTH32F_STENCIL8:M===po&&(F=n.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):M===null||M===fr||M===hs?F=n.DEPTH_COMPONENT24:M===Hn?F=n.DEPTH_COMPONENT32F:M===po&&(F=n.DEPTH_COMPONENT16),F}function C(T,M){return m(T)===!0||T.isFramebufferTexture&&T.minFilter!==zt&&T.minFilter!==zn?Math.log2(Math.max(M.width,M.height))+1:T.mipmaps!==void 0&&T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?M.mipmaps.length:1}function R(T){const M=T.target;M.removeEventListener("dispose",R),P(M),M.isVideoTexture&&u.delete(M)}function A(T){const M=T.target;M.removeEventListener("dispose",A),v(M)}function P(T){const M=i.get(T);if(M.__webglInit===void 0)return;const F=T.source,Y=f.get(F);if(Y){const $=Y[M.__cacheKey];$.usedTimes--,$.usedTimes===0&&x(T),Object.keys(Y).length===0&&f.delete(F)}i.remove(T)}function x(T){const M=i.get(T);n.deleteTexture(M.__webglTexture);const F=T.source,Y=f.get(F);delete Y[M.__cacheKey],o.memory.textures--}function v(T){const M=i.get(T);if(T.depthTexture&&(T.depthTexture.dispose(),i.remove(T.depthTexture)),T.isWebGLCubeRenderTarget)for(let Y=0;Y<6;Y++){if(Array.isArray(M.__webglFramebuffer[Y]))for(let $=0;$<M.__webglFramebuffer[Y].length;$++)n.deleteFramebuffer(M.__webglFramebuffer[Y][$]);else n.deleteFramebuffer(M.__webglFramebuffer[Y]);M.__webglDepthbuffer&&n.deleteRenderbuffer(M.__webglDepthbuffer[Y])}else{if(Array.isArray(M.__webglFramebuffer))for(let Y=0;Y<M.__webglFramebuffer.length;Y++)n.deleteFramebuffer(M.__webglFramebuffer[Y]);else n.deleteFramebuffer(M.__webglFramebuffer);if(M.__webglDepthbuffer&&n.deleteRenderbuffer(M.__webglDepthbuffer),M.__webglMultisampledFramebuffer&&n.deleteFramebuffer(M.__webglMultisampledFramebuffer),M.__webglColorRenderbuffer)for(let Y=0;Y<M.__webglColorRenderbuffer.length;Y++)M.__webglColorRenderbuffer[Y]&&n.deleteRenderbuffer(M.__webglColorRenderbuffer[Y]);M.__webglDepthRenderbuffer&&n.deleteRenderbuffer(M.__webglDepthRenderbuffer)}const F=T.textures;for(let Y=0,$=F.length;Y<$;Y++){const q=i.get(F[Y]);q.__webglTexture&&(n.deleteTexture(q.__webglTexture),o.memory.textures--),i.remove(F[Y])}i.remove(T)}let w=0;function k(){w=0}function B(){const T=w;return T>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+T+" texture units while this GPU supports only "+r.maxTextures),w+=1,T}function X(T){const M=[];return M.push(T.wrapS),M.push(T.wrapT),M.push(T.wrapR||0),M.push(T.magFilter),M.push(T.minFilter),M.push(T.anisotropy),M.push(T.internalFormat),M.push(T.format),M.push(T.type),M.push(T.generateMipmaps),M.push(T.premultiplyAlpha),M.push(T.flipY),M.push(T.unpackAlignment),M.push(T.colorSpace),M.join()}function J(T,M){const F=i.get(T);if(T.isVideoTexture&&Te(T),T.isRenderTargetTexture===!1&&T.version>0&&F.__version!==T.version){const Y=T.image;if(Y===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Y.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{K(F,T,M);return}}t.bindTexture(n.TEXTURE_2D,F.__webglTexture,n.TEXTURE0+M)}function H(T,M){const F=i.get(T);if(T.version>0&&F.__version!==T.version){K(F,T,M);return}t.bindTexture(n.TEXTURE_2D_ARRAY,F.__webglTexture,n.TEXTURE0+M)}function te(T,M){const F=i.get(T);if(T.version>0&&F.__version!==T.version){K(F,T,M);return}t.bindTexture(n.TEXTURE_3D,F.__webglTexture,n.TEXTURE0+M)}function I(T,M){const F=i.get(T);if(T.version>0&&F.__version!==T.version){re(F,T,M);return}t.bindTexture(n.TEXTURE_CUBE_MAP,F.__webglTexture,n.TEXTURE0+M)}const Z={[ho]:n.REPEAT,[ar]:n.CLAMP_TO_EDGE,[Oc]:n.MIRRORED_REPEAT},Q={[zt]:n.NEAREST,[i_]:n.NEAREST_MIPMAP_NEAREST,[Co]:n.NEAREST_MIPMAP_LINEAR,[zn]:n.LINEAR,[gl]:n.LINEAR_MIPMAP_NEAREST,[lr]:n.LINEAR_MIPMAP_LINEAR},se={[a_]:n.NEVER,[h_]:n.ALWAYS,[l_]:n.LESS,[Sp]:n.LEQUAL,[c_]:n.EQUAL,[d_]:n.GEQUAL,[u_]:n.GREATER,[f_]:n.NOTEQUAL};function Me(T,M){if(M.type===Hn&&e.has("OES_texture_float_linear")===!1&&(M.magFilter===zn||M.magFilter===gl||M.magFilter===Co||M.magFilter===lr||M.minFilter===zn||M.minFilter===gl||M.minFilter===Co||M.minFilter===lr)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(T,n.TEXTURE_WRAP_S,Z[M.wrapS]),n.texParameteri(T,n.TEXTURE_WRAP_T,Z[M.wrapT]),(T===n.TEXTURE_3D||T===n.TEXTURE_2D_ARRAY)&&n.texParameteri(T,n.TEXTURE_WRAP_R,Z[M.wrapR]),n.texParameteri(T,n.TEXTURE_MAG_FILTER,Q[M.magFilter]),n.texParameteri(T,n.TEXTURE_MIN_FILTER,Q[M.minFilter]),M.compareFunction&&(n.texParameteri(T,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(T,n.TEXTURE_COMPARE_FUNC,se[M.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(M.magFilter===zt||M.minFilter!==Co&&M.minFilter!==lr||M.type===Hn&&e.has("OES_texture_float_linear")===!1)return;if(M.anisotropy>1||i.get(M).__currentAnisotropy){const F=e.get("EXT_texture_filter_anisotropic");n.texParameterf(T,F.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,r.getMaxAnisotropy())),i.get(M).__currentAnisotropy=M.anisotropy}}}function Je(T,M){let F=!1;T.__webglInit===void 0&&(T.__webglInit=!0,M.addEventListener("dispose",R));const Y=M.source;let $=f.get(Y);$===void 0&&($={},f.set(Y,$));const q=X(M);if(q!==T.__cacheKey){$[q]===void 0&&($[q]={texture:n.createTexture(),usedTimes:0},o.memory.textures++,F=!0),$[q].usedTimes++;const ve=$[T.__cacheKey];ve!==void 0&&($[T.__cacheKey].usedTimes--,ve.usedTimes===0&&x(M)),T.__cacheKey=q,T.__webglTexture=$[q].texture}return F}function K(T,M,F){let Y=n.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(Y=n.TEXTURE_2D_ARRAY),M.isData3DTexture&&(Y=n.TEXTURE_3D);const $=Je(T,M),q=M.source;t.bindTexture(Y,T.__webglTexture,n.TEXTURE0+F);const ve=i.get(q);if(q.version!==ve.__version||$===!0){t.activeTexture(n.TEXTURE0+F);const de=at.getPrimaries(at.workingColorSpace),_e=M.colorSpace===Di?null:at.getPrimaries(M.colorSpace),ot=M.colorSpace===Di||de===_e?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,M.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,M.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,ot);let oe=_(M.image,!1,r.maxTextureSize);oe=ct(M,oe);const xe=s.convert(M.format,M.colorSpace),Le=s.convert(M.type);let Oe=S(M.internalFormat,xe,Le,M.colorSpace,M.isVideoTexture);Me(Y,M);let Se;const rt=M.mipmaps,Xe=M.isVideoTexture!==!0,Mt=ve.__version===void 0||$===!0,L=q.dataReady,fe=C(M,oe);if(M.isDepthTexture)Oe=y(M.format===ps,M.type),Mt&&(Xe?t.texStorage2D(n.TEXTURE_2D,1,Oe,oe.width,oe.height):t.texImage2D(n.TEXTURE_2D,0,Oe,oe.width,oe.height,0,xe,Le,null));else if(M.isDataTexture)if(rt.length>0){Xe&&Mt&&t.texStorage2D(n.TEXTURE_2D,fe,Oe,rt[0].width,rt[0].height);for(let W=0,ee=rt.length;W<ee;W++)Se=rt[W],Xe?L&&t.texSubImage2D(n.TEXTURE_2D,W,0,0,Se.width,Se.height,xe,Le,Se.data):t.texImage2D(n.TEXTURE_2D,W,Oe,Se.width,Se.height,0,xe,Le,Se.data);M.generateMipmaps=!1}else Xe?(Mt&&t.texStorage2D(n.TEXTURE_2D,fe,Oe,oe.width,oe.height),L&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,oe.width,oe.height,xe,Le,oe.data)):t.texImage2D(n.TEXTURE_2D,0,Oe,oe.width,oe.height,0,xe,Le,oe.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){Xe&&Mt&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Oe,rt[0].width,rt[0].height,oe.depth);for(let W=0,ee=rt.length;W<ee;W++)if(Se=rt[W],M.format!==Ln)if(xe!==null)if(Xe){if(L)if(M.layerUpdates.size>0){const me=_d(Se.width,Se.height,M.format,M.type);for(const he of M.layerUpdates){const Ve=Se.data.subarray(he*me/Se.data.BYTES_PER_ELEMENT,(he+1)*me/Se.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,W,0,0,he,Se.width,Se.height,1,xe,Ve)}M.clearLayerUpdates()}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,W,0,0,0,Se.width,Se.height,oe.depth,xe,Se.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,W,Oe,Se.width,Se.height,oe.depth,0,Se.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Xe?L&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,W,0,0,0,Se.width,Se.height,oe.depth,xe,Le,Se.data):t.texImage3D(n.TEXTURE_2D_ARRAY,W,Oe,Se.width,Se.height,oe.depth,0,xe,Le,Se.data)}else{Xe&&Mt&&t.texStorage2D(n.TEXTURE_2D,fe,Oe,rt[0].width,rt[0].height);for(let W=0,ee=rt.length;W<ee;W++)Se=rt[W],M.format!==Ln?xe!==null?Xe?L&&t.compressedTexSubImage2D(n.TEXTURE_2D,W,0,0,Se.width,Se.height,xe,Se.data):t.compressedTexImage2D(n.TEXTURE_2D,W,Oe,Se.width,Se.height,0,Se.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Xe?L&&t.texSubImage2D(n.TEXTURE_2D,W,0,0,Se.width,Se.height,xe,Le,Se.data):t.texImage2D(n.TEXTURE_2D,W,Oe,Se.width,Se.height,0,xe,Le,Se.data)}else if(M.isDataArrayTexture)if(Xe){if(Mt&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Oe,oe.width,oe.height,oe.depth),L)if(M.layerUpdates.size>0){const W=_d(oe.width,oe.height,M.format,M.type);for(const ee of M.layerUpdates){const me=oe.data.subarray(ee*W/oe.data.BYTES_PER_ELEMENT,(ee+1)*W/oe.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,ee,oe.width,oe.height,1,xe,Le,me)}M.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,oe.width,oe.height,oe.depth,xe,Le,oe.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,Oe,oe.width,oe.height,oe.depth,0,xe,Le,oe.data);else if(M.isData3DTexture)Xe?(Mt&&t.texStorage3D(n.TEXTURE_3D,fe,Oe,oe.width,oe.height,oe.depth),L&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,oe.width,oe.height,oe.depth,xe,Le,oe.data)):t.texImage3D(n.TEXTURE_3D,0,Oe,oe.width,oe.height,oe.depth,0,xe,Le,oe.data);else if(M.isFramebufferTexture){if(Mt)if(Xe)t.texStorage2D(n.TEXTURE_2D,fe,Oe,oe.width,oe.height);else{let W=oe.width,ee=oe.height;for(let me=0;me<fe;me++)t.texImage2D(n.TEXTURE_2D,me,Oe,W,ee,0,xe,Le,null),W>>=1,ee>>=1}}else if(rt.length>0){if(Xe&&Mt){const W=Pe(rt[0]);t.texStorage2D(n.TEXTURE_2D,fe,Oe,W.width,W.height)}for(let W=0,ee=rt.length;W<ee;W++)Se=rt[W],Xe?L&&t.texSubImage2D(n.TEXTURE_2D,W,0,0,xe,Le,Se):t.texImage2D(n.TEXTURE_2D,W,Oe,xe,Le,Se);M.generateMipmaps=!1}else if(Xe){if(Mt){const W=Pe(oe);t.texStorage2D(n.TEXTURE_2D,fe,Oe,W.width,W.height)}L&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,xe,Le,oe)}else t.texImage2D(n.TEXTURE_2D,0,Oe,xe,Le,oe);m(M)&&p(Y),ve.__version=q.version,M.onUpdate&&M.onUpdate(M)}T.__version=M.version}function re(T,M,F){if(M.image.length!==6)return;const Y=Je(T,M),$=M.source;t.bindTexture(n.TEXTURE_CUBE_MAP,T.__webglTexture,n.TEXTURE0+F);const q=i.get($);if($.version!==q.__version||Y===!0){t.activeTexture(n.TEXTURE0+F);const ve=at.getPrimaries(at.workingColorSpace),de=M.colorSpace===Di?null:at.getPrimaries(M.colorSpace),_e=M.colorSpace===Di||ve===de?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,M.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,M.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,_e);const ot=M.isCompressedTexture||M.image[0].isCompressedTexture,oe=M.image[0]&&M.image[0].isDataTexture,xe=[];for(let ee=0;ee<6;ee++)!ot&&!oe?xe[ee]=_(M.image[ee],!0,r.maxCubemapSize):xe[ee]=oe?M.image[ee].image:M.image[ee],xe[ee]=ct(M,xe[ee]);const Le=xe[0],Oe=s.convert(M.format,M.colorSpace),Se=s.convert(M.type),rt=S(M.internalFormat,Oe,Se,M.colorSpace),Xe=M.isVideoTexture!==!0,Mt=q.__version===void 0||Y===!0,L=$.dataReady;let fe=C(M,Le);Me(n.TEXTURE_CUBE_MAP,M);let W;if(ot){Xe&&Mt&&t.texStorage2D(n.TEXTURE_CUBE_MAP,fe,rt,Le.width,Le.height);for(let ee=0;ee<6;ee++){W=xe[ee].mipmaps;for(let me=0;me<W.length;me++){const he=W[me];M.format!==Ln?Oe!==null?Xe?L&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me,0,0,he.width,he.height,Oe,he.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me,rt,he.width,he.height,0,he.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Xe?L&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me,0,0,he.width,he.height,Oe,Se,he.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me,rt,he.width,he.height,0,Oe,Se,he.data)}}}else{if(W=M.mipmaps,Xe&&Mt){W.length>0&&fe++;const ee=Pe(xe[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,fe,rt,ee.width,ee.height)}for(let ee=0;ee<6;ee++)if(oe){Xe?L&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,0,0,xe[ee].width,xe[ee].height,Oe,Se,xe[ee].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,rt,xe[ee].width,xe[ee].height,0,Oe,Se,xe[ee].data);for(let me=0;me<W.length;me++){const Ve=W[me].image[ee].image;Xe?L&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me+1,0,0,Ve.width,Ve.height,Oe,Se,Ve.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me+1,rt,Ve.width,Ve.height,0,Oe,Se,Ve.data)}}else{Xe?L&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,0,0,Oe,Se,xe[ee]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,rt,Oe,Se,xe[ee]);for(let me=0;me<W.length;me++){const he=W[me];Xe?L&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me+1,0,0,Oe,Se,he.image[ee]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ee,me+1,rt,Oe,Se,he.image[ee])}}}m(M)&&p(n.TEXTURE_CUBE_MAP),q.__version=$.version,M.onUpdate&&M.onUpdate(M)}T.__version=M.version}function ne(T,M,F,Y,$,q){const ve=s.convert(F.format,F.colorSpace),de=s.convert(F.type),_e=S(F.internalFormat,ve,de,F.colorSpace),ot=i.get(M),oe=i.get(F);if(oe.__renderTarget=M,!ot.__hasExternalTextures){const xe=Math.max(1,M.width>>q),Le=Math.max(1,M.height>>q);$===n.TEXTURE_3D||$===n.TEXTURE_2D_ARRAY?t.texImage3D($,q,_e,xe,Le,M.depth,0,ve,de,null):t.texImage2D($,q,_e,xe,Le,0,ve,de,null)}t.bindFramebuffer(n.FRAMEBUFFER,T),ze(M)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,Y,$,oe.__webglTexture,0,Ze(M)):($===n.TEXTURE_2D||$>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&$<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,Y,$,oe.__webglTexture,q),t.bindFramebuffer(n.FRAMEBUFFER,null)}function ce(T,M,F){if(n.bindRenderbuffer(n.RENDERBUFFER,T),M.depthBuffer){const Y=M.depthTexture,$=Y&&Y.isDepthTexture?Y.type:null,q=y(M.stencilBuffer,$),ve=M.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,de=Ze(M);ze(M)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,de,q,M.width,M.height):F?n.renderbufferStorageMultisample(n.RENDERBUFFER,de,q,M.width,M.height):n.renderbufferStorage(n.RENDERBUFFER,q,M.width,M.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,ve,n.RENDERBUFFER,T)}else{const Y=M.textures;for(let $=0;$<Y.length;$++){const q=Y[$],ve=s.convert(q.format,q.colorSpace),de=s.convert(q.type),_e=S(q.internalFormat,ve,de,q.colorSpace),ot=Ze(M);F&&ze(M)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,ot,_e,M.width,M.height):ze(M)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ot,_e,M.width,M.height):n.renderbufferStorage(n.RENDERBUFFER,_e,M.width,M.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function Re(T,M){if(M&&M.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,T),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Y=i.get(M.depthTexture);Y.__renderTarget=M,(!Y.__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),J(M.depthTexture,0);const $=Y.__webglTexture,q=Ze(M);if(M.depthTexture.format===es)ze(M)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,$,0,q):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,$,0);else if(M.depthTexture.format===ps)ze(M)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,$,0,q):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,$,0);else throw new Error("Unknown depthTexture format")}function De(T){const M=i.get(T),F=T.isWebGLCubeRenderTarget===!0;if(M.__boundDepthTexture!==T.depthTexture){const Y=T.depthTexture;if(M.__depthDisposeCallback&&M.__depthDisposeCallback(),Y){const $=()=>{delete M.__boundDepthTexture,delete M.__depthDisposeCallback,Y.removeEventListener("dispose",$)};Y.addEventListener("dispose",$),M.__depthDisposeCallback=$}M.__boundDepthTexture=Y}if(T.depthTexture&&!M.__autoAllocateDepthBuffer){if(F)throw new Error("target.depthTexture not supported in Cube render targets");Re(M.__webglFramebuffer,T)}else if(F){M.__webglDepthbuffer=[];for(let Y=0;Y<6;Y++)if(t.bindFramebuffer(n.FRAMEBUFFER,M.__webglFramebuffer[Y]),M.__webglDepthbuffer[Y]===void 0)M.__webglDepthbuffer[Y]=n.createRenderbuffer(),ce(M.__webglDepthbuffer[Y],T,!1);else{const $=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,q=M.__webglDepthbuffer[Y];n.bindRenderbuffer(n.RENDERBUFFER,q),n.framebufferRenderbuffer(n.FRAMEBUFFER,$,n.RENDERBUFFER,q)}}else if(t.bindFramebuffer(n.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer===void 0)M.__webglDepthbuffer=n.createRenderbuffer(),ce(M.__webglDepthbuffer,T,!1);else{const Y=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,$=M.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,$),n.framebufferRenderbuffer(n.FRAMEBUFFER,Y,n.RENDERBUFFER,$)}t.bindFramebuffer(n.FRAMEBUFFER,null)}function ye(T,M,F){const Y=i.get(T);M!==void 0&&ne(Y.__webglFramebuffer,T,T.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),F!==void 0&&De(T)}function xt(T){const M=T.texture,F=i.get(T),Y=i.get(M);T.addEventListener("dispose",A);const $=T.textures,q=T.isWebGLCubeRenderTarget===!0,ve=$.length>1;if(ve||(Y.__webglTexture===void 0&&(Y.__webglTexture=n.createTexture()),Y.__version=M.version,o.memory.textures++),q){F.__webglFramebuffer=[];for(let de=0;de<6;de++)if(M.mipmaps&&M.mipmaps.length>0){F.__webglFramebuffer[de]=[];for(let _e=0;_e<M.mipmaps.length;_e++)F.__webglFramebuffer[de][_e]=n.createFramebuffer()}else F.__webglFramebuffer[de]=n.createFramebuffer()}else{if(M.mipmaps&&M.mipmaps.length>0){F.__webglFramebuffer=[];for(let de=0;de<M.mipmaps.length;de++)F.__webglFramebuffer[de]=n.createFramebuffer()}else F.__webglFramebuffer=n.createFramebuffer();if(ve)for(let de=0,_e=$.length;de<_e;de++){const ot=i.get($[de]);ot.__webglTexture===void 0&&(ot.__webglTexture=n.createTexture(),o.memory.textures++)}if(T.samples>0&&ze(T)===!1){F.__webglMultisampledFramebuffer=n.createFramebuffer(),F.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,F.__webglMultisampledFramebuffer);for(let de=0;de<$.length;de++){const _e=$[de];F.__webglColorRenderbuffer[de]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,F.__webglColorRenderbuffer[de]);const ot=s.convert(_e.format,_e.colorSpace),oe=s.convert(_e.type),xe=S(_e.internalFormat,ot,oe,_e.colorSpace,T.isXRRenderTarget===!0),Le=Ze(T);n.renderbufferStorageMultisample(n.RENDERBUFFER,Le,xe,T.width,T.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+de,n.RENDERBUFFER,F.__webglColorRenderbuffer[de])}n.bindRenderbuffer(n.RENDERBUFFER,null),T.depthBuffer&&(F.__webglDepthRenderbuffer=n.createRenderbuffer(),ce(F.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(q){t.bindTexture(n.TEXTURE_CUBE_MAP,Y.__webglTexture),Me(n.TEXTURE_CUBE_MAP,M);for(let de=0;de<6;de++)if(M.mipmaps&&M.mipmaps.length>0)for(let _e=0;_e<M.mipmaps.length;_e++)ne(F.__webglFramebuffer[de][_e],T,M,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+de,_e);else ne(F.__webglFramebuffer[de],T,M,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+de,0);m(M)&&p(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ve){for(let de=0,_e=$.length;de<_e;de++){const ot=$[de],oe=i.get(ot);t.bindTexture(n.TEXTURE_2D,oe.__webglTexture),Me(n.TEXTURE_2D,ot),ne(F.__webglFramebuffer,T,ot,n.COLOR_ATTACHMENT0+de,n.TEXTURE_2D,0),m(ot)&&p(n.TEXTURE_2D)}t.unbindTexture()}else{let de=n.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(de=T.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(de,Y.__webglTexture),Me(de,M),M.mipmaps&&M.mipmaps.length>0)for(let _e=0;_e<M.mipmaps.length;_e++)ne(F.__webglFramebuffer[_e],T,M,n.COLOR_ATTACHMENT0,de,_e);else ne(F.__webglFramebuffer,T,M,n.COLOR_ATTACHMENT0,de,0);m(M)&&p(de),t.unbindTexture()}T.depthBuffer&&De(T)}function Ke(T){const M=T.textures;for(let F=0,Y=M.length;F<Y;F++){const $=M[F];if(m($)){const q=E(T),ve=i.get($).__webglTexture;t.bindTexture(q,ve),p(q),t.unbindTexture()}}}const yt=[],D=[];function Ot(T){if(T.samples>0){if(ze(T)===!1){const M=T.textures,F=T.width,Y=T.height;let $=n.COLOR_BUFFER_BIT;const q=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ve=i.get(T),de=M.length>1;if(de)for(let _e=0;_e<M.length;_e++)t.bindFramebuffer(n.FRAMEBUFFER,ve.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+_e,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,ve.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+_e,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,ve.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ve.__webglFramebuffer);for(let _e=0;_e<M.length;_e++){if(T.resolveDepthBuffer&&(T.depthBuffer&&($|=n.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&($|=n.STENCIL_BUFFER_BIT)),de){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,ve.__webglColorRenderbuffer[_e]);const ot=i.get(M[_e]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ot,0)}n.blitFramebuffer(0,0,F,Y,0,0,F,Y,$,n.NEAREST),l===!0&&(yt.length=0,D.length=0,yt.push(n.COLOR_ATTACHMENT0+_e),T.depthBuffer&&T.resolveDepthBuffer===!1&&(yt.push(q),D.push(q),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,D)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,yt))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),de)for(let _e=0;_e<M.length;_e++){t.bindFramebuffer(n.FRAMEBUFFER,ve.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+_e,n.RENDERBUFFER,ve.__webglColorRenderbuffer[_e]);const ot=i.get(M[_e]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,ve.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+_e,n.TEXTURE_2D,ot,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ve.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.resolveDepthBuffer===!1&&l){const M=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[M])}}}function Ze(T){return Math.min(r.maxSamples,T.samples)}function ze(T){const M=i.get(T);return T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function Te(T){const M=o.render.frame;u.get(T)!==M&&(u.set(T,M),T.update())}function ct(T,M){const F=T.colorSpace,Y=T.format,$=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||F!==As&&F!==Di&&(at.getTransfer(F)===gt?(Y!==Ln||$!==mi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",F)),M}function Pe(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(c.width=T.naturalWidth||T.width,c.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(c.width=T.displayWidth,c.height=T.displayHeight):(c.width=T.width,c.height=T.height),c}this.allocateTextureUnit=B,this.resetTextureUnits=k,this.setTexture2D=J,this.setTexture2DArray=H,this.setTexture3D=te,this.setTextureCube=I,this.rebindTextures=ye,this.setupRenderTarget=xt,this.updateRenderTargetMipmap=Ke,this.updateMultisampleRenderTarget=Ot,this.setupDepthRenderbuffer=De,this.setupFrameBufferTexture=ne,this.useMultisampledRTT=ze}function vy(n,e){function t(i,r=Di){let s;const o=at.getTransfer(r);if(i===mi)return n.UNSIGNED_BYTE;if(i===Lu)return n.UNSIGNED_SHORT_4_4_4_4;if(i===Du)return n.UNSIGNED_SHORT_5_5_5_1;if(i===dp)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===up)return n.BYTE;if(i===fp)return n.SHORT;if(i===po)return n.UNSIGNED_SHORT;if(i===Iu)return n.INT;if(i===fr)return n.UNSIGNED_INT;if(i===Hn)return n.FLOAT;if(i===So)return n.HALF_FLOAT;if(i===hp)return n.ALPHA;if(i===pp)return n.RGB;if(i===Ln)return n.RGBA;if(i===mp)return n.LUMINANCE;if(i===gp)return n.LUMINANCE_ALPHA;if(i===es)return n.DEPTH_COMPONENT;if(i===ps)return n.DEPTH_STENCIL;if(i===Nu)return n.RED;if(i===Uu)return n.RED_INTEGER;if(i===_p)return n.RG;if(i===Ou)return n.RG_INTEGER;if(i===Fu)return n.RGBA_INTEGER;if(i===xa||i===Sa||i===ya||i===Ma)if(o===gt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(i===xa)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===Sa)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===ya)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===Ma)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(i===xa)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===Sa)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===ya)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===Ma)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===Fc||i===kc||i===Bc||i===zc)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(i===Fc)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===kc)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Bc)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===zc)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===Hc||i===Vc||i===Gc)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(i===Hc||i===Vc)return o===gt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(i===Gc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===Wc||i===Xc||i===qc||i===Yc||i===Kc||i===Zc||i===$c||i===jc||i===Jc||i===Qc||i===eu||i===tu||i===nu||i===iu)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(i===Wc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Xc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===qc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Yc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===Kc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===Zc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===$c)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===jc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Jc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Qc)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===eu)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===tu)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===nu)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===iu)return o===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Ea||i===ru||i===su)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(i===Ea)return o===gt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===ru)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===su)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===vp||i===ou||i===au||i===lu)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(i===Ea)return s.COMPRESSED_RED_RGTC1_EXT;if(i===ou)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===au)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===lu)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===hs?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}class xy extends Mn{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class Dn extends qt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Sy={type:"move"};class Xl{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Dn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Dn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new z,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new z),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Dn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new z,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new z),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,o=null;const a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(const _ of e.hand.values()){const m=t.getJointPose(_,i),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const u=c.joints["index-finger-tip"],d=c.joints["thumb-tip"],f=u.position.distanceTo(d.position),h=.02,g=.005;c.inputState.pinching&&f>h+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&f<=h-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(a.matrix.fromArray(r.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,r.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(r.linearVelocity)):a.hasLinearVelocity=!1,r.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(r.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Sy)))}return a!==null&&(a.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new Dn;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}const yy=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,My=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Ey{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,i){if(this.texture===null){const r=new Qt,s=e.properties.get(r);s.__webglTexture=t.texture,(t.depthNear!=i.depthNear||t.depthFar!=i.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,i=new gi({vertexShader:yy,fragmentShader:My,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new je(new _i(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class by extends Ts{constructor(e,t){super();const i=this;let r=null,s=1,o=null,a="local-floor",l=1,c=null,u=null,d=null,f=null,h=null,g=null;const _=new Ey,m=t.getContextAttributes();let p=null,E=null;const S=[],y=[],C=new nt;let R=null;const A=new Mn;A.viewport=new Ut;const P=new Mn;P.viewport=new Ut;const x=[A,P],v=new xy;let w=null,k=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let re=S[K];return re===void 0&&(re=new Xl,S[K]=re),re.getTargetRaySpace()},this.getControllerGrip=function(K){let re=S[K];return re===void 0&&(re=new Xl,S[K]=re),re.getGripSpace()},this.getHand=function(K){let re=S[K];return re===void 0&&(re=new Xl,S[K]=re),re.getHandSpace()};function B(K){const re=y.indexOf(K.inputSource);if(re===-1)return;const ne=S[re];ne!==void 0&&(ne.update(K.inputSource,K.frame,c||o),ne.dispatchEvent({type:K.type,data:K.inputSource}))}function X(){r.removeEventListener("select",B),r.removeEventListener("selectstart",B),r.removeEventListener("selectend",B),r.removeEventListener("squeeze",B),r.removeEventListener("squeezestart",B),r.removeEventListener("squeezeend",B),r.removeEventListener("end",X),r.removeEventListener("inputsourceschange",J);for(let K=0;K<S.length;K++){const re=y[K];re!==null&&(y[K]=null,S[K].disconnect(re))}w=null,k=null,_.reset(),e.setRenderTarget(p),h=null,f=null,d=null,r=null,E=null,Je.stop(),i.isPresenting=!1,e.setPixelRatio(R),e.setSize(C.width,C.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){s=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){a=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(K){c=K},this.getBaseLayer=function(){return f!==null?f:h},this.getBinding=function(){return d},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(K){if(r=K,r!==null){if(p=e.getRenderTarget(),r.addEventListener("select",B),r.addEventListener("selectstart",B),r.addEventListener("selectend",B),r.addEventListener("squeeze",B),r.addEventListener("squeezestart",B),r.addEventListener("squeezeend",B),r.addEventListener("end",X),r.addEventListener("inputsourceschange",J),m.xrCompatible!==!0&&await t.makeXRCompatible(),R=e.getPixelRatio(),e.getSize(C),r.renderState.layers===void 0){const re={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:s};h=new XRWebGLLayer(r,t,re),r.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),E=new dr(h.framebufferWidth,h.framebufferHeight,{format:Ln,type:mi,colorSpace:e.outputColorSpace,stencilBuffer:m.stencil})}else{let re=null,ne=null,ce=null;m.depth&&(ce=m.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,re=m.stencil?ps:es,ne=m.stencil?hs:fr);const Re={colorFormat:t.RGBA8,depthFormat:ce,scaleFactor:s};d=new XRWebGLBinding(r,t),f=d.createProjectionLayer(Re),r.updateRenderState({layers:[f]}),e.setPixelRatio(1),e.setSize(f.textureWidth,f.textureHeight,!1),E=new dr(f.textureWidth,f.textureHeight,{format:Ln,type:mi,depthTexture:new Lp(f.textureWidth,f.textureHeight,ne,void 0,void 0,void 0,void 0,void 0,void 0,re),stencilBuffer:m.stencil,colorSpace:e.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await r.requestReferenceSpace(a),Je.setContext(r),Je.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function J(K){for(let re=0;re<K.removed.length;re++){const ne=K.removed[re],ce=y.indexOf(ne);ce>=0&&(y[ce]=null,S[ce].disconnect(ne))}for(let re=0;re<K.added.length;re++){const ne=K.added[re];let ce=y.indexOf(ne);if(ce===-1){for(let De=0;De<S.length;De++)if(De>=y.length){y.push(ne),ce=De;break}else if(y[De]===null){y[De]=ne,ce=De;break}if(ce===-1)break}const Re=S[ce];Re&&Re.connect(ne)}}const H=new z,te=new z;function I(K,re,ne){H.setFromMatrixPosition(re.matrixWorld),te.setFromMatrixPosition(ne.matrixWorld);const ce=H.distanceTo(te),Re=re.projectionMatrix.elements,De=ne.projectionMatrix.elements,ye=Re[14]/(Re[10]-1),xt=Re[14]/(Re[10]+1),Ke=(Re[9]+1)/Re[5],yt=(Re[9]-1)/Re[5],D=(Re[8]-1)/Re[0],Ot=(De[8]+1)/De[0],Ze=ye*D,ze=ye*Ot,Te=ce/(-D+Ot),ct=Te*-D;if(re.matrixWorld.decompose(K.position,K.quaternion,K.scale),K.translateX(ct),K.translateZ(Te),K.matrixWorld.compose(K.position,K.quaternion,K.scale),K.matrixWorldInverse.copy(K.matrixWorld).invert(),Re[10]===-1)K.projectionMatrix.copy(re.projectionMatrix),K.projectionMatrixInverse.copy(re.projectionMatrixInverse);else{const Pe=ye+Te,T=xt+Te,M=Ze-ct,F=ze+(ce-ct),Y=Ke*xt/T*Pe,$=yt*xt/T*Pe;K.projectionMatrix.makePerspective(M,F,Y,$,Pe,T),K.projectionMatrixInverse.copy(K.projectionMatrix).invert()}}function Z(K,re){re===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(re.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(r===null)return;let re=K.near,ne=K.far;_.texture!==null&&(_.depthNear>0&&(re=_.depthNear),_.depthFar>0&&(ne=_.depthFar)),v.near=P.near=A.near=re,v.far=P.far=A.far=ne,(w!==v.near||k!==v.far)&&(r.updateRenderState({depthNear:v.near,depthFar:v.far}),w=v.near,k=v.far),A.layers.mask=K.layers.mask|2,P.layers.mask=K.layers.mask|4,v.layers.mask=A.layers.mask|P.layers.mask;const ce=K.parent,Re=v.cameras;Z(v,ce);for(let De=0;De<Re.length;De++)Z(Re[De],ce);Re.length===2?I(v,A,P):v.projectionMatrix.copy(A.projectionMatrix),Q(K,v,ce)};function Q(K,re,ne){ne===null?K.matrix.copy(re.matrixWorld):(K.matrix.copy(ne.matrixWorld),K.matrix.invert(),K.matrix.multiply(re.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(re.projectionMatrix),K.projectionMatrixInverse.copy(re.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=uu*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(f===null&&h===null))return l},this.setFoveation=function(K){l=K,f!==null&&(f.fixedFoveation=K),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=K)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(v)};let se=null;function Me(K,re){if(u=re.getViewerPose(c||o),g=re,u!==null){const ne=u.views;h!==null&&(e.setRenderTargetFramebuffer(E,h.framebuffer),e.setRenderTarget(E));let ce=!1;ne.length!==v.cameras.length&&(v.cameras.length=0,ce=!0);for(let De=0;De<ne.length;De++){const ye=ne[De];let xt=null;if(h!==null)xt=h.getViewport(ye);else{const yt=d.getViewSubImage(f,ye);xt=yt.viewport,De===0&&(e.setRenderTargetTextures(E,yt.colorTexture,f.ignoreDepthValues?void 0:yt.depthStencilTexture),e.setRenderTarget(E))}let Ke=x[De];Ke===void 0&&(Ke=new Mn,Ke.layers.enable(De),Ke.viewport=new Ut,x[De]=Ke),Ke.matrix.fromArray(ye.transform.matrix),Ke.matrix.decompose(Ke.position,Ke.quaternion,Ke.scale),Ke.projectionMatrix.fromArray(ye.projectionMatrix),Ke.projectionMatrixInverse.copy(Ke.projectionMatrix).invert(),Ke.viewport.set(xt.x,xt.y,xt.width,xt.height),De===0&&(v.matrix.copy(Ke.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),ce===!0&&v.cameras.push(Ke)}const Re=r.enabledFeatures;if(Re&&Re.includes("depth-sensing")){const De=d.getDepthInformation(ne[0]);De&&De.isValid&&De.texture&&_.init(e,De,r.renderState)}}for(let ne=0;ne<S.length;ne++){const ce=y[ne],Re=S[ne];ce!==null&&Re!==void 0&&Re.update(ce,re,c||o)}se&&se(K,re),re.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:re}),g=null}const Je=new Pp;Je.setAnimationLoop(Me),this.setAnimationLoop=function(K){se=K},this.dispose=function(){}}}const Qi=new Zn,Ay=new St;function Ty(n,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function i(m,p){p.color.getRGB(m.fogColor.value,wp(n)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function r(m,p,E,S,y){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),d(m,p)):p.isMeshPhongMaterial?(s(m,p),u(m,p)):p.isMeshStandardMaterial?(s(m,p),f(m,p),p.isMeshPhysicalMaterial&&h(m,p,y)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),_(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,E,S):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===sn&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===sn&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const E=e.get(p),S=E.envMap,y=E.envMapRotation;S&&(m.envMap.value=S,Qi.copy(y),Qi.x*=-1,Qi.y*=-1,Qi.z*=-1,S.isCubeTexture&&S.isRenderTargetTexture===!1&&(Qi.y*=-1,Qi.z*=-1),m.envMapRotation.value.setFromMatrix4(Ay.makeRotationFromEuler(Qi)),m.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,E,S){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*E,m.scale.value=S*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function u(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function d(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function f(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function h(m,p,E){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===sn&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=E.texture,m.transmissionSamplerSize.value.set(E.width,E.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const E=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(E.matrixWorld),m.nearDistance.value=E.shadow.camera.near,m.farDistance.value=E.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function wy(n,e,t,i){let r={},s={},o=[];const a=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function l(E,S){const y=S.program;i.uniformBlockBinding(E,y)}function c(E,S){let y=r[E.id];y===void 0&&(g(E),y=u(E),r[E.id]=y,E.addEventListener("dispose",m));const C=S.program;i.updateUBOMapping(E,C);const R=e.render.frame;s[E.id]!==R&&(f(E),s[E.id]=R)}function u(E){const S=d();E.__bindingPointIndex=S;const y=n.createBuffer(),C=E.__size,R=E.usage;return n.bindBuffer(n.UNIFORM_BUFFER,y),n.bufferData(n.UNIFORM_BUFFER,C,R),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,S,y),y}function d(){for(let E=0;E<a;E++)if(o.indexOf(E)===-1)return o.push(E),E;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(E){const S=r[E.id],y=E.uniforms,C=E.__cache;n.bindBuffer(n.UNIFORM_BUFFER,S);for(let R=0,A=y.length;R<A;R++){const P=Array.isArray(y[R])?y[R]:[y[R]];for(let x=0,v=P.length;x<v;x++){const w=P[x];if(h(w,R,x,C)===!0){const k=w.__offset,B=Array.isArray(w.value)?w.value:[w.value];let X=0;for(let J=0;J<B.length;J++){const H=B[J],te=_(H);typeof H=="number"||typeof H=="boolean"?(w.__data[0]=H,n.bufferSubData(n.UNIFORM_BUFFER,k+X,w.__data)):H.isMatrix3?(w.__data[0]=H.elements[0],w.__data[1]=H.elements[1],w.__data[2]=H.elements[2],w.__data[3]=0,w.__data[4]=H.elements[3],w.__data[5]=H.elements[4],w.__data[6]=H.elements[5],w.__data[7]=0,w.__data[8]=H.elements[6],w.__data[9]=H.elements[7],w.__data[10]=H.elements[8],w.__data[11]=0):(H.toArray(w.__data,X),X+=te.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,k,w.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function h(E,S,y,C){const R=E.value,A=S+"_"+y;if(C[A]===void 0)return typeof R=="number"||typeof R=="boolean"?C[A]=R:C[A]=R.clone(),!0;{const P=C[A];if(typeof R=="number"||typeof R=="boolean"){if(P!==R)return C[A]=R,!0}else if(P.equals(R)===!1)return P.copy(R),!0}return!1}function g(E){const S=E.uniforms;let y=0;const C=16;for(let A=0,P=S.length;A<P;A++){const x=Array.isArray(S[A])?S[A]:[S[A]];for(let v=0,w=x.length;v<w;v++){const k=x[v],B=Array.isArray(k.value)?k.value:[k.value];for(let X=0,J=B.length;X<J;X++){const H=B[X],te=_(H),I=y%C,Z=I%te.boundary,Q=I+Z;y+=Z,Q!==0&&C-Q<te.storage&&(y+=C-Q),k.__data=new Float32Array(te.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=y,y+=te.storage}}}const R=y%C;return R>0&&(y+=C-R),E.__size=y,E.__cache={},this}function _(E){const S={boundary:0,storage:0};return typeof E=="number"||typeof E=="boolean"?(S.boundary=4,S.storage=4):E.isVector2?(S.boundary=8,S.storage=8):E.isVector3||E.isColor?(S.boundary=16,S.storage=12):E.isVector4?(S.boundary=16,S.storage=16):E.isMatrix3?(S.boundary=48,S.storage=48):E.isMatrix4?(S.boundary=64,S.storage=64):E.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",E),S}function m(E){const S=E.target;S.removeEventListener("dispose",m);const y=o.indexOf(S.__bindingPointIndex);o.splice(y,1),n.deleteBuffer(r[S.id]),delete r[S.id],delete s[S.id]}function p(){for(const E in r)n.deleteBuffer(r[E]);o=[],r={},s={}}return{bind:l,update:c,dispose:p}}class Ry{constructor(e={}){const{canvas:t=m_(),context:i=null,depth:r=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:d=!1,reverseDepthBuffer:f=!1}=e;this.isWebGLRenderer=!0;let h;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");h=i.getContextAttributes().alpha}else h=o;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const E=[],S=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=jt,this.toneMapping=Bi,this.toneMappingExposure=1;const y=this;let C=!1,R=0,A=0,P=null,x=-1,v=null;const w=new Ut,k=new Ut;let B=null;const X=new et(0);let J=0,H=t.width,te=t.height,I=1,Z=null,Q=null;const se=new Ut(0,0,H,te),Me=new Ut(0,0,H,te);let Je=!1;const K=new Bu;let re=!1,ne=!1;const ce=new St,Re=new St,De=new z,ye=new Ut,xt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ke=!1;function yt(){return P===null?I:1}let D=i;function Ot(b,N){return t.getContext(b,N)}try{const b={alpha:!0,depth:r,stencil:s,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:u,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ru}`),t.addEventListener("webglcontextlost",ee,!1),t.addEventListener("webglcontextrestored",me,!1),t.addEventListener("webglcontextcreationerror",he,!1),D===null){const N="webgl2";if(D=Ot(N,b),D===null)throw Ot(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(b){throw console.error("THREE.WebGLRenderer: "+b.message),b}let Ze,ze,Te,ct,Pe,T,M,F,Y,$,q,ve,de,_e,ot,oe,xe,Le,Oe,Se,rt,Xe,Mt,L;function fe(){Ze=new Dx(D),Ze.init(),Xe=new vy(D,Ze),ze=new wx(D,Ze,e,Xe),Te=new my(D,Ze),ze.reverseDepthBuffer&&f&&Te.buffers.depth.setReversed(!0),ct=new Ox(D),Pe=new ey,T=new _y(D,Ze,Te,Pe,ze,Xe,ct),M=new Cx(y),F=new Lx(y),Y=new G_(D),Mt=new Ax(D,Y),$=new Nx(D,Y,ct,Mt),q=new kx(D,$,Y,ct),Oe=new Fx(D,ze,T),oe=new Rx(Pe),ve=new QS(y,M,F,Ze,ze,Mt,oe),de=new Ty(y,Pe),_e=new ny,ot=new ly(Ze),Le=new bx(y,M,F,Te,q,h,l),xe=new hy(y,q,ze),L=new wy(D,ct,ze,Te),Se=new Tx(D,Ze,ct),rt=new Ux(D,Ze,ct),ct.programs=ve.programs,y.capabilities=ze,y.extensions=Ze,y.properties=Pe,y.renderLists=_e,y.shadowMap=xe,y.state=Te,y.info=ct}fe();const W=new by(y,D);this.xr=W,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){const b=Ze.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){const b=Ze.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return I},this.setPixelRatio=function(b){b!==void 0&&(I=b,this.setSize(H,te,!1))},this.getSize=function(b){return b.set(H,te)},this.setSize=function(b,N,V=!0){if(W.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}H=b,te=N,t.width=Math.floor(b*I),t.height=Math.floor(N*I),V===!0&&(t.style.width=b+"px",t.style.height=N+"px"),this.setViewport(0,0,b,N)},this.getDrawingBufferSize=function(b){return b.set(H*I,te*I).floor()},this.setDrawingBufferSize=function(b,N,V){H=b,te=N,I=V,t.width=Math.floor(b*V),t.height=Math.floor(N*V),this.setViewport(0,0,b,N)},this.getCurrentViewport=function(b){return b.copy(w)},this.getViewport=function(b){return b.copy(se)},this.setViewport=function(b,N,V,G){b.isVector4?se.set(b.x,b.y,b.z,b.w):se.set(b,N,V,G),Te.viewport(w.copy(se).multiplyScalar(I).round())},this.getScissor=function(b){return b.copy(Me)},this.setScissor=function(b,N,V,G){b.isVector4?Me.set(b.x,b.y,b.z,b.w):Me.set(b,N,V,G),Te.scissor(k.copy(Me).multiplyScalar(I).round())},this.getScissorTest=function(){return Je},this.setScissorTest=function(b){Te.setScissorTest(Je=b)},this.setOpaqueSort=function(b){Z=b},this.setTransparentSort=function(b){Q=b},this.getClearColor=function(b){return b.copy(Le.getClearColor())},this.setClearColor=function(){Le.setClearColor.apply(Le,arguments)},this.getClearAlpha=function(){return Le.getClearAlpha()},this.setClearAlpha=function(){Le.setClearAlpha.apply(Le,arguments)},this.clear=function(b=!0,N=!0,V=!0){let G=0;if(b){let U=!1;if(P!==null){const ae=P.texture.format;U=ae===Fu||ae===Ou||ae===Uu}if(U){const ae=P.texture.type,pe=ae===mi||ae===fr||ae===po||ae===hs||ae===Lu||ae===Du,Ee=Le.getClearColor(),be=Le.getClearAlpha(),Fe=Ee.r,Ge=Ee.g,Ae=Ee.b;pe?(g[0]=Fe,g[1]=Ge,g[2]=Ae,g[3]=be,D.clearBufferuiv(D.COLOR,0,g)):(_[0]=Fe,_[1]=Ge,_[2]=Ae,_[3]=be,D.clearBufferiv(D.COLOR,0,_))}else G|=D.COLOR_BUFFER_BIT}N&&(G|=D.DEPTH_BUFFER_BIT),V&&(G|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),D.clear(G)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ee,!1),t.removeEventListener("webglcontextrestored",me,!1),t.removeEventListener("webglcontextcreationerror",he,!1),_e.dispose(),ot.dispose(),Pe.dispose(),M.dispose(),F.dispose(),q.dispose(),Mt.dispose(),L.dispose(),ve.dispose(),W.dispose(),W.removeEventListener("sessionstart",df),W.removeEventListener("sessionend",hf),Yi.stop()};function ee(b){b.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),C=!0}function me(){console.log("THREE.WebGLRenderer: Context Restored."),C=!1;const b=ct.autoReset,N=xe.enabled,V=xe.autoUpdate,G=xe.needsUpdate,U=xe.type;fe(),ct.autoReset=b,xe.enabled=N,xe.autoUpdate=V,xe.needsUpdate=G,xe.type=U}function he(b){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function Ve(b){const N=b.target;N.removeEventListener("dispose",Ve),Lt(N)}function Lt(b){Yt(b),Pe.remove(b)}function Yt(b){const N=Pe.get(b).programs;N!==void 0&&(N.forEach(function(V){ve.releaseProgram(V)}),b.isShaderMaterial&&ve.releaseShaderCache(b))}this.renderBufferDirect=function(b,N,V,G,U,ae){N===null&&(N=xt);const pe=U.isMesh&&U.matrixWorld.determinant()<0,Ee=Mg(b,N,V,G,U);Te.setMaterial(G,pe);let be=V.index,Fe=1;if(G.wireframe===!0){if(be=$.getWireframeAttribute(V),be===void 0)return;Fe=2}const Ge=V.drawRange,Ae=V.attributes.position;let lt=Ge.start*Fe,Et=(Ge.start+Ge.count)*Fe;ae!==null&&(lt=Math.max(lt,ae.start*Fe),Et=Math.min(Et,(ae.start+ae.count)*Fe)),be!==null?(lt=Math.max(lt,0),Et=Math.min(Et,be.count)):Ae!=null&&(lt=Math.max(lt,0),Et=Math.min(Et,Ae.count));const Tt=Et-lt;if(Tt<0||Tt===1/0)return;Mt.setup(U,G,Ee,V,be);let on,ut=Se;if(be!==null&&(on=Y.get(be),ut=rt,ut.setIndex(on)),U.isMesh)G.wireframe===!0?(Te.setLineWidth(G.wireframeLinewidth*yt()),ut.setMode(D.LINES)):ut.setMode(D.TRIANGLES);else if(U.isLine){let we=G.linewidth;we===void 0&&(we=1),Te.setLineWidth(we*yt()),U.isLineSegments?ut.setMode(D.LINES):U.isLineLoop?ut.setMode(D.LINE_LOOP):ut.setMode(D.LINE_STRIP)}else U.isPoints?ut.setMode(D.POINTS):U.isSprite&&ut.setMode(D.TRIANGLES);if(U.isBatchedMesh)if(U._multiDrawInstances!==null)ut.renderMultiDrawInstances(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount,U._multiDrawInstances);else if(Ze.get("WEBGL_multi_draw"))ut.renderMultiDraw(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount);else{const we=U._multiDrawStarts,Qn=U._multiDrawCounts,ft=U._multiDrawCount,wn=be?Y.get(be).bytesPerElement:1,br=Pe.get(G).currentProgram.getUniforms();for(let fn=0;fn<ft;fn++)br.setValue(D,"_gl_DrawID",fn),ut.render(we[fn]/wn,Qn[fn])}else if(U.isInstancedMesh)ut.renderInstances(lt,Tt,U.count);else if(V.isInstancedBufferGeometry){const we=V._maxInstanceCount!==void 0?V._maxInstanceCount:1/0,Qn=Math.min(V.instanceCount,we);ut.renderInstances(lt,Tt,Qn)}else ut.render(lt,Tt)};function pt(b,N,V){b.transparent===!0&&b.side===gn&&b.forceSinglePass===!1?(b.side=sn,b.needsUpdate=!0,Ro(b,N,V),b.side=Kn,b.needsUpdate=!0,Ro(b,N,V),b.side=gn):Ro(b,N,V)}this.compile=function(b,N,V=null){V===null&&(V=b),p=ot.get(V),p.init(N),S.push(p),V.traverseVisible(function(U){U.isLight&&U.layers.test(N.layers)&&(p.pushLight(U),U.castShadow&&p.pushShadow(U))}),b!==V&&b.traverseVisible(function(U){U.isLight&&U.layers.test(N.layers)&&(p.pushLight(U),U.castShadow&&p.pushShadow(U))}),p.setupLights();const G=new Set;return b.traverse(function(U){if(!(U.isMesh||U.isPoints||U.isLine||U.isSprite))return;const ae=U.material;if(ae)if(Array.isArray(ae))for(let pe=0;pe<ae.length;pe++){const Ee=ae[pe];pt(Ee,V,U),G.add(Ee)}else pt(ae,V,U),G.add(ae)}),S.pop(),p=null,G},this.compileAsync=function(b,N,V=null){const G=this.compile(b,N,V);return new Promise(U=>{function ae(){if(G.forEach(function(pe){Pe.get(pe).currentProgram.isReady()&&G.delete(pe)}),G.size===0){U(b);return}setTimeout(ae,10)}Ze.get("KHR_parallel_shader_compile")!==null?ae():setTimeout(ae,10)})};let Tn=null;function Jn(b){Tn&&Tn(b)}function df(){Yi.stop()}function hf(){Yi.start()}const Yi=new Pp;Yi.setAnimationLoop(Jn),typeof self<"u"&&Yi.setContext(self),this.setAnimationLoop=function(b){Tn=b,W.setAnimationLoop(b),b===null?Yi.stop():Yi.start()},W.addEventListener("sessionstart",df),W.addEventListener("sessionend",hf),this.render=function(b,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(C===!0)return;if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),W.enabled===!0&&W.isPresenting===!0&&(W.cameraAutoUpdate===!0&&W.updateCamera(N),N=W.getCamera()),b.isScene===!0&&b.onBeforeRender(y,b,N,P),p=ot.get(b,S.length),p.init(N),S.push(p),Re.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),K.setFromProjectionMatrix(Re),ne=this.localClippingEnabled,re=oe.init(this.clippingPlanes,ne),m=_e.get(b,E.length),m.init(),E.push(m),W.enabled===!0&&W.isPresenting===!0){const ae=y.xr.getDepthSensingMesh();ae!==null&&ml(ae,N,-1/0,y.sortObjects)}ml(b,N,0,y.sortObjects),m.finish(),y.sortObjects===!0&&m.sort(Z,Q),Ke=W.enabled===!1||W.isPresenting===!1||W.hasDepthSensing()===!1,Ke&&Le.addToRenderList(m,b),this.info.render.frame++,re===!0&&oe.beginShadows();const V=p.state.shadowsArray;xe.render(V,b,N),re===!0&&oe.endShadows(),this.info.autoReset===!0&&this.info.reset();const G=m.opaque,U=m.transmissive;if(p.setupLights(),N.isArrayCamera){const ae=N.cameras;if(U.length>0)for(let pe=0,Ee=ae.length;pe<Ee;pe++){const be=ae[pe];mf(G,U,b,be)}Ke&&Le.render(b);for(let pe=0,Ee=ae.length;pe<Ee;pe++){const be=ae[pe];pf(m,b,be,be.viewport)}}else U.length>0&&mf(G,U,b,N),Ke&&Le.render(b),pf(m,b,N);P!==null&&(T.updateMultisampleRenderTarget(P),T.updateRenderTargetMipmap(P)),b.isScene===!0&&b.onAfterRender(y,b,N),Mt.resetDefaultState(),x=-1,v=null,S.pop(),S.length>0?(p=S[S.length-1],re===!0&&oe.setGlobalState(y.clippingPlanes,p.state.camera)):p=null,E.pop(),E.length>0?m=E[E.length-1]:m=null};function ml(b,N,V,G){if(b.visible===!1)return;if(b.layers.test(N.layers)){if(b.isGroup)V=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(N);else if(b.isLight)p.pushLight(b),b.castShadow&&p.pushShadow(b);else if(b.isSprite){if(!b.frustumCulled||K.intersectsSprite(b)){G&&ye.setFromMatrixPosition(b.matrixWorld).applyMatrix4(Re);const pe=q.update(b),Ee=b.material;Ee.visible&&m.push(b,pe,Ee,V,ye.z,null)}}else if((b.isMesh||b.isLine||b.isPoints)&&(!b.frustumCulled||K.intersectsObject(b))){const pe=q.update(b),Ee=b.material;if(G&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),ye.copy(b.boundingSphere.center)):(pe.boundingSphere===null&&pe.computeBoundingSphere(),ye.copy(pe.boundingSphere.center)),ye.applyMatrix4(b.matrixWorld).applyMatrix4(Re)),Array.isArray(Ee)){const be=pe.groups;for(let Fe=0,Ge=be.length;Fe<Ge;Fe++){const Ae=be[Fe],lt=Ee[Ae.materialIndex];lt&&lt.visible&&m.push(b,pe,lt,V,ye.z,Ae)}}else Ee.visible&&m.push(b,pe,Ee,V,ye.z,null)}}const ae=b.children;for(let pe=0,Ee=ae.length;pe<Ee;pe++)ml(ae[pe],N,V,G)}function pf(b,N,V,G){const U=b.opaque,ae=b.transmissive,pe=b.transparent;p.setupLightsView(V),re===!0&&oe.setGlobalState(y.clippingPlanes,V),G&&Te.viewport(w.copy(G)),U.length>0&&wo(U,N,V),ae.length>0&&wo(ae,N,V),pe.length>0&&wo(pe,N,V),Te.buffers.depth.setTest(!0),Te.buffers.depth.setMask(!0),Te.buffers.color.setMask(!0),Te.setPolygonOffset(!1)}function mf(b,N,V,G){if((V.isScene===!0?V.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[G.id]===void 0&&(p.state.transmissionRenderTarget[G.id]=new dr(1,1,{generateMipmaps:!0,type:Ze.has("EXT_color_buffer_half_float")||Ze.has("EXT_color_buffer_float")?So:mi,minFilter:lr,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:at.workingColorSpace}));const ae=p.state.transmissionRenderTarget[G.id],pe=G.viewport||w;ae.setSize(pe.z,pe.w);const Ee=y.getRenderTarget();y.setRenderTarget(ae),y.getClearColor(X),J=y.getClearAlpha(),J<1&&y.setClearColor(16777215,.5),y.clear(),Ke&&Le.render(V);const be=y.toneMapping;y.toneMapping=Bi;const Fe=G.viewport;if(G.viewport!==void 0&&(G.viewport=void 0),p.setupLightsView(G),re===!0&&oe.setGlobalState(y.clippingPlanes,G),wo(b,V,G),T.updateMultisampleRenderTarget(ae),T.updateRenderTargetMipmap(ae),Ze.has("WEBGL_multisampled_render_to_texture")===!1){let Ge=!1;for(let Ae=0,lt=N.length;Ae<lt;Ae++){const Et=N[Ae],Tt=Et.object,on=Et.geometry,ut=Et.material,we=Et.group;if(ut.side===gn&&Tt.layers.test(G.layers)){const Qn=ut.side;ut.side=sn,ut.needsUpdate=!0,gf(Tt,V,G,on,ut,we),ut.side=Qn,ut.needsUpdate=!0,Ge=!0}}Ge===!0&&(T.updateMultisampleRenderTarget(ae),T.updateRenderTargetMipmap(ae))}y.setRenderTarget(Ee),y.setClearColor(X,J),Fe!==void 0&&(G.viewport=Fe),y.toneMapping=be}function wo(b,N,V){const G=N.isScene===!0?N.overrideMaterial:null;for(let U=0,ae=b.length;U<ae;U++){const pe=b[U],Ee=pe.object,be=pe.geometry,Fe=G===null?pe.material:G,Ge=pe.group;Ee.layers.test(V.layers)&&gf(Ee,N,V,be,Fe,Ge)}}function gf(b,N,V,G,U,ae){b.onBeforeRender(y,N,V,G,U,ae),b.modelViewMatrix.multiplyMatrices(V.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),U.onBeforeRender(y,N,V,G,b,ae),U.transparent===!0&&U.side===gn&&U.forceSinglePass===!1?(U.side=sn,U.needsUpdate=!0,y.renderBufferDirect(V,N,G,U,b,ae),U.side=Kn,U.needsUpdate=!0,y.renderBufferDirect(V,N,G,U,b,ae),U.side=gn):y.renderBufferDirect(V,N,G,U,b,ae),b.onAfterRender(y,N,V,G,U,ae)}function Ro(b,N,V){N.isScene!==!0&&(N=xt);const G=Pe.get(b),U=p.state.lights,ae=p.state.shadowsArray,pe=U.state.version,Ee=ve.getParameters(b,U.state,ae,N,V),be=ve.getProgramCacheKey(Ee);let Fe=G.programs;G.environment=b.isMeshStandardMaterial?N.environment:null,G.fog=N.fog,G.envMap=(b.isMeshStandardMaterial?F:M).get(b.envMap||G.environment),G.envMapRotation=G.environment!==null&&b.envMap===null?N.environmentRotation:b.envMapRotation,Fe===void 0&&(b.addEventListener("dispose",Ve),Fe=new Map,G.programs=Fe);let Ge=Fe.get(be);if(Ge!==void 0){if(G.currentProgram===Ge&&G.lightsStateVersion===pe)return vf(b,Ee),Ge}else Ee.uniforms=ve.getUniforms(b),b.onBeforeCompile(Ee,y),Ge=ve.acquireProgram(Ee,be),Fe.set(be,Ge),G.uniforms=Ee.uniforms;const Ae=G.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Ae.clippingPlanes=oe.uniform),vf(b,Ee),G.needsLights=bg(b),G.lightsStateVersion=pe,G.needsLights&&(Ae.ambientLightColor.value=U.state.ambient,Ae.lightProbe.value=U.state.probe,Ae.directionalLights.value=U.state.directional,Ae.directionalLightShadows.value=U.state.directionalShadow,Ae.spotLights.value=U.state.spot,Ae.spotLightShadows.value=U.state.spotShadow,Ae.rectAreaLights.value=U.state.rectArea,Ae.ltc_1.value=U.state.rectAreaLTC1,Ae.ltc_2.value=U.state.rectAreaLTC2,Ae.pointLights.value=U.state.point,Ae.pointLightShadows.value=U.state.pointShadow,Ae.hemisphereLights.value=U.state.hemi,Ae.directionalShadowMap.value=U.state.directionalShadowMap,Ae.directionalShadowMatrix.value=U.state.directionalShadowMatrix,Ae.spotShadowMap.value=U.state.spotShadowMap,Ae.spotLightMatrix.value=U.state.spotLightMatrix,Ae.spotLightMap.value=U.state.spotLightMap,Ae.pointShadowMap.value=U.state.pointShadowMap,Ae.pointShadowMatrix.value=U.state.pointShadowMatrix),G.currentProgram=Ge,G.uniformsList=null,Ge}function _f(b){if(b.uniformsList===null){const N=b.currentProgram.getUniforms();b.uniformsList=ba.seqWithValue(N.seq,b.uniforms)}return b.uniformsList}function vf(b,N){const V=Pe.get(b);V.outputColorSpace=N.outputColorSpace,V.batching=N.batching,V.batchingColor=N.batchingColor,V.instancing=N.instancing,V.instancingColor=N.instancingColor,V.instancingMorph=N.instancingMorph,V.skinning=N.skinning,V.morphTargets=N.morphTargets,V.morphNormals=N.morphNormals,V.morphColors=N.morphColors,V.morphTargetsCount=N.morphTargetsCount,V.numClippingPlanes=N.numClippingPlanes,V.numIntersection=N.numClipIntersection,V.vertexAlphas=N.vertexAlphas,V.vertexTangents=N.vertexTangents,V.toneMapping=N.toneMapping}function Mg(b,N,V,G,U){N.isScene!==!0&&(N=xt),T.resetTextureUnits();const ae=N.fog,pe=G.isMeshStandardMaterial?N.environment:null,Ee=P===null?y.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:As,be=(G.isMeshStandardMaterial?F:M).get(G.envMap||pe),Fe=G.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,Ge=!!V.attributes.tangent&&(!!G.normalMap||G.anisotropy>0),Ae=!!V.morphAttributes.position,lt=!!V.morphAttributes.normal,Et=!!V.morphAttributes.color;let Tt=Bi;G.toneMapped&&(P===null||P.isXRRenderTarget===!0)&&(Tt=y.toneMapping);const on=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,ut=on!==void 0?on.length:0,we=Pe.get(G),Qn=p.state.lights;if(re===!0&&(ne===!0||b!==v)){const _n=b===v&&G.id===x;oe.setState(G,b,_n)}let ft=!1;G.version===we.__version?(we.needsLights&&we.lightsStateVersion!==Qn.state.version||we.outputColorSpace!==Ee||U.isBatchedMesh&&we.batching===!1||!U.isBatchedMesh&&we.batching===!0||U.isBatchedMesh&&we.batchingColor===!0&&U.colorTexture===null||U.isBatchedMesh&&we.batchingColor===!1&&U.colorTexture!==null||U.isInstancedMesh&&we.instancing===!1||!U.isInstancedMesh&&we.instancing===!0||U.isSkinnedMesh&&we.skinning===!1||!U.isSkinnedMesh&&we.skinning===!0||U.isInstancedMesh&&we.instancingColor===!0&&U.instanceColor===null||U.isInstancedMesh&&we.instancingColor===!1&&U.instanceColor!==null||U.isInstancedMesh&&we.instancingMorph===!0&&U.morphTexture===null||U.isInstancedMesh&&we.instancingMorph===!1&&U.morphTexture!==null||we.envMap!==be||G.fog===!0&&we.fog!==ae||we.numClippingPlanes!==void 0&&(we.numClippingPlanes!==oe.numPlanes||we.numIntersection!==oe.numIntersection)||we.vertexAlphas!==Fe||we.vertexTangents!==Ge||we.morphTargets!==Ae||we.morphNormals!==lt||we.morphColors!==Et||we.toneMapping!==Tt||we.morphTargetsCount!==ut)&&(ft=!0):(ft=!0,we.__version=G.version);let wn=we.currentProgram;ft===!0&&(wn=Ro(G,N,U));let br=!1,fn=!1,Ls=!1;const wt=wn.getUniforms(),Nn=we.uniforms;if(Te.useProgram(wn.program)&&(br=!0,fn=!0,Ls=!0),G.id!==x&&(x=G.id,fn=!0),br||v!==b){Te.buffers.depth.getReversed()?(ce.copy(b.projectionMatrix),__(ce),v_(ce),wt.setValue(D,"projectionMatrix",ce)):wt.setValue(D,"projectionMatrix",b.projectionMatrix),wt.setValue(D,"viewMatrix",b.matrixWorldInverse);const vi=wt.map.cameraPosition;vi!==void 0&&vi.setValue(D,De.setFromMatrixPosition(b.matrixWorld)),ze.logarithmicDepthBuffer&&wt.setValue(D,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(G.isMeshPhongMaterial||G.isMeshToonMaterial||G.isMeshLambertMaterial||G.isMeshBasicMaterial||G.isMeshStandardMaterial||G.isShaderMaterial)&&wt.setValue(D,"isOrthographic",b.isOrthographicCamera===!0),v!==b&&(v=b,fn=!0,Ls=!0)}if(U.isSkinnedMesh){wt.setOptional(D,U,"bindMatrix"),wt.setOptional(D,U,"bindMatrixInverse");const _n=U.skeleton;_n&&(_n.boneTexture===null&&_n.computeBoneTexture(),wt.setValue(D,"boneTexture",_n.boneTexture,T))}U.isBatchedMesh&&(wt.setOptional(D,U,"batchingTexture"),wt.setValue(D,"batchingTexture",U._matricesTexture,T),wt.setOptional(D,U,"batchingIdTexture"),wt.setValue(D,"batchingIdTexture",U._indirectTexture,T),wt.setOptional(D,U,"batchingColorTexture"),U._colorsTexture!==null&&wt.setValue(D,"batchingColorTexture",U._colorsTexture,T));const Ds=V.morphAttributes;if((Ds.position!==void 0||Ds.normal!==void 0||Ds.color!==void 0)&&Oe.update(U,V,wn),(fn||we.receiveShadow!==U.receiveShadow)&&(we.receiveShadow=U.receiveShadow,wt.setValue(D,"receiveShadow",U.receiveShadow)),G.isMeshGouraudMaterial&&G.envMap!==null&&(Nn.envMap.value=be,Nn.flipEnvMap.value=be.isCubeTexture&&be.isRenderTargetTexture===!1?-1:1),G.isMeshStandardMaterial&&G.envMap===null&&N.environment!==null&&(Nn.envMapIntensity.value=N.environmentIntensity),fn&&(wt.setValue(D,"toneMappingExposure",y.toneMappingExposure),we.needsLights&&Eg(Nn,Ls),ae&&G.fog===!0&&de.refreshFogUniforms(Nn,ae),de.refreshMaterialUniforms(Nn,G,I,te,p.state.transmissionRenderTarget[b.id]),ba.upload(D,_f(we),Nn,T)),G.isShaderMaterial&&G.uniformsNeedUpdate===!0&&(ba.upload(D,_f(we),Nn,T),G.uniformsNeedUpdate=!1),G.isSpriteMaterial&&wt.setValue(D,"center",U.center),wt.setValue(D,"modelViewMatrix",U.modelViewMatrix),wt.setValue(D,"normalMatrix",U.normalMatrix),wt.setValue(D,"modelMatrix",U.matrixWorld),G.isShaderMaterial||G.isRawShaderMaterial){const _n=G.uniformsGroups;for(let vi=0,xi=_n.length;vi<xi;vi++){const xf=_n[vi];L.update(xf,wn),L.bind(xf,wn)}}return wn}function Eg(b,N){b.ambientLightColor.needsUpdate=N,b.lightProbe.needsUpdate=N,b.directionalLights.needsUpdate=N,b.directionalLightShadows.needsUpdate=N,b.pointLights.needsUpdate=N,b.pointLightShadows.needsUpdate=N,b.spotLights.needsUpdate=N,b.spotLightShadows.needsUpdate=N,b.rectAreaLights.needsUpdate=N,b.hemisphereLights.needsUpdate=N}function bg(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(b,N,V){Pe.get(b.texture).__webglTexture=N,Pe.get(b.depthTexture).__webglTexture=V;const G=Pe.get(b);G.__hasExternalTextures=!0,G.__autoAllocateDepthBuffer=V===void 0,G.__autoAllocateDepthBuffer||Ze.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),G.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(b,N){const V=Pe.get(b);V.__webglFramebuffer=N,V.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(b,N=0,V=0){P=b,R=N,A=V;let G=!0,U=null,ae=!1,pe=!1;if(b){const be=Pe.get(b);if(be.__useDefaultFramebuffer!==void 0)Te.bindFramebuffer(D.FRAMEBUFFER,null),G=!1;else if(be.__webglFramebuffer===void 0)T.setupRenderTarget(b);else if(be.__hasExternalTextures)T.rebindTextures(b,Pe.get(b.texture).__webglTexture,Pe.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){const Ae=b.depthTexture;if(be.__boundDepthTexture!==Ae){if(Ae!==null&&Pe.has(Ae)&&(b.width!==Ae.image.width||b.height!==Ae.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");T.setupDepthRenderbuffer(b)}}const Fe=b.texture;(Fe.isData3DTexture||Fe.isDataArrayTexture||Fe.isCompressedArrayTexture)&&(pe=!0);const Ge=Pe.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(Ge[N])?U=Ge[N][V]:U=Ge[N],ae=!0):b.samples>0&&T.useMultisampledRTT(b)===!1?U=Pe.get(b).__webglMultisampledFramebuffer:Array.isArray(Ge)?U=Ge[V]:U=Ge,w.copy(b.viewport),k.copy(b.scissor),B=b.scissorTest}else w.copy(se).multiplyScalar(I).floor(),k.copy(Me).multiplyScalar(I).floor(),B=Je;if(Te.bindFramebuffer(D.FRAMEBUFFER,U)&&G&&Te.drawBuffers(b,U),Te.viewport(w),Te.scissor(k),Te.setScissorTest(B),ae){const be=Pe.get(b.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+N,be.__webglTexture,V)}else if(pe){const be=Pe.get(b.texture),Fe=N||0;D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,be.__webglTexture,V||0,Fe)}x=-1},this.readRenderTargetPixels=function(b,N,V,G,U,ae,pe){if(!(b&&b.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ee=Pe.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&pe!==void 0&&(Ee=Ee[pe]),Ee){Te.bindFramebuffer(D.FRAMEBUFFER,Ee);try{const be=b.texture,Fe=be.format,Ge=be.type;if(!ze.textureFormatReadable(Fe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ze.textureTypeReadable(Ge)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=b.width-G&&V>=0&&V<=b.height-U&&D.readPixels(N,V,G,U,Xe.convert(Fe),Xe.convert(Ge),ae)}finally{const be=P!==null?Pe.get(P).__webglFramebuffer:null;Te.bindFramebuffer(D.FRAMEBUFFER,be)}}},this.readRenderTargetPixelsAsync=async function(b,N,V,G,U,ae,pe){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ee=Pe.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&pe!==void 0&&(Ee=Ee[pe]),Ee){const be=b.texture,Fe=be.format,Ge=be.type;if(!ze.textureFormatReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ze.textureTypeReadable(Ge))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(N>=0&&N<=b.width-G&&V>=0&&V<=b.height-U){Te.bindFramebuffer(D.FRAMEBUFFER,Ee);const Ae=D.createBuffer();D.bindBuffer(D.PIXEL_PACK_BUFFER,Ae),D.bufferData(D.PIXEL_PACK_BUFFER,ae.byteLength,D.STREAM_READ),D.readPixels(N,V,G,U,Xe.convert(Fe),Xe.convert(Ge),0);const lt=P!==null?Pe.get(P).__webglFramebuffer:null;Te.bindFramebuffer(D.FRAMEBUFFER,lt);const Et=D.fenceSync(D.SYNC_GPU_COMMANDS_COMPLETE,0);return D.flush(),await g_(D,Et,4),D.bindBuffer(D.PIXEL_PACK_BUFFER,Ae),D.getBufferSubData(D.PIXEL_PACK_BUFFER,0,ae),D.deleteBuffer(Ae),D.deleteSync(Et),ae}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(b,N=null,V=0){b.isTexture!==!0&&(Js("WebGLRenderer: copyFramebufferToTexture function signature has changed."),N=arguments[0]||null,b=arguments[1]);const G=Math.pow(2,-V),U=Math.floor(b.image.width*G),ae=Math.floor(b.image.height*G),pe=N!==null?N.x:0,Ee=N!==null?N.y:0;T.setTexture2D(b,0),D.copyTexSubImage2D(D.TEXTURE_2D,V,0,0,pe,Ee,U,ae),Te.unbindTexture()},this.copyTextureToTexture=function(b,N,V=null,G=null,U=0){b.isTexture!==!0&&(Js("WebGLRenderer: copyTextureToTexture function signature has changed."),G=arguments[0]||null,b=arguments[1],N=arguments[2],U=arguments[3]||0,V=null);let ae,pe,Ee,be,Fe,Ge,Ae,lt,Et;const Tt=b.isCompressedTexture?b.mipmaps[U]:b.image;V!==null?(ae=V.max.x-V.min.x,pe=V.max.y-V.min.y,Ee=V.isBox3?V.max.z-V.min.z:1,be=V.min.x,Fe=V.min.y,Ge=V.isBox3?V.min.z:0):(ae=Tt.width,pe=Tt.height,Ee=Tt.depth||1,be=0,Fe=0,Ge=0),G!==null?(Ae=G.x,lt=G.y,Et=G.z):(Ae=0,lt=0,Et=0);const on=Xe.convert(N.format),ut=Xe.convert(N.type);let we;N.isData3DTexture?(T.setTexture3D(N,0),we=D.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(T.setTexture2DArray(N,0),we=D.TEXTURE_2D_ARRAY):(T.setTexture2D(N,0),we=D.TEXTURE_2D),D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,N.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,N.unpackAlignment);const Qn=D.getParameter(D.UNPACK_ROW_LENGTH),ft=D.getParameter(D.UNPACK_IMAGE_HEIGHT),wn=D.getParameter(D.UNPACK_SKIP_PIXELS),br=D.getParameter(D.UNPACK_SKIP_ROWS),fn=D.getParameter(D.UNPACK_SKIP_IMAGES);D.pixelStorei(D.UNPACK_ROW_LENGTH,Tt.width),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,Tt.height),D.pixelStorei(D.UNPACK_SKIP_PIXELS,be),D.pixelStorei(D.UNPACK_SKIP_ROWS,Fe),D.pixelStorei(D.UNPACK_SKIP_IMAGES,Ge);const Ls=b.isDataArrayTexture||b.isData3DTexture,wt=N.isDataArrayTexture||N.isData3DTexture;if(b.isRenderTargetTexture||b.isDepthTexture){const Nn=Pe.get(b),Ds=Pe.get(N),_n=Pe.get(Nn.__renderTarget),vi=Pe.get(Ds.__renderTarget);Te.bindFramebuffer(D.READ_FRAMEBUFFER,_n.__webglFramebuffer),Te.bindFramebuffer(D.DRAW_FRAMEBUFFER,vi.__webglFramebuffer);for(let xi=0;xi<Ee;xi++)Ls&&D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Pe.get(b).__webglTexture,U,Ge+xi),b.isDepthTexture?(wt&&D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Pe.get(N).__webglTexture,U,Et+xi),D.blitFramebuffer(be,Fe,ae,pe,Ae,lt,ae,pe,D.DEPTH_BUFFER_BIT,D.NEAREST)):wt?D.copyTexSubImage3D(we,U,Ae,lt,Et+xi,be,Fe,ae,pe):D.copyTexSubImage2D(we,U,Ae,lt,Et+xi,be,Fe,ae,pe);Te.bindFramebuffer(D.READ_FRAMEBUFFER,null),Te.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else wt?b.isDataTexture||b.isData3DTexture?D.texSubImage3D(we,U,Ae,lt,Et,ae,pe,Ee,on,ut,Tt.data):N.isCompressedArrayTexture?D.compressedTexSubImage3D(we,U,Ae,lt,Et,ae,pe,Ee,on,Tt.data):D.texSubImage3D(we,U,Ae,lt,Et,ae,pe,Ee,on,ut,Tt):b.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,U,Ae,lt,ae,pe,on,ut,Tt.data):b.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,U,Ae,lt,Tt.width,Tt.height,on,Tt.data):D.texSubImage2D(D.TEXTURE_2D,U,Ae,lt,ae,pe,on,ut,Tt);D.pixelStorei(D.UNPACK_ROW_LENGTH,Qn),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,ft),D.pixelStorei(D.UNPACK_SKIP_PIXELS,wn),D.pixelStorei(D.UNPACK_SKIP_ROWS,br),D.pixelStorei(D.UNPACK_SKIP_IMAGES,fn),U===0&&N.generateMipmaps&&D.generateMipmap(we),Te.unbindTexture()},this.copyTextureToTexture3D=function(b,N,V=null,G=null,U=0){return b.isTexture!==!0&&(Js("WebGLRenderer: copyTextureToTexture3D function signature has changed."),V=arguments[0]||null,G=arguments[1]||null,b=arguments[2],N=arguments[3],U=arguments[4]||0),Js('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(b,N,V,G,U)},this.initRenderTarget=function(b){Pe.get(b).__webglFramebuffer===void 0&&T.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?T.setTextureCube(b,0):b.isData3DTexture?T.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?T.setTexture2DArray(b,0):T.setTexture2D(b,0),Te.unbindTexture()},this.resetState=function(){R=0,A=0,P=null,Te.reset(),Mt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=at._getDrawingBufferColorSpace(e),t.unpackColorSpace=at._getUnpackColorSpace()}}class Hu{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new et(e),this.density=t}clone(){return new Hu(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class mo{constructor(e,t=1,i=1e3){this.isFog=!0,this.name="",this.color=new et(e),this.near=t,this.far=i}clone(){return new mo(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class Cy extends qt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Zn,this.environmentIntensity=1,this.environmentRotation=new Zn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class Py{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=cu,this.updateRanges=[],this.version=0,this.uuid=zi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const tn=new z;class Ia{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)tn.fromBufferAttribute(this,t),tn.applyMatrix4(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)tn.fromBufferAttribute(this,t),tn.applyNormalMatrix(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)tn.fromBufferAttribute(this,t),tn.transformDirection(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}getComponent(e,t){let i=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(i=Bn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=vt(i,this.array)),this.data.array[e*this.data.stride+this.offset+t]=i,this}setX(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Bn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Bn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Bn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Bn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array),s=vt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new bt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Ia(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Fp extends ws{static get type(){return"SpriteMaterial"}constructor(e){super(),this.isSpriteMaterial=!0,this.color=new et(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let Br;const ks=new z,zr=new z,Hr=new z,Vr=new nt,Bs=new nt,kp=new St,$o=new z,zs=new z,jo=new z,vd=new nt,ql=new nt,xd=new nt;class Iy extends qt{constructor(e=new Fp){if(super(),this.isSprite=!0,this.type="Sprite",Br===void 0){Br=new Jt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Py(t,5);Br.setIndex([0,1,2,0,2,3]),Br.setAttribute("position",new Ia(i,3,0,!1)),Br.setAttribute("uv",new Ia(i,2,3,!1))}this.geometry=Br,this.material=e,this.center=new nt(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),zr.setFromMatrixScale(this.matrixWorld),kp.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Hr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&zr.multiplyScalar(-Hr.z);const i=this.material.rotation;let r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));const o=this.center;Jo($o.set(-.5,-.5,0),Hr,o,zr,r,s),Jo(zs.set(.5,-.5,0),Hr,o,zr,r,s),Jo(jo.set(.5,.5,0),Hr,o,zr,r,s),vd.set(0,0),ql.set(1,0),xd.set(1,1);let a=e.ray.intersectTriangle($o,zs,jo,!1,ks);if(a===null&&(Jo(zs.set(-.5,.5,0),Hr,o,zr,r,s),ql.set(0,1),a=e.ray.intersectTriangle($o,jo,zs,!1,ks),a===null))return;const l=e.ray.origin.distanceTo(ks);l<e.near||l>e.far||t.push({distance:l,point:ks.clone(),uv:En.getInterpolation(ks,$o,zs,jo,vd,ql,xd,new nt),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Jo(n,e,t,i,r,s){Vr.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(Bs.x=s*Vr.x-r*Vr.y,Bs.y=r*Vr.x+s*Vr.y):Bs.copy(Vr),n.copy(e),n.x+=Bs.x,n.y+=Bs.y,n.applyMatrix4(kp)}class Ly extends Qt{constructor(e=null,t=1,i=1,r,s,o,a,l,c=zt,u=zt,d,f){super(null,o,a,l,c,u,r,s,d,f),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Sd extends bt{constructor(e,t,i,r=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Gr=new St,yd=new St,Qo=[],Md=new vr,Dy=new St,Hs=new je,Vs=new Mo;class Ny extends je{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Sd(new Float32Array(i*16),16),this.instanceColor=null,this.morphTexture=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<i;r++)this.setMatrixAt(r,Dy)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new vr),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Gr),Md.copy(e.boundingBox).applyMatrix4(Gr),this.boundingBox.union(Md)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Mo),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Gr),Vs.copy(e.boundingSphere).applyMatrix4(Gr),this.boundingSphere.union(Vs)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const i=t.morphTargetInfluences,r=this.morphTexture.source.data.data,s=i.length+1,o=e*s+1;for(let a=0;a<i.length;a++)i[a]=r[o+a]}raycast(e,t){const i=this.matrixWorld,r=this.count;if(Hs.geometry=this.geometry,Hs.material=this.material,Hs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Vs.copy(this.boundingSphere),Vs.applyMatrix4(i),e.ray.intersectsSphere(Vs)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,Gr),yd.multiplyMatrices(i,Gr),Hs.matrixWorld=yd,Hs.raycast(e,Qo);for(let o=0,a=Qo.length;o<a;o++){const l=Qo[o];l.instanceId=s,l.object=this,t.push(l)}Qo.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Sd(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const i=t.morphTargetInfluences,r=i.length+1;this.morphTexture===null&&(this.morphTexture=new Ly(new Float32Array(r*this.count),r,this.count,Nu,Hn));const s=this.morphTexture.source.data.data;let o=0;for(let c=0;c<i.length;c++)o+=i[c];const a=this.geometry.morphTargetsRelative?1:1-o,l=r*e;s[l]=a,s.set(i,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}}class Vu extends Qt{constructor(e,t,i,r,s,o,a,l,c){super(e,t,i,r,s,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Gu extends Jt{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const l=Math.min(o+a,Math.PI);let c=0;const u=[],d=new z,f=new z,h=[],g=[],_=[],m=[];for(let p=0;p<=i;p++){const E=[],S=p/i;let y=0;p===0&&o===0?y=.5/t:p===i&&l===Math.PI&&(y=-.5/t);for(let C=0;C<=t;C++){const R=C/t;d.x=-e*Math.cos(r+R*s)*Math.sin(o+S*a),d.y=e*Math.cos(o+S*a),d.z=e*Math.sin(r+R*s)*Math.sin(o+S*a),g.push(d.x,d.y,d.z),f.copy(d).normalize(),_.push(f.x,f.y,f.z),m.push(R+y,1-S),E.push(c++)}u.push(E)}for(let p=0;p<i;p++)for(let E=0;E<t;E++){const S=u[p][E+1],y=u[p][E],C=u[p+1][E],R=u[p+1][E+1];(p!==0||o>0)&&h.push(S,y,R),(p!==i-1||l<Math.PI)&&h.push(y,C,R)}this.setIndex(h),this.setAttribute("position",new Xn(g,3)),this.setAttribute("normal",new Xn(_,3)),this.setAttribute("uv",new Xn(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Gu(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class bn extends ws{static get type(){return"MeshLambertMaterial"}constructor(e){super(),this.isMeshLambertMaterial=!0,this.color=new et(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new et(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=xp,this.normalScale=new nt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Zn,this.combine=Pu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Bp extends qt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new et(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}const Yl=new St,Ed=new z,bd=new z;class Uy{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new nt(512,512),this.map=null,this.mapPass=null,this.matrix=new St,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Bu,this._frameExtents=new nt(1,1),this._viewportCount=1,this._viewports=[new Ut(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;Ed.setFromMatrixPosition(e.matrixWorld),t.position.copy(Ed),bd.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(bd),t.updateMatrixWorld(),Yl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Yl),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Yl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class Oy extends Uy{constructor(){super(new Ip(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Fy extends Bp{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(qt.DEFAULT_UP),this.updateMatrix(),this.target=new qt,this.shadow=new Oy}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class ky extends Bp{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ru}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ru);function By(n,e=100){return{x:n.x*e,y:Math.abs(n.y)*e,z:n.z*e}}function zy(n,e,t,i=100){const r=Math.round(n/2)*2,s=Math.round(e/2)*2,o=By(t,i);return{light:{x:r+o.x,y:o.y,z:s+o.z},target:{x:r,y:0,z:s}}}const du=8900331,zp=40,Hp=140,Hy=1855114,Vy=.09;function Gy(n){let e=n.fog instanceof mo?n.fog:null;e||(e=new mo(du,zp,Hp),n.fog=e);const t=new Hu(Hy,Vy);let i=!1;return{setDayFogColor(r){e.color.setHex(r),i||(n.fog=e)},setDayFogFar(r){e.far=r,i||(n.fog=e)},setUnderwater(r){r!==i&&(i=r,n.fog=r?t:e)}}}function Wy(n){const e=new Ry({canvas:n,antialias:!1});e.setSize(window.innerWidth,window.innerHeight),e.setPixelRatio(Math.min(window.devicePixelRatio,2)),e.shadowMap.type=Cu;const t=new Cy;t.background=new et(du),t.fog=new mo(du,zp,Hp);const i=Gy(t),r=new Fy(16777215,.9);r.castShadow=!0,r.shadow.mapSize.set(2048,2048);const s=r.shadow.camera;s.left=-56,s.right=56,s.top=56,s.bottom=-56,s.near=1,s.far=300,s.updateProjectionMatrix(),t.add(r),t.add(r.target);const o=new ky(16777215,.75);t.add(o);let a=0,l=0;const c=new Mn(70,window.innerWidth/window.innerHeight,.1,1e3);return c.position.set(.5,96,.5),c.rotation.order="YXZ",{scene:t,camera:c,renderer:e,setSize(u,d){c.aspect=u/d,c.updateProjectionMatrix(),e.setSize(u,d)},setDayNight(u,d){const f=zy(a,l,u);r.position.set(f.light.x,f.light.y,f.light.z),r.target.position.set(f.target.x,f.target.y,f.target.z),r.intensity=d.sunIntensity,o.intensity=d.ambient,t.background instanceof et&&t.background.setHex(d.sky),i.setDayFogColor(d.fog)},setSunFocus(u,d){a=u,l=d},setShadowsEnabled(u){e.shadowMap.enabled=u,t.traverse(d=>{if(!(d instanceof je))return;const f=d.material;if(Array.isArray(f))for(const h of f)h.needsUpdate=!0;else f.needsUpdate=!0})},setUnderwater(u){i.setUnderwater(u)},setDayFogFar(u){i.setDayFogFar(u)},dispose(){e.dispose()}}}function Xy(n,e){const t=new Map,i=new Map,r=new Map;function s(o){const a=i.get(o);if(a)return a;const l=new Vu(e(o));l.magFilter=zt,l.minFilter=zt,l.generateMipmaps=!1,l.colorSpace=jt,t.set(o,l);const c=new Fp({map:l,transparent:!0,alphaTest:.1});return i.set(o,c),c}return{syncDrops(o){const a=new Set;for(const l of o){a.add(l.id);let c=r.get(l.id);c?c.material!==s(l.item)&&(c.material=s(l.item)):(c=new Iy(s(l.item)),c.scale.set(.4,.4,1),r.set(l.id,c),n.add(c));const u=Math.sin(l.age*3)*.05;c.position.set(l.pos.x,l.pos.y+.2+u,l.pos.z)}for(const[l,c]of r)a.has(l)||(n.remove(c),r.delete(l))},dispose(){for(const o of r.values())n.remove(o);r.clear();for(const o of i.values())o.dispose();i.clear();for(const o of t.values())o.dispose();t.clear()}}}const qy={zombie:{head:6986330,body:4020864,legs:3821434,arms:5934970},skeleton:{head:14211280,body:14211280,legs:11579560,arms:12895420}},Yy=.1,Ky=.6,Zy=4;function $y(n){const e=new rn(.5,.5,.5),t=new rn(.5,.75,.25),i=new rn(.25,.75,.25),r=new rn(.1,.1,.5),s=new bn({color:4868682}),o=[e,t,i,r],a=new Map,l=new Map;function c(f,h,g,_,m){const p=new Dn;p.name=m,p.position.set(g,_,0);const E=new je(f,h);return E.position.y=-.375,p.add(E),p}function u(f){const h=qy[f],g=w=>new bn({color:w}),_=g(h.head),m=g(h.body),p=g(h.legs),E=g(h.arms),S=[_,m,p,E],y=new Dn;y.name=`mob:${f}`,y.scale.setScalar(.9);const C=new je(e,_);C.name="head",C.position.y=1.75,y.add(C);const R=new je(t,m);R.name="body",R.position.y=1.125,y.add(R);const A=c(i,p,.125,.75,"legL"),P=c(i,p,-.125,.75,"legR"),x=c(i,E,.375,1.5,"armL"),v=c(i,E,-.375,1.5,"armR");return y.add(A,P,x,v),y.traverse(w=>{w instanceof je&&(w.castShadow=!0)}),{kind:f,group:y,legL:A,legR:P,armL:x,armR:v,materials:S,phase:0,swing:0,flash:0}}function d(f){const h=a.get(f);if(h){n.remove(h.group);for(const g of h.materials)g.dispose();a.delete(f)}}return{syncMobs(f,h){const g=Number.isFinite(h)&&h>0?h:0,_=new Set;for(const m of f){_.add(m.id);let p=a.get(m.id);p&&p.kind!==m.kind&&(d(m.id),p=void 0),p||(p=u(m.kind),a.set(m.id,p),n.add(p.group)),p.group.position.set(m.pos.x,m.pos.y,m.pos.z);const E=Math.hypot(m.vel.x,m.vel.z);E>.01&&(p.group.rotation.y=Math.atan2(m.vel.x,m.vel.z)),E>.01&&g>0?(p.phase+=E*g*Zy,p.swing=Math.sin(p.phase)*Ky):g>0&&(p.swing*=Math.pow(.01,g),Math.abs(p.swing)<1e-4&&(p.swing=0,p.phase=0)),p.legL.rotation.x=p.swing,p.legR.rotation.x=-p.swing,p.armL.rotation.x=-p.swing,p.armR.rotation.x=p.swing,p.flash=Math.max(0,p.flash-g);const S=p.flash>0?16777215:0;for(const y of p.materials)y.emissive.setHex(S)}for(const m of[...a.keys()])_.has(m)||d(m)},syncArrows(f){const h=new Set;for(const g of f){h.add(g.id);let _=l.get(g.id);_||(_=new je(r,s),l.set(g.id,_),n.add(_)),_.position.set(g.pos.x,g.pos.y,g.pos.z),Math.hypot(g.vel.x,g.vel.y,g.vel.z)>1e-6&&_.lookAt(g.pos.x+g.vel.x,g.pos.y+g.vel.y,g.pos.z+g.vel.z)}for(const[g,_]of l)h.has(g)||(n.remove(_),l.delete(g))},flashMob(f){const h=a.get(f);h&&(h.flash=Yy)},dispose(){for(const f of[...a.keys()])d(f);for(const f of l.values())n.remove(f);l.clear();for(const f of o)f.dispose();s.dispose()}}}const O={AIR:0,STONE:1,DIRT:2,GRASS:3,SAND:4,LOG:5,LEAVES:6,PLANKS:7,COBBLE:8,WATER:9,BEDROCK:10,SNOW:11,GLASS:12,COAL_ORE:13,IRON_ORE:14,CRAFTING_TABLE:15,FURNACE:16,SPRUCE_LOG:17,SPRUCE_LEAVES:18,BIRCH_LOG:19,BIRCH_LEAVES:20,DANDELION:21,POPPY:22,SHORT_GRASS:23,CACTUS:24,ICE:25,WOOL:26,GRAVEL:27,GOLD_ORE:28,DIAMOND_ORE:29,SPRUCE_PLANKS:30,BIRCH_PLANKS:31,TORCH:32},ie={GRASS_TOP:0,GRASS_SIDE:1,DIRT:2,STONE:3,SAND:4,LOG_SIDE:5,LOG_TOP:6,LEAVES:7,PLANKS:8,COBBLE:9,WATER:10,BEDROCK:11,SNOW_TOP:12,SNOW_SIDE:13,GLASS:14,COAL:15,IRON:16,CRAFTING_TOP:17,CRAFTING_SIDE:18,FURNACE_TOP:19,FURNACE_SIDE:20,SPRUCE_LOG_SIDE:21,SPRUCE_LOG_TOP:22,SPRUCE_LEAVES:23,BIRCH_LOG_SIDE:24,BIRCH_LOG_TOP:25,BIRCH_LEAVES:26,DANDELION:27,POPPY:28,SHORT_GRASS:29,CACTUS_SIDE:30,CACTUS_TOP:31,ICE:32,WOOL:33,GRAVEL:34,GOLD_ORE:35,DIAMOND_ORE:36,SPRUCE_PLANKS:37,BIRCH_PLANKS:38,TORCH:39},jy=ie.TORCH+1,Ad={0:{id:0,name:"air",hardness:0,solid:!1,transparent:!0,shape:"cube",top:0,side:0,bottom:0,requiredTool:null,fastTool:null},1:{id:1,name:"stone",hardness:1.5,solid:!0,transparent:!1,shape:"cube",top:ie.STONE,side:ie.STONE,bottom:ie.STONE,requiredTool:{kind:"pickaxe",level:0},fastTool:"pickaxe"},2:{id:2,name:"dirt",hardness:.5,solid:!0,transparent:!1,shape:"cube",top:ie.DIRT,side:ie.DIRT,bottom:ie.DIRT,requiredTool:null,fastTool:"shovel"},3:{id:3,name:"grass_block",hardness:.6,solid:!0,transparent:!1,shape:"cube",top:ie.GRASS_TOP,side:ie.GRASS_SIDE,bottom:ie.DIRT,requiredTool:null,fastTool:"shovel"},4:{id:4,name:"sand",hardness:.5,solid:!0,transparent:!1,shape:"cube",top:ie.SAND,side:ie.SAND,bottom:ie.SAND,requiredTool:null,fastTool:"shovel"},5:{id:5,name:"oak_log",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.LOG_TOP,side:ie.LOG_SIDE,bottom:ie.LOG_TOP,requiredTool:null,fastTool:"axe"},6:{id:6,name:"oak_leaves",hardness:.2,solid:!0,transparent:!0,shape:"cube",top:ie.LEAVES,side:ie.LEAVES,bottom:ie.LEAVES,requiredTool:null,fastTool:null},7:{id:7,name:"oak_planks",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.PLANKS,side:ie.PLANKS,bottom:ie.PLANKS,requiredTool:null,fastTool:"axe"},8:{id:8,name:"cobblestone",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.COBBLE,side:ie.COBBLE,bottom:ie.COBBLE,requiredTool:{kind:"pickaxe",level:0},fastTool:"pickaxe"},9:{id:9,name:"water",hardness:1/0,solid:!1,transparent:!0,shape:"cube",top:ie.WATER,side:ie.WATER,bottom:ie.WATER,requiredTool:null,fastTool:null},10:{id:10,name:"bedrock",hardness:1/0,solid:!0,transparent:!1,shape:"cube",top:ie.BEDROCK,side:ie.BEDROCK,bottom:ie.BEDROCK,requiredTool:null,fastTool:null},11:{id:11,name:"snow_block",hardness:.2,solid:!0,transparent:!1,shape:"cube",top:ie.SNOW_TOP,side:ie.SNOW_SIDE,bottom:ie.DIRT,requiredTool:null,fastTool:"shovel"},12:{id:12,name:"glass",hardness:.3,solid:!0,transparent:!0,shape:"cube",top:ie.GLASS,side:ie.GLASS,bottom:ie.GLASS,requiredTool:null,fastTool:null},13:{id:13,name:"coal_ore",hardness:3,solid:!0,transparent:!1,shape:"cube",top:ie.COAL,side:ie.COAL,bottom:ie.COAL,requiredTool:{kind:"pickaxe",level:0},fastTool:"pickaxe"},14:{id:14,name:"iron_ore",hardness:3,solid:!0,transparent:!1,shape:"cube",top:ie.IRON,side:ie.IRON,bottom:ie.IRON,requiredTool:{kind:"pickaxe",level:1},fastTool:"pickaxe"},15:{id:15,name:"crafting_table",hardness:2.5,solid:!0,transparent:!1,shape:"cube",top:ie.CRAFTING_TOP,side:ie.CRAFTING_SIDE,bottom:ie.PLANKS,requiredTool:null,fastTool:"axe"},16:{id:16,name:"furnace",hardness:3.5,solid:!0,transparent:!1,shape:"cube",top:ie.FURNACE_TOP,side:ie.FURNACE_SIDE,bottom:ie.STONE,requiredTool:{kind:"pickaxe",level:0},fastTool:"pickaxe"},17:{id:17,name:"spruce_log",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.SPRUCE_LOG_TOP,side:ie.SPRUCE_LOG_SIDE,bottom:ie.SPRUCE_LOG_TOP,requiredTool:null,fastTool:"axe"},18:{id:18,name:"spruce_leaves",hardness:.2,solid:!0,transparent:!0,shape:"cube",top:ie.SPRUCE_LEAVES,side:ie.SPRUCE_LEAVES,bottom:ie.SPRUCE_LEAVES,requiredTool:null,fastTool:null},19:{id:19,name:"birch_log",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.BIRCH_LOG_TOP,side:ie.BIRCH_LOG_SIDE,bottom:ie.BIRCH_LOG_TOP,requiredTool:null,fastTool:"axe"},20:{id:20,name:"birch_leaves",hardness:.2,solid:!0,transparent:!0,shape:"cube",top:ie.BIRCH_LEAVES,side:ie.BIRCH_LEAVES,bottom:ie.BIRCH_LEAVES,requiredTool:null,fastTool:null},21:{id:21,name:"dandelion",hardness:0,solid:!1,transparent:!0,shape:"cross",top:ie.DANDELION,side:ie.DANDELION,bottom:ie.DANDELION,requiredTool:null,fastTool:null},22:{id:22,name:"poppy",hardness:0,solid:!1,transparent:!0,shape:"cross",top:ie.POPPY,side:ie.POPPY,bottom:ie.POPPY,requiredTool:null,fastTool:null},23:{id:23,name:"short_grass",hardness:0,solid:!1,transparent:!0,shape:"cross",top:ie.SHORT_GRASS,side:ie.SHORT_GRASS,bottom:ie.SHORT_GRASS,requiredTool:null,fastTool:null},24:{id:24,name:"cactus",hardness:.4,solid:!0,transparent:!1,shape:"cube",top:ie.CACTUS_TOP,side:ie.CACTUS_SIDE,bottom:ie.CACTUS_TOP,requiredTool:null,fastTool:null},25:{id:25,name:"ice",hardness:.5,solid:!0,transparent:!0,shape:"cube",top:ie.ICE,side:ie.ICE,bottom:ie.ICE,requiredTool:null,fastTool:"pickaxe"},26:{id:26,name:"wool",hardness:.8,solid:!0,transparent:!1,shape:"cube",top:ie.WOOL,side:ie.WOOL,bottom:ie.WOOL,requiredTool:null,fastTool:null},27:{id:27,name:"gravel",hardness:.6,solid:!0,transparent:!1,shape:"cube",top:ie.GRAVEL,side:ie.GRAVEL,bottom:ie.GRAVEL,requiredTool:null,fastTool:"shovel"},28:{id:28,name:"gold_ore",hardness:3,solid:!0,transparent:!1,shape:"cube",top:ie.GOLD_ORE,side:ie.GOLD_ORE,bottom:ie.GOLD_ORE,requiredTool:{kind:"pickaxe",level:2},fastTool:"pickaxe"},29:{id:29,name:"diamond_ore",hardness:3,solid:!0,transparent:!1,shape:"cube",top:ie.DIAMOND_ORE,side:ie.DIAMOND_ORE,bottom:ie.DIAMOND_ORE,requiredTool:{kind:"pickaxe",level:2},fastTool:"pickaxe"},30:{id:30,name:"spruce_planks",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.SPRUCE_PLANKS,side:ie.SPRUCE_PLANKS,bottom:ie.SPRUCE_PLANKS,requiredTool:null,fastTool:"axe"},31:{id:31,name:"birch_planks",hardness:2,solid:!0,transparent:!1,shape:"cube",top:ie.BIRCH_PLANKS,side:ie.BIRCH_PLANKS,bottom:ie.BIRCH_PLANKS,requiredTool:null,fastTool:"axe"},32:{id:32,name:"torch",hardness:0,solid:!1,transparent:!0,shape:"torch",top:ie.TORCH,side:ie.TORCH,bottom:ie.TORCH,requiredTool:null,fastTool:null,emission:14}};function en(n){return Ad[n]??Ad[0]}const or=n=>en(n).solid,so=n=>en(n).transparent,Vp=n=>en(n).shape==="cross",Jy=n=>{const e=en(n);return e.solid||e.shape==="cross"||e.shape==="torch"},Qy=[O.GRASS,O.DIRT,O.STONE,O.COBBLE,O.PLANKS,O.LOG,O.LEAVES,O.SAND,O.GLASS],j=16,ht=256;function Rt(n,e,t){return n+t*j+e*j*j}class Wu{constructor(e,t,i){ke(this,"cx");ke(this,"cz");ke(this,"data");ke(this,"dirty",!0);ke(this,"generated",!1);ke(this,"light",null);ke(this,"lightDirty",!1);ke(this,"topY",0);this.cx=e,this.cz=t,this.data=i??new Uint8Array(j*j*ht)}ensureLight(){return this.light||(this.light=new Uint8Array(j*j*ht)),this.light}get(e,t,i){return t<0||t>=ht||e<0||e>=j||i<0||i>=j?O.AIR:this.data[Rt(e,t,i)]}set(e,t,i,r){t<0||t>=ht||e<0||e>=j||i<0||i>=j||(this.data[Rt(e,t,i)]=r,this.dirty=!0)}}const Gp=[{dir:[1,0,0],nAxis:0,uAxis:2,uFlip:!0,vAxis:1,vFlip:!1,shade:.72,tileKey:"side"},{dir:[-1,0,0],nAxis:0,uAxis:2,uFlip:!1,vAxis:1,vFlip:!1,shade:.72,tileKey:"side"},{dir:[0,1,0],nAxis:1,uAxis:0,uFlip:!1,vAxis:2,vFlip:!0,shade:1,tileKey:"top"},{dir:[0,-1,0],nAxis:1,uAxis:0,uFlip:!1,vAxis:2,vFlip:!1,shade:.5,tileKey:"bottom"},{dir:[0,0,1],nAxis:2,uAxis:0,uFlip:!1,vAxis:1,vFlip:!1,shade:.86,tileKey:"side"},{dir:[0,0,-1],nAxis:2,uAxis:0,uFlip:!0,vAxis:1,vFlip:!1,shade:.86,tileKey:"side"}],Kl=[j,ht,j],eM=[.5,.7,.85,1],tM=14,Wp=22,Xp=1<<30;function nM(n,e,t,i,r){return n|e<<8|t<<tM|i<<Wp|(r?Xp:0)}function iM(n,e){return e===O.AIR?!0:!(n===e||!so(e))}function oo(n,e,t,i){const r=e[0]+t[0],s=e[1]+t[1],o=e[2]+t[2];if(s<0||s>=ht)return O.AIR;const a=r<0?-1:r>=j?1:0,l=o<0?-1:o>=j?1:0;if(a===0&&l===0)return n[Rt(r,s,o)];let c;return a===0?c=l<0?i.zm:i.zp:l===0?c=a<0?i.xm:i.xp:a<0?c=l<0?i.xmzm:i.xmzp:c=l<0?i.xpzm:i.xpzp,c?c[Rt(r-a*j,s,o-l*j)]:O.AIR}function rM(n){const e=n.uFlip?1:-1,t=n.vFlip?1:-1,i=[e,-e,e,-e],r=[t,t,-t,-t],s=[];for(let o=0;o<4;o++){const a=[0,0,0];a[n.nAxis]=n.dir[n.nAxis],a[n.uAxis]=i[o];const l=[0,0,0];l[n.nAxis]=n.dir[n.nAxis],l[n.vAxis]=r[o];const c=[0,0,0];c[n.nAxis]=n.dir[n.nAxis],c[n.uAxis]=i[o],c[n.vAxis]=r[o],s.push([a,l,c])}return s}function sM(n,e,t,i){const r=!so(oo(n,e,t[0],i)),s=!so(oo(n,e,t[1],i)),o=!so(oo(n,e,t[2],i));return r&&s?0:3-(r?1:0)-(s?1:0)-(o?1:0)}function oM(n,e,t,i){let r=0;for(let s=0;s<4;s++)r|=sM(n,e,t[s],i)<<2*s;return r}function aM(n,e,t){var r;const i=new Array(9).fill(void 0);for(let s=-1;s<=1;s++)for(let o=-1;o<=1;o++)i[(s+1)*3+(o+1)]=((r=n.getChunk(e+s,t+o))==null?void 0:r.light)??void 0;return i}function qp(n,e,t){const i=e[0]+t[0],r=e[1]+t[1],s=e[2]+t[2];if(r<0||r>=ht)return 0;const o=i<0?-1:i>=j?1:0,a=s<0?-1:s>=j?1:0,l=n[(o+1)*3+(a+1)];return l?l[Rt(i-o*j,r,s-a*j)]:0}function lM(n,e,t,i,r){const s=[i[0][0]+i[1][0]-i[2][0],i[0][1]+i[1][1]-i[2][1],i[0][2]+i[1][2]-i[2][2]];let o=0,a=0,l=0;for(let c=0;c<4;c++){const u=c===0?s:i[c-1];if(!so(oo(e,t,u,r)))continue;const d=qp(n,t,u);o+=d>>4,a+=d&15,l++}return l===0?{sky:0,block:0}:{sky:o/l,block:a/l}}function Ti(){return{positions:[],normals:[],uvs:[],texIndex:[],shades:[],lightSky:[],lightBlock:[],indices:[],quadCount:0}}function wi(n){return{positions:new Float32Array(n.positions),normals:new Float32Array(n.normals),uvs:new Float32Array(n.uvs),texIndex:new Float32Array(n.texIndex),shades:new Float32Array(n.shades),lightSky:new Float32Array(n.lightSky),lightBlock:new Float32Array(n.lightBlock),indices:new Uint32Array(n.indices),quadCount:n.quadCount}}function cM(n,e,t,i,r,s,o,a,l,c,u,d,f){const h=Math.abs(r-i),g=Math.abs(o-s),_=[[i,s],[r,s],[i,o],[r,o]],m=[[0,0],[h,0],[0,g],[h,g]],p=n.positions.length/3;for(let E=0;E<4;E++){const S=[0,0,0];S[e.nAxis]=t,S[e.uAxis]=_[E][0],S[e.vAxis]=_[E][1],n.positions.push(d+S[0],S[1],f+S[2]),n.normals.push(e.dir[0],e.dir[1],e.dir[2]),n.uvs.push(m[E][0],m[E][1]),n.texIndex.push(a),n.shades.push(e.shade*eM[l>>2*E&3]),n.lightSky.push(c[E]),n.lightBlock.push(u[E])}n.indices.push(p,p+1,p+2,p+2,p+1,p+3),n.quadCount++}const ea=Math.SQRT1_2;function uM(n,e,t,i,r,s,o,a,l){const c=e+i,u=r,d=t+s,f=[{corners:[[c,u,d],[c+1,u,d+1],[c,u+1,d],[c+1,u+1,d+1]],normal:[-ea,0,ea]},{corners:[[c,u,d+1],[c+1,u,d],[c,u+1,d+1],[c+1,u+1,d]],normal:[ea,0,ea]}],h=[[0,0],[1,0],[0,1],[1,1]];for(const g of f){const _=n.positions.length/3;for(let m=0;m<4;m++){const p=g.corners[m];n.positions.push(p[0],p[1],p[2]),n.normals.push(g.normal[0],g.normal[1],g.normal[2]),n.uvs.push(h[m][0],h[m][1]),n.texIndex.push(o),n.shades.push(1),n.lightSky.push(a),n.lightBlock.push(l)}n.indices.push(_,_+1,_+2,_+2,_+1,_+3),n.quadCount++}}function Yp(n,e,t,i){return or(n.getBlock(e,t-1,i))?"floor":or(n.getBlock(e+1,t,i))?"wall+x":or(n.getBlock(e-1,t,i))?"wall-x":or(n.getBlock(e,t,i+1))?"wall+z":or(n.getBlock(e,t,i-1))?"wall-z":"free"}const Ri=2/16,fM=10/16;function dM(n,e,t,i,r,s,o,a,l,c){const u=e+i,d=r,f=t+s;let h=u+.5-Ri/2,g=u+.5+Ri/2,_=f+.5-Ri/2,m=f+.5+Ri/2;a==="wall+x"?(h=u+1-Ri,g=u+1):a==="wall-x"?(h=u,g=u+Ri):a==="wall+z"?(_=f+1-Ri,m=f+1):a==="wall-z"&&(_=f,m=f+Ri);const p=[[h,g],[d,d+fM],[_,m]],E=[[0,0],[1,0],[0,1],[1,1]];for(const S of Gp){const y=S.dir[S.nAxis]>0?p[S.nAxis][1]:p[S.nAxis][0],C=S.uFlip?p[S.uAxis][1]:p[S.uAxis][0],R=S.uFlip?p[S.uAxis][0]:p[S.uAxis][1],A=S.vFlip?p[S.vAxis][1]:p[S.vAxis][0],P=S.vFlip?p[S.vAxis][0]:p[S.vAxis][1],x=[[C,A],[R,A],[C,P],[R,P]],v=n.positions.length/3;for(let w=0;w<4;w++){const k=[0,0,0];k[S.nAxis]=y,k[S.uAxis]=x[w][0],k[S.vAxis]=x[w][1],n.positions.push(e+k[0],k[1],t+k[2]),n.normals.push(S.dir[0],S.dir[1],S.dir[2]),n.uvs.push(E[w][0],E[w][1]),n.texIndex.push(o[S.tileKey]),n.shades.push(S.shade),n.lightSky.push(l),n.lightBlock.push(c)}n.indices.push(v,v+1,v+2,v+2,v+1,v+3),n.quadCount++}}function hM(n,e,t,i,r){for(let s=0;s<t;s++)for(let o=0;o<e;o++){const a=n[o+s*e];if(!i(a))continue;let l=1;for(;o+l<e&&n[o+l+s*e]===a;)l++;let c=1,u=!0;for(;u&&s+c<t;){for(let d=0;d<l;d++)if(n[o+d+(s+c)*e]!==a){u=!1;break}u&&c++}for(let d=0;d<c;d++)for(let f=0;f<l;f++)n[o+f+(s+d)*e]=0;r(o,s,l,c,a)}}function pM(n,e,t){var h,g,_,m,p,E,S,y;const i=n.getChunk(e,t);if(!i)return{opaque:wi(Ti()),water:wi(Ti()),foliage:wi(Ti()),torches:wi(Ti())};const r=i.data,s={xp:(h=n.getChunk(e+1,t))==null?void 0:h.data,xm:(g=n.getChunk(e-1,t))==null?void 0:g.data,zp:(_=n.getChunk(e,t+1))==null?void 0:_.data,zm:(m=n.getChunk(e,t-1))==null?void 0:m.data,xpzp:(p=n.getChunk(e+1,t+1))==null?void 0:p.data,xpzm:(E=n.getChunk(e+1,t-1))==null?void 0:E.data,xmzp:(S=n.getChunk(e-1,t+1))==null?void 0:S.data,xmzm:(y=n.getChunk(e-1,t-1))==null?void 0:y.data},o=aM(n,e,t),a=e*j,l=t*j,c=Ti(),u=Ti(),d=Ti(),f=Ti();for(const C of Gp){const R=Kl[C.nAxis],A=Kl[C.uAxis],P=Kl[C.vAxis],x=rM(C),v=new Int32Array(A*P),w=[0,0,0];for(let k=0;k<R;k++){v.fill(0);let B=!1;for(let H=0;H<P;H++)for(let te=0;te<A;te++){w[C.nAxis]=k,w[C.uAxis]=te,w[C.vAxis]=H;const I=r[Rt(w[0],w[1],w[2])];if(I===O.AIR||Vp(I)||en(I).shape==="torch"||!iM(I,oo(r,w,C.dir,s)))continue;const Z=en(I)[C.tileKey],Q=oM(r,w,x,s),se=qp(o,w,C.dir);v[te+H*A]=nM(I,Z,se,Q,I===O.WATER),B=!0}if(!B)continue;const X=k+(C.dir[C.nAxis]>0?1:0),J=(H,te)=>{hM(v,A,P,I=>I!==0&&(I&Xp)!==0===te,(I,Z,Q,se,Me)=>{const Je=Me>>8&63,K=Me>>Wp&255,re=C.uFlip?I+Q:I,ne=C.uFlip?I:I+Q,ce=C.vFlip?Z+se:Z,Re=C.vFlip?Z:Z+se,De=C.uFlip?I+Q-1:I,ye=C.uFlip?I:I+Q-1,xt=C.vFlip?Z+se-1:Z,Ke=C.vFlip?Z:Z+se-1,yt=[De,ye,De,ye],D=[xt,xt,Ke,Ke],Ot=[],Ze=[];for(let ze=0;ze<4;ze++){const Te=[0,0,0];Te[C.nAxis]=k,Te[C.uAxis]=yt[ze],Te[C.vAxis]=D[ze];const ct=lM(o,r,Te,x[ze],s);Ot.push(ct.sky),Ze.push(ct.block)}cM(H,C,X,re,ne,ce,Re,Je,K,Ot,Ze,a,l)})};J(c,!1),J(u,!0)}}for(let C=0;C<ht;C++)for(let R=0;R<j;R++)for(let A=0;A<j;A++){const P=r[Rt(A,C,R)];if(P===O.AIR)continue;const x=en(P);if(x.shape==="cross"){const v=i.light?i.light[Rt(A,C,R)]:0;uM(d,a,l,A,C,R,x.top,v>>4,v&15)}else if(x.shape==="torch"){const v=i.light?i.light[Rt(A,C,R)]:0;dM(f,a,l,A,C,R,x,Yp(n,a+A,C,l+R),v>>4,v&15)}}return{opaque:wi(c),water:wi(u),foliage:wi(d),torches:wi(f)}}const La=600,Kp=60,Zp=3600,mM=8900331,gM=658970,_M=4026313,vM=329487,xM=16751196,Td=.06,SM=.85,yM=.75,MM=.25,EM=.9,bM=.12,$p=n=>n<0?0:n>1?1:n,ao=(n,e,t)=>n+(e-n)*t;function Aa(n,e,t){const i=Number.isFinite(t)?$p(t):0,r=Math.round(ao(n>>>16&255,e>>>16&255,i)),s=Math.round(ao(n>>>8&255,e>>>8&255,i)),o=Math.round(ao(n&255,e&255,i));return r<<16|s<<8|o}function Xu(n=La){return{t:.25,dayLengthSec:Number.isFinite(n)&&n>0?Math.min(Zp,Math.max(Kp,n)):La}}function AM(n,e){if(!Number.isFinite(e)||e<=0)return{...n};const t=n.t+e/n.dayLengthSec;return{...n,t:t-Math.floor(t)}}function hr(n){return n<.5?"day":"night"}function TM(n){const e=(n-.25)*Math.PI*2;return{x:0,y:Math.cos(e),z:Math.sin(e)}}function wd(n,e){const t=Math.abs(n-e),i=Math.min(t,1-t);return i>=Td?0:1-i/Td}function qu(n){const e=Math.cos((n-.25)*Math.PI*2);return $p((e+.2)/.4)}function wM(n){const e=qu(n),t=Aa(gM,mM,e),i=Math.max(wd(n,0),wd(n,.5)),r=Aa(t,xM,i*SM),s=Aa(vM,_M,e);return{sky:r,zenith:s,fog:r,ambient:ao(MM,yM,e),sunIntensity:ao(bM,EM,e)}}const gs=15,In=new Uint8Array(256);for(let n=0;n<In.length;n++)In[n]=en(n).transparent?1:0;const ns=new Int8Array([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1]);function jp(n,e,t,i){const r=Math.floor(e),s=Math.floor(t),o=Math.floor(i);if(s<0||s>=ht)return null;const a=Math.floor(r/j),l=Math.floor(o/j),c=n.getChunk(a,l);return c?{chunk:c,lx:r-a*j,ly:s,lz:o-l*j,cx:a,cz:l}:null}function RM(n,e,t,i){const r=jp(n,e,t,i);return!r||!r.chunk.light?0:r.chunk.light[Rt(r.lx,r.ly,r.lz)]&15}function CM(n,e,t,i){const r=jp(n,e,t,i);return!r||!r.chunk.light?0:r.chunk.light[Rt(r.lx,r.ly,r.lz)]>>4}let $t=new Int32Array(4096*4),mn=0,is=0;function Eo(n,e,t,i){if((is+1)*4>$t.length){const s=new Int32Array($t.length*2);s.set($t),$t=s}const r=is*4;$t[r]=n,$t[r+1]=e,$t[r+2]=t,$t[r+3]=i,is+=1}function Zl(){mn=0,is=0}const Qa=4,hu=new Array(Qa).fill(null),Rd=new Int32Array(Qa),Cd=new Int32Array(Qa),Pd=new Array(Qa).fill(void 0);function PM(){hu.fill(null)}function Jp(n,e,t){const i=e&1|(t&1)<<1;if(hu[i]===n&&Rd[i]===e&&Cd[i]===t)return Pd[i];const r=n.getChunk(e,t);return hu[i]=n,Rd[i]=e,Cd[i]=t,Pd[i]=r,r}const go=Math.round(Math.log2(j)),Da=j-1;if(1<<go!==j)throw new Error(`lighting.ts: CHUNK_SIZE must be a power of two, got ${j}`);function IM(n){for(;mn<is;){const e=$t[mn*4],t=$t[mn*4+1],i=$t[mn*4+2],r=$t[mn*4+3];if(mn+=1,!(r<=1))for(let s=0;s<6;s++){const o=e+ns[s*3],a=t+ns[s*3+1],l=i+ns[s*3+2];if(a<0||a>=ht)continue;const c=o>>go,u=l>>go,d=Jp(n,c,u);if(!d)continue;const f=Rt(o&Da,a,l&Da);if(In[d.data[f]]===0)continue;const h=d.light?d.light[f]:0,g=r-1;(h&15)>=g||(d.ensureLight()[f]=h&240|g,d.dirty=!0,Eo(o,a,l,g))}}}function LM(n,e,t){const i=[];for(let r=-1;r<=1;r++)for(let s=-1;s<=1;s++){const o=n.getChunk(e+r,t+s);o&&i.push(o)}return i}function Id(n,e,t){const i=new Set;for(const r of e)i.add(`${r.cx},${r.cz}`);for(const r of e)for(let s=0;s<4;s++){const o=s===0?1:s===1?-1:0,a=s===2?1:s===3?-1:0,l=r.cx+o,c=r.cz+a;if(i.has(`${l},${c}`))continue;const u=n.getChunk(l,c);if(!(!u||u.lightDirty||!u.light))for(let d=0;d<ht;d++)for(let f=0;f<j;f++){const h=o===1?j-1:o===-1?0:f,g=a===1?j-1:a===-1?0:f,_=Rt(h,d,g);if(In[r.data[_]]===0)continue;const m=o===1?0:o===-1?j-1:f,p=a===1?0:a===-1?j-1:f,E=Rt(m,d,p);if(In[u.data[E]]===0)continue;const S=u.light[E],y=t==="sky"?S>>4:S&15;if(y<=1)continue;const C=y-1,R=r.ensureLight(),A=R[_];(t==="sky"?A>>4:A&15)>=C||(R[_]=t==="sky"?C<<4|A&15:A&240|C,r.dirty=!0,Eo(r.cx*j+h,d,r.cz*j+g,C))}}}function Qp(n,e,t){if(!n.getChunk(e,t))return;PM();const r=LM(n,e,t);for(const o of r)o.ensureLight().fill(0);const s=j*j*ht;Zl();for(const o of r){const a=o.ensureLight();for(let l=0;l<s;l++){const c=en(o.data[l]).emission??0;if(c<=0)continue;const u=Math.floor(l/(j*j)),d=l-u*j*j,f=Math.floor(d/j),h=d-f*j,g=a[l];c<=(g&15)||(a[l]=g&240|c,o.dirty=!0,Eo(o.cx*j+h,u,o.cz*j+f,c))}}Id(n,r,"block"),IM(n),Zl();for(const o of r)BM(o);Id(n,r,"sky"),kM(n),Zl();for(const o of r)o.lightDirty=!1}function Yu(n,e,t){for(let i=-1;i<=1;i++)for(let r=-1;r<=1;r++){const s=n.getChunk(e+i,t+r);s&&(s.lightDirty=!0)}}function em(n){for(let e=ht-1;e>=0;e--){const t=e*j*j;for(let i=t;i<t+j*j;i++)if(n.data[i]!==O.AIR)return e+1}return 0}function DM(n,e){return n.slice(0,Math.max(0,e))}function NM(n,e,t){return[...n].sort((i,r)=>(i[0]-e)**2+(i[1]-t)**2-((r[0]-e)**2+(r[1]-t)**2))}const Ld=.85,UM=.05;function OM(n){return Ld+(1-Ld)*qu(n)}function FM(n,e){const t=4+(gs-4)*qu(e);return Math.max(0,Math.round(t-(gs-n)))}function tm(n,e,t,i,r){const s=CM(n,e,t,i),o=RM(n,e,t,i);return{sky:s,internalSky:FM(s,r),block:o}}function kM(n){for(;mn<is;){const e=$t[mn*4],t=$t[mn*4+1],i=$t[mn*4+2],r=$t[mn*4+3];if(mn+=1,!(r<=1))for(let s=0;s<6;s++){const o=ns[s*3],a=ns[s*3+1],l=e+o,c=t+a,u=i+ns[s*3+2];if(c<0||c>=ht)continue;const d=l>>go,f=u>>go,h=Jp(n,d,f);if(!h)continue;const g=Rt(l&Da,c,u&Da);if(In[h.data[g]]===0)continue;const _=h.light?h.light[g]:0,m=a===-1&&r===gs?gs:r-1;_>>4>=m||(h.ensureLight()[g]=m<<4|_&15,h.dirty=!0,Eo(l,c,u,m))}}}const Wr=new Int16Array(j*j);function BM(n){const e=n.cx*j,t=n.cz*j,i=n.data;let r=n.light,s=!1;for(let o=0;o<j;o++)for(let a=0;a<j;a++){let l=ht-1;for(;l>=0;l--){const c=Rt(o,l,a);if(In[i[c]]===0)break;r||(r=n.ensureLight()),r[c]=gs<<4|r[c]&15,s=!0}Wr[o*j+a]=l}s&&(n.dirty=!0);for(let o=0;o<j;o++)for(let a=0;a<j;a++){const l=Wr[o*j+a],c=o>0,u=o<j-1,d=a>0,f=a<j-1;for(let h=l+1;h<ht;h++){let g=!(c&&u&&d&&f);g||(g=Wr[(o-1)*j+a]>h&&In[i[Rt(o-1,h,a)]]===1||Wr[(o+1)*j+a]>h&&In[i[Rt(o+1,h,a)]]===1||Wr[o*j+(a-1)]>h&&In[i[Rt(o,h,a-1)]]===1||Wr[o*j+(a+1)]>h&&In[i[Rt(o,h,a+1)]]===1),g&&Eo(e+o,h,t+a,gs)}}return s}function Gs(n,e,t,i){return or(n.getBlock(e,t,i))}function zM(n,e,t,i){const r=[],s=[[e,t+1,i],[e+1,t,i],[e-1,t,i],[e,t,i+1],[e,t,i-1]];for(const[o,a,l]of s)n.getBlock(o,a,l)===O.TORCH&&Yp(n,o,a,l)==="free"&&(n.setBlock(o,a,l,O.AIR),r.push({x:o,y:a,z:l}));return r}function Vn(n,e){return`${n},${e}`}class HM{constructor(){ke(this,"chunks",new Map);ke(this,"modified",new Map)}hasChunk(e,t){return this.chunks.has(Vn(e,t))}getChunk(e,t){return this.chunks.get(Vn(e,t))}addChunk(e){this.chunks.set(Vn(e.cx,e.cz),e)}removeChunk(e,t){this.chunks.delete(Vn(e,t))}getBlock(e,t,i){if(e=Math.floor(e),t=Math.floor(t),i=Math.floor(i),t<0||t>=ht)return O.AIR;const r=Math.floor(e/j),s=Math.floor(i/j),o=this.getChunk(r,s);return o?o.get(e-r*j,t,i-s*j):O.AIR}setBlock(e,t,i,r){if(e=Math.floor(e),t=Math.floor(t),i=Math.floor(i),t<0||t>=ht)return!1;const s=Math.floor(e/j),o=Math.floor(i/j);let a=this.getChunk(s,o);a||(a=new Wu(s,o),this.addChunk(a));const l=e-s*j,c=i-o*j;return a.set(l,t,c,r),l===0&&this.markDirty(s-1,o),l===j-1&&this.markDirty(s+1,o),c===0&&this.markDirty(s,o-1),c===j-1&&this.markDirty(s,o+1),this.modified.set(`${e},${t},${i}`,r),a.topY=Math.max(a.topY,t+1),Yu(this,s,o),!0}markDirty(e,t){const i=this.getChunk(e,t);i&&(i.dirty=!0)}serializeModified(){return[...this.modified.entries()]}applyModified(e){for(const t of e){if(!Array.isArray(t)||t.length!==2)continue;const[i,r]=t;if(typeof i!="string"||!Number.isInteger(r)||!/^-?\d+,-?\d+,-?\d+$/.test(i))continue;const[s,o,a]=i.split(",").map(Number);o<0||o>=ht||this.setBlock(s,o,a,r)}}reapplyModifiedInChunk(e,t){const i=e*j,r=t*j;for(const[s,o]of[...this.modified]){const a=s.split(",");if(a.length!==3)continue;const l=Number(a[0]),c=Number(a[1]),u=Number(a[2]);c<0||c>=ht||l<i||l>=i+j||u<r||u>=r+j||this.setBlock(l,c,u,o)}}clear(){this.chunks.clear(),this.modified.clear()}isSolid(e,t,i){return or(this.getBlock(e,t,i))}isTargetable(e,t,i){return Jy(this.getBlock(e,t,i))}}const Ui=512,tt=16,_s=Ui/tt,Dd=64;function Ku(n){let e=n>>>0;return()=>{e=e+1831565813>>>0;let t=e;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}}const ge=n=>Math.max(0,Math.min(255,Math.round(n))),He=(n,e,t)=>{const i=(e()-.5)*t;return[ge(n[0]+i),ge(n[1]+i),ge(n[2]+i),n[3]]};function VM(n,e,t){const i=e%_s,r=Math.floor(e/_s),s=Ku(e*7919+17);for(let o=0;o<tt;o++)for(let a=0;a<tt;a++){const[l,c,u,d]=t(a,o,s),f=((r*tt+o)*Ui+i*tt+a)*4;n[f]=l,n[f+1]=c,n[f+2]=u,n[f+3]=d}}let ta=null;const GM=(()=>{const n=Ku(269263),e=[];for(;e.length<20;){const t=Math.floor(n()*tt),i=Math.floor(n()*tt);e.some(r=>r.x===t&&r.y===i)||e.push({x:t,y:i,d:e.length%2===0?-36:34})}return e})(),WM=[[3,2],[9,3],[13,6],[4,10],[8,12],[12,13]],Nd=(n,e)=>WM.some(([t,i])=>{const r=n-t,s=e-i;return r*r+s*s<=2});function Zu(){if(ta)return ta;const n=new Uint8ClampedArray(Ui*Ui*4),e=(t,i)=>VM(n,t,i);return e(0,(t,i,r)=>He([106,170,64,255],r,26)),e(1,(t,i,r)=>i<3+(t%3===0?1:0)?He([106,170,64,255],r,26):He([134,96,67,255],r,24)),e(2,(t,i,r)=>He([134,96,67,255],r,28)),e(3,(t,i,r)=>{const s=(t*3+i*7)%5===0?-22:0,o=He([125,125,125,255],r,20);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(4,(t,i,r)=>He([219,207,163,255],r,20)),e(5,(t,i,r)=>{const s=t%4===0?-30:0,o=He([102,81,50,255],r,16);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(6,(t,i,r)=>{const s=t-7.5,o=i-7.5,a=Math.floor(Math.sqrt(s*s+o*o))%2===0?18:-10,l=He([154,126,78,255],r,14);return[ge(l[0]+a),ge(l[1]+a),ge(l[2]+a),255]}),e(7,(t,i,r)=>r()<.18?[0,0,0,0]:He([60,140,46,255],r,40)),e(8,(t,i,r)=>{const s=i%4===3||(t+Math.floor(i/4)%2*8)%16===0?-28:0,o=He([168,136,84,255],r,14);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(9,(t,i,r)=>He([110,110,110,255],r,45)),e(10,(t,i,r)=>{const s=Math.sin(t*.8+i*.5)*14,o=He([52,96,200,200],r,10);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),200]}),e(11,(t,i,r)=>He([70,70,70,255],r,55)),e(12,(t,i,r)=>He([242,246,248,255],r,12)),e(13,(t,i,r)=>i<4?He([242,246,248,255],r,12):He([134,96,67,255],r,24)),e(14,(t,i)=>t===0||i===0||t===15||i===15?[220,240,250,220]:t===i||t+i===15?[230,245,255,60]:[200,230,245,0]),e(15,(t,i,r)=>{const s=He([125,125,125,255],r,20);return(t%8<3&&i%8<3||t%8>5&&i%8>5)&&r()>.3?He([30,30,30,255],r,18):s}),e(16,(t,i,r)=>{const s=He([125,125,125,255],r,20);return(t%8<3&&i%8<3||t%8>5&&i%8>5)&&r()>.3?He([216,175,147,255],r,20):s}),e(17,(t,i,r)=>{const s=t===7||t===8||i===7||i===8?-40:0,o=i%4===3?-14:0,a=He([168,136,84,255],r,14);return[ge(a[0]+o+s),ge(a[1]+o+s),ge(a[2]+o+s),255]}),e(18,(t,i,r)=>{const s=i>=2&&i<=5?-30:0,o=t>=3&&t<=5&&i>=9&&i<=11||t===11&&i>=8&&i<=12?-45:0,a=i%4===3?-14:0,l=He([168,136,84,255],r,14),c=s+o+a;return[ge(l[0]+c),ge(l[1]+c),ge(l[2]+c),255]}),e(19,(t,i,r)=>{if(t>=4&&t<=11&&i>=4&&i<=11)return He([22,22,22,255],r,12);const o=(t*3+i*7)%5===0?-22:0,a=He([125,125,125,255],r,20);return[ge(a[0]+o),ge(a[1]+o),ge(a[2]+o),255]}),e(20,(t,i,r)=>{const s=t>=5&&t<=10&&i>=6&&i<=13;if(t>=6&&t<=9&&i>=8&&i<=12)return He([235,120,25,255],r,30);if(s)return He([25,25,25,255],r,12);const a=(t*3+i*7)%5===0?-22:0,l=He([125,125,125,255],r,20);return[ge(l[0]+a),ge(l[1]+a),ge(l[2]+a),255]}),e(21,(t,i,r)=>{const s=t%4===0?-26:0,o=He([64,48,32,255],r,14);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(22,(t,i,r)=>{const s=t-7.5,o=i-7.5,a=Math.floor(Math.sqrt(s*s+o*o))%2===0?16:-12,l=He([78,58,38,255],r,12);return[ge(l[0]+a),ge(l[1]+a),ge(l[2]+a),255]}),e(23,(t,i,r)=>r()<.18?[0,0,0,0]:He([46,96,40,255],r,34)),e(24,(t,i,r)=>{const s=i%5,o=(s===2||s===3)&&(t+i%3*5)%7<4?-150:0,a=He([216,214,206,255],r,10);return[ge(a[0]+o),ge(a[1]+o),ge(a[2]+o),255]}),e(25,(t,i,r)=>{const s=t-7.5,o=i-7.5,a=Math.floor(Math.sqrt(s*s+o*o))%2===0?14:-10,l=He([214,206,182,255],r,10);return[ge(l[0]+a),ge(l[1]+a),ge(l[2]+a),255]}),e(26,(t,i,r)=>r()<.18?[0,0,0,0]:He([126,168,84,255],r,34)),e(27,(t,i)=>t>=7&&t<=8&&i>=8?[86,140,60,255]:t>=6&&t<=9&&i>=4&&i<=6||t>=7&&t<=8&&i>=2&&i<=7?[230,200,60,255]:[0,0,0,0]),e(28,(t,i)=>t>=7&&t<=8&&i>=8?[86,140,60,255]:t>=6&&t<=9&&i>=4&&i<=6||t>=7&&t<=8&&i>=2&&i<=7?[200,60,50,255]:[0,0,0,0]),e(29,(t,i)=>t===3&&i>=7||t===6&&i>=11||t===7&&i>=4&&i<=10||t===10&&i>=9?[92,150,62,255]:[0,0,0,0]),e(30,(t,i,r)=>{if((t===3||t===7||t===11)&&i%5===2)return[198,216,158,255];const s=t===0||t===15?-28:0,o=He([74,130,66,255],r,18);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(31,(t,i,r)=>{const s=t-7.5,o=i-7.5,a=Math.sqrt(s*s+o*o),l=a<3?26:a<6?8:-20,c=He([74,130,66,255],r,16);return[ge(c[0]+l),ge(c[1]+l),ge(c[2]+l),255]}),e(32,(t,i)=>t===i*7%13||(t+i)%11===0?[240,248,255,220]:[168,205,235,190]),e(33,(t,i,r)=>He([233,236,236,255],r,18)),e(34,(t,i,r)=>{const s=He([136,130,122,255],r,16),o=GM.find(a=>a.x===t&&a.y===i);return o?[ge(s[0]+o.d),ge(s[1]+o.d),ge(s[2]+o.d),255]:s}),e(35,(t,i,r)=>{if(Nd(t,i))return He([240,200,60,255],r,20);const s=(t*3+i*7)%5===0?-22:0,o=He([125,125,125,255],r,20);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(36,(t,i,r)=>{if(Nd(t,i))return He([120,220,225,255],r,20);const s=(t*3+i*7)%5===0?-22:0,o=He([125,125,125,255],r,20);return[ge(o[0]+s),ge(o[1]+s),ge(o[2]+s),255]}),e(37,(t,i,r)=>{const s=t%4===3?-26:0,o=(i+Math.floor(t/4)%2*4)%8===0?-12:0,a=He([92,64,38,255],r,14),l=s+o;return[ge(a[0]+l),ge(a[1]+l),ge(a[2]+l),255]}),e(38,(t,i,r)=>{const s=t%4===3?26:0,o=(i+Math.floor(t/4)%2*4)%8===0?12:0,a=He([196,180,140,255],r,14),l=s+o;return[ge(a[0]+l),ge(a[1]+l),ge(a[2]+l),255]}),e(ie.TORCH,(t,i)=>{if(t>=6&&t<=9&&i>=4){const o=t===6||t===9?-24:0;return[ge(110+o),ge(84+o),ge(50+o),255]}return t>=6&&t<=9&&i>=1&&i<=3?(t===7||t===8)&&i===2?[255,230,120,255]:[240,150,40,255]:[0,0,0,0]}),ta={width:Ui,height:Ui,data:n},ta}function XM(n=Zu()){const e=tt*tt*4,t=new Uint8Array(Dd*e);for(let r=0;r<t.length;r+=4)t[r]=255,t[r+1]=0,t[r+2]=255,t[r+3]=255;for(let r=0;r<jy;r++){const s=r%_s,o=Math.floor(r/_s),a=r*e;for(let l=0;l<tt;l++){const c=o*tt+(tt-1-l);for(let u=0;u<tt;u++){const d=(c*Ui+s*tt+u)*4,f=a+(l*tt+u)*4;t[f]=n.data[d],t[f+1]=n.data[d+1],t[f+2]=n.data[d+2],t[f+3]=n.data[d+3]}}}const i=new ku(t,tt,tt,Dd);return i.minFilter=zt,i.magFilter=zt,i.generateMipmaps=!1,i.wrapS=ho,i.wrapT=ho,i.flipY=!1,i.colorSpace=jt,i.needsUpdate=!0,i}let $l=null;function $u(){return $l||($l=XM(Zu())),$l}const qM=120,YM=96,KM=8,ZM=.2,$M=.4,jM=60;let jl=null;function JM(){if(jl)return jl;const n=Ku(1715004),e=new Set,t=[],i=(f,h)=>h*tt+f,r=(f,h)=>f>=0&&f<tt&&h>=0&&h<tt&&!e.has(i(f,h)),s=(f,h)=>{e.add(i(f,h)),t.push(i(f,h))};function o(f,h,g,_,m,p){for(let E=0;E<m&&t.length<YM;E++){if(n()<ZM||!r(f+g,h+_)){const S=[_,-g],y=[-_,g],C=[-g,-_],A=(n()<.5?[S,y,C]:[y,S,C]).find(([P,x])=>r(f+P,h+x));if(!A)return;g=A[0],_=A[1]}if(s(f+g,h+_),f+=g,h+=_,p>0&&n()<$M){const S=n()<.5?[_,-g]:[-_,g];r(f+S[0],h+S[1])&&(s(f+S[0],h+S[1]),o(f+S[0],h+S[1],S[0],S[1],3+Math.floor(n()*4),p-1))}}}const a=tt/2,l=tt/2;s(a,l);const c=[[1,0],[-1,0],[0,1],[0,-1]],[u,d]=c[Math.floor(n()*c.length)];return s(a+u,l+d),o(a+u,l+d,u,d,jM,2),jl=t,t}function QM(n){const e=Number.isFinite(n)?Math.max(0,Math.min(9,Math.floor(n))):0,t=JM(),i=Math.min(KM,t.length),r=i+Math.round((t.length-i)*e/9),s=new Uint8ClampedArray(tt*tt*4);for(let o=0;o<r;o++){const a=t[o]*4;s[a]=0,s[a+1]=0,s[a+2]=0,s[a+3]=qM}return s}function ju(n,e){n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
attribute float texIndex;
varying vec2 vTileUv;
varying float vTexIndex;`).replace("#include <begin_vertex>",`#include <begin_vertex>
vTileUv = uv;
vTexIndex = texIndex;`),n.fragmentShader=n.fragmentShader.replace("#include <common>",`#include <common>
uniform sampler2DArray mapArray;
varying vec2 vTileUv;
varying float vTexIndex;`).replace("#include <map_fragment>",`vec4 sampledDiffuseColor = texture( mapArray, vec3( vTileUv, vTexIndex ) );
	diffuseColor *= sampledDiffuseColor;`),n.uniforms.mapArray={value:e}}function na(n,e,t){ju(n,e),n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
attribute float lightSky;
attribute float lightBlock;
varying float vLightSky;
varying float vLightBlock;`).replace("#include <begin_vertex>",`#include <begin_vertex>
vLightSky = lightSky;
vLightBlock = lightBlock;`),n.fragmentShader=n.fragmentShader.replace("#include <common>",`#include <common>
uniform float uSkyScale;
uniform float uMinLight;
varying float vLightSky;
varying float vLightBlock;`).replace("diffuseColor *= sampledDiffuseColor;",["diffuseColor *= sampledDiffuseColor;","	float lf = max(vLightSky * (1.0/15.0) * uSkyScale, vLightBlock * (1.0/15.0));","	lf = max(lf, uMinLight);","	diffuseColor.rgb *= lf;"].join(`
`)),n.uniforms.uSkyScale=t.uSkyScale,n.uniforms.uMinLight=t.uMinLight}function eE(){return{transparent:!0,opacity:.62,depthWrite:!1,side:gn}}const tE=3e3;function nE(n){const e=new Float32Array(n.length*3);for(let t=0;t<n.length;t++)e[t*3]=n[t],e[t*3+1]=n[t],e[t*3+2]=n[t];return e}function ia(n){if(n.quadCount===0)return null;const e=new Jt;return e.setAttribute("position",new bt(n.positions,3)),e.setAttribute("normal",new bt(n.normals,3)),e.setAttribute("uv",new bt(n.uvs,2)),e.setAttribute("texIndex",new bt(n.texIndex,1)),e.setAttribute("color",new bt(nE(n.shades),3)),e.setAttribute("lightSky",new bt(n.lightSky,1)),e.setAttribute("lightBlock",new bt(n.lightBlock,1)),e.setIndex(new bt(n.indices,1)),e.computeBoundingSphere(),e}function ra(n,e){e?(n.geometry.dispose(),n.geometry=e,n.visible=!0):n.visible&&(n.geometry.dispose(),n.geometry=new Jt,n.visible=!1)}class iE{constructor(e){ke(this,"chunks",new Map);ke(this,"material");ke(this,"waterMaterial");ke(this,"foliageMaterial");ke(this,"torchMaterial");ke(this,"textureArray");ke(this,"lightUniforms",{uSkyScale:{value:1},uMinLight:{value:UM}});this.scene=e,this.textureArray=$u(),this.material=new bn({alphaTest:.1,vertexColors:!0,side:Kn,fog:!0}),this.material.onBeforeCompile=t=>{na(t,this.textureArray,this.lightUniforms)},this.waterMaterial=new bn({...eE(),alphaTest:0,vertexColors:!0,fog:!0}),this.waterMaterial.onBeforeCompile=t=>{na(t,this.textureArray,this.lightUniforms)},this.foliageMaterial=new bn({alphaTest:.1,vertexColors:!0,side:gn,fog:!0}),this.foliageMaterial.onBeforeCompile=t=>{na(t,this.textureArray,this.lightUniforms)},this.torchMaterial=new bn({alphaTest:.1,vertexColors:!0,side:Kn,fog:!0}),this.torchMaterial.onBeforeCompile=t=>{na(t,this.textureArray,this.lightUniforms)}}setSkyScale(e){this.lightUniforms.uSkyScale.value=e}rebuild(e,t,i){const r=Vn(t,i),s=pM(e,t,i),o=ia(s.opaque),a=ia(s.water),l=ia(s.foliage),c=ia(s.torches);if(!o&&!a&&!l&&!c){this.remove(t,i);return}let u=this.chunks.get(r);if(!u){u={opaque:new je(new Jt,this.material),water:new je(new Jt,this.waterMaterial),foliage:new je(new Jt,this.foliageMaterial),torches:new je(new Jt,this.torchMaterial)},u.opaque.castShadow=!0,u.opaque.receiveShadow=!0,u.water.receiveShadow=!0,u.foliage.castShadow=!1,u.foliage.receiveShadow=!0,u.torches.castShadow=!1,u.torches.receiveShadow=!0;for(const d of[u.opaque,u.water,u.foliage,u.torches])d.matrixAutoUpdate=!1,d.updateMatrix();u.water.renderOrder=tE,this.scene.add(u.opaque,u.water,u.foliage,u.torches),this.chunks.set(r,u)}ra(u.opaque,o),ra(u.water,a),ra(u.foliage,l),ra(u.torches,c)}remove(e,t){const i=Vn(e,t),r=this.chunks.get(i);r&&(this.scene.remove(r.opaque,r.water,r.foliage,r.torches),r.opaque.geometry.dispose(),r.water.geometry.dispose(),r.foliage.geometry.dispose(),r.torches.geometry.dispose(),this.chunks.delete(i))}has(e,t){return this.chunks.has(Vn(e,t))}dispose(){for(const e of this.chunks.values())this.scene.remove(e.opaque,e.water,e.foliage,e.torches),e.opaque.geometry.dispose(),e.water.geometry.dispose(),e.foliage.geometry.dispose(),e.torches.geometry.dispose();this.chunks.clear(),this.material.dispose(),this.waterMaterial.dispose(),this.foliageMaterial.dispose(),this.torchMaterial.dispose()}}function rE(n){return Number.isFinite(n)?Math.max(0,Math.min(9,Math.floor(n*10))):0}function sE(n){return n.y!==0?n.y>0?[-Math.PI/2,0,0]:[Math.PI/2,0,0]:n.x!==0?n.x>0?[0,Math.PI/2,0]:[0,-Math.PI/2,0]:n.z<0?[0,Math.PI,0]:[0,0,0]}function oE(n,e=.003){const t=.5+e;return{x:n.x+.5+n.nx*t,y:n.y+.5+n.ny*t,z:n.z+.5+n.nz*t}}const aE=10;let sa=null;function lE(n){if(sa===!1)return null;if(typeof CanvasRenderingContext2D>"u")return sa=!1,null;const e=document.createElement("canvas");e.width=tt,e.height=tt;let t=null;try{t=e.getContext("2d")}catch{t=null}if(!t)return sa=!1,null;sa=!0;const i=t.createImageData(tt,tt);i.data.set(QM(n)),t.putImageData(i,0,0);const r=new Vu(e);return r.magFilter=zt,r.minFilter=zt,r.generateMipmaps=!1,r.colorSpace=jt,r}function cE(n){const e=new _i(1,1),t=[],i=[];for(let s=0;s<aE;s++){const o=lE(s);t.push(o),i.push(new Wi({map:o,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1,polygonOffsetUnits:-1}))}const r=new je(e,i[0]);return r.name="crack-overlay",r.visible=!1,n.add(r),{set(s,o){if(!s){r.visible=!1;return}const a=oE(s);r.position.set(a.x,a.y,a.z);const[l,c,u]=sE({x:s.nx,y:s.ny,z:s.nz});r.rotation.set(l,c,u),r.material=i[rE(o)],r.visible=!0},dispose(){n.remove(r),e.dispose();for(const s of i)s.dispose();for(const s of t)s==null||s.dispose()}}}const nm=200,uE=12,fE=.08,dE=.16,hE=.6,pE=1.2,mE=1.5,gE=3.5,_E=2,vE=5,xE=2,SE=.3,yE=.5,ME=1,EE=2,bE=.06,AE=.12,TE=20,cr=(n,e,t)=>e+n()*(t-e);function im(n){let e=-1;for(const t of n)t.id>e&&(e=t.id);return e+1}function wE(n,e,t,i=Math.random){const r=en(e).side,s=[...n];let o=im(n);for(let a=0;a<uE;a++){const l=i()*Math.PI*2,c=cr(i,mE,gE),u=cr(i,hE,pE);s.push({id:o++,tile:r,pos:{x:t.x,y:t.y,z:t.z},vel:{x:Math.cos(l)*c,y:cr(i,_E,vE),z:Math.sin(l)*c},life:u,maxLife:u,size:cr(i,fE,dE)})}return s}function RE(n,e,t,i=Math.random){const r=en(e).side,s=[...n];let o=im(n);for(let a=0;a<xE;a++){const l=i()*Math.PI*2,c=cr(i,ME,EE),u=i(),d=Math.sqrt(Math.max(0,1-u*u))*c,f=cr(i,SE,yE);s.push({id:o++,tile:r,pos:{x:t.x,y:t.y,z:t.z},vel:{x:Math.cos(l)*d,y:u*c,z:Math.sin(l)*d},life:f,maxLife:f,size:cr(i,bE,AE)})}return s}function CE(n,e,t){const i=Number.isFinite(e)&&e>0?e:0,r=[];for(const o of n){const a=o.life-i;if(a<=0)continue;const l={x:o.pos.x,y:o.pos.y,z:o.pos.z},c={x:o.vel.x,y:o.vel.y,z:o.vel.z};c.y-=TE*i,l.x+=c.x*i,l.y+=c.y*i,l.z+=c.z*i,c.y<0&&t(Math.floor(l.x),Math.floor(l.y),Math.floor(l.z))&&(l.y=Math.floor(l.y)+1,c.y=0),r.push({...o,pos:l,vel:c,life:a})}const s=r.length-nm;return s>0?r.slice(s):r}function PE(n){const e=nm,t=e*4,i=new Jt,r=new Float32Array(t*2),s=new Float32Array(t*3);for(let d=0;d<e;d++){const f=d*4;r.set([0,0,1,0,0,1,1,1],f*2),s.fill(1,f*3,f*3+12)}i.setAttribute("position",new bt(new Float32Array(t*3),3).setUsage(Af)),i.setAttribute("uv",new bt(r,2)),i.setAttribute("texIndex",new bt(new Float32Array(t),1).setUsage(Af)),i.setAttribute("color",new bt(s,3));const o=new Uint16Array(e*6);for(let d=0;d<e;d++){const f=d*4,h=d*6;o[h]=f,o[h+1]=f+1,o[h+2]=f+2,o[h+3]=f+2,o[h+4]=f+1,o[h+5]=f+3}i.setIndex(new bt(o,1)),i.setDrawRange(0,0);const a=new Wi({vertexColors:!0,alphaTest:.1,side:gn});a.onBeforeCompile=d=>{ju(d,$u())};const l=new je(i,a);l.frustumCulled=!1,n.add(l);const c=i.getAttribute("position"),u=i.getAttribute("texIndex");return{sync(d,f){f.updateMatrixWorld();const h=f.matrixWorld.elements,g=h[0],_=h[1],m=h[2],p=h[4],E=h[5],S=h[6],y=Math.min(d.length,e),C=c.array,R=u.array;for(let A=0;A<y;A++){const P=d[A],x=P.size/2,v=g*x,w=_*x,k=m*x,B=p*x,X=E*x,J=S*x,H=A*12;C[H]=P.pos.x-v-B,C[H+1]=P.pos.y-w-X,C[H+2]=P.pos.z-k-J,C[H+3]=P.pos.x+v-B,C[H+4]=P.pos.y+w-X,C[H+5]=P.pos.z+k-J,C[H+6]=P.pos.x-v+B,C[H+7]=P.pos.y-w+X,C[H+8]=P.pos.z-k+J,C[H+9]=P.pos.x+v+B,C[H+10]=P.pos.y+w+X,C[H+11]=P.pos.z+k+J;const te=A*4;R[te]=P.tile,R[te+1]=P.tile,R[te+2]=P.tile,R[te+3]=P.tile}c.needsUpdate=!0,u.needsUpdate=!0,i.setDrawRange(0,y*6)},dispose(){n.remove(l),i.dispose(),a.dispose()}}}const IE=9,LE=7;function DE(n){return hr(n)==="day"}function NE(n){return Math.max(n.sky,n.block)}function UE(n){return NE(n)>=IE}function OE(n){return n.internalSky<=LE&&n.block===0}const FE=35,kE=40,BE=1.6,zE=3,HE=1,VE=2,GE=15,WE=.5,XE=7,qE=9,YE=3.2,Ud=3.5,Od=1.5,Na=2,rm=4,sm=32,om=8,Ua=6,am=.1,lm=.1,eo=1.4,KE=.15,ZE=40,$E=9.8,jE=.25,JE=64,QE=30,eb=.6,tb=2,nb=5,ib=12,Fd=24,rb=128,sb=128,ob=8,ab=1,lb=.3,cb={zombie:.9,skeleton:.9};let kd=-1;function ub(n,e){return kd+=1,{id:kd,kind:n,hp:20,ranged:n==="skeleton",pos:{x:e.x,y:e.y,z:e.z},vel:{x:0,y:0,z:0},state:"wander",attackCooldown:0,wanderDir:Math.random()*Math.PI*2,wanderTimer:Na+Math.random()*(rm-Na),target:null,kbVel:{x:0,z:0},burn:0,burnAcc:0}}function fb(n,e){return Math.hypot(n.x-e.x,n.z-e.z)}function oa(n){return n.hp<=0}function Bd(n,e,t){const i=Math.hypot(e.x-n.x,e.y-n.y,e.z-n.z),r=Math.ceil(i/WE);for(let s=1;s<r;s++){const o=s/r,a=n.x+(e.x-n.x)*o,l=n.y+(e.y-n.y)*o,c=n.z+(e.z-n.z)*o;if(t(Math.floor(a),Math.floor(l),Math.floor(c)))return!1}return!0}function db(n,e,t){const i=Number.isFinite(e)&&e>0?Math.max(0,n.hp-e):n.hp,r={x:n.kbVel.x,z:n.kbVel.z};if(t){const s=Math.hypot(t.x,t.z);Number.isFinite(s)&&s>0&&(r.x+=t.x/s*Ua,r.z+=t.z/s*Ua)}return{...n,hp:i,kbVel:r}}function hb(n,e){const t=Number.isFinite(e.dt)&&e.dt>0?e.dt:0,i=[],r={x:n.pos.x,y:n.pos.y,z:n.pos.z},s={x:n.vel.x,y:n.vel.y,z:n.vel.z},o={x:n.kbVel.x,z:n.kbVel.z};let a=n.state,l=Math.max(0,n.attackCooldown-t),c=n.wanderDir,u=n.wanderTimer-t;const d=e.playerPos,f=d.x-r.x,h=d.z-r.z,g=Math.hypot(f,h);g>kE?a="wander":g<=FE&&(n.ranged?a=g<XE?"retreat":"chase":a="chase");const _=a==="wander"?null:{x:d.x,y:d.y,z:d.z};let m=0,p=0;if(a==="chase"){if(!(n.ranged&&g<=qE)&&g>0){const v=n.ranged?Ud:YE;m=f/g*v,p=h/g*v}}else if(a==="retreat"&&g>0){const x=Ud;m=-f/g*x,p=-h/g*x}else u<=0&&(c=Math.random()*Math.PI*2,u=Na+Math.random()*(rm-Na)),m=Math.sin(c)*Od,p=Math.cos(c)*Od;if(!n.ranged)Math.hypot(f,d.y-r.y,h)<=BE&&l<=0&&Bd({x:r.x,y:r.y+eo,z:r.z},{x:d.x,y:d.y+eo,z:d.z},e.isSolidAt)&&(i.push({type:"damage",target:"player",amount:zE,mobId:n.id}),l=HE);else{const x={x:r.x,y:r.y+eo,z:r.z},v={x:d.x,y:d.y+eo,z:d.z};if(g<=GE&&l<=0&&Bd(x,v,e.isSolidAt)){const w={x:v.x-x.x,y:v.y-x.y+KE,z:v.z-x.z},k=Math.hypot(w.x,w.y,w.z),B=k>0&&Number.isFinite(k)?1/k:0;i.push({type:"shoot",from:x,dir:{x:w.x*B,y:w.y*B,z:w.z*B},mobId:n.id}),l=VE}}const E=Math.floor(r.x),S=Math.floor(r.z),y=e.isSolidAt(E,Math.floor(r.y-.05),S);let C=!1,R=!1;const A=Math.hypot(m,p);if(A>0){const x=A*t+Math.max(lb,cb[n.kind]/2),v=Math.floor(r.x+m/A*x),w=Math.floor(r.z+p/A*x),k=e.isSolidAt(v,Math.floor(r.y+.1),w),B=e.isSolidAt(v,Math.floor(r.y+1.5),w);C=k||B,R=k,C&&(m=0,p=0)}if(y&&s.y<=0?s.y=0:s.y-=sm*t,R&&y&&(s.y=om),s.x=m,s.z=p,o.x!==0||o.z!==0){const x=r.x+o.x*t,v=r.z+o.z*t;e.isSolidAt(Math.floor(x),Math.floor(r.y),Math.floor(v))||(r.x=x,r.z=v);const w=Math.pow(am,t);o.x*=w,o.z*=w,Math.hypot(o.x,o.z)<lm&&(o.x=0,o.z=0)}r.x+=s.x*t,r.z+=s.z*t;const P=r.y;if(r.y+=s.y*t,s.y<=0){const x=Math.floor(r.y-.05);for(let v=Math.floor(P-.05);v>=x;v--)if(e.isSolidAt(Math.floor(r.x),v,Math.floor(r.z))){r.y=v+1,s.y=0;break}}return{mob:{...n,pos:r,vel:s,state:a,attackCooldown:l,wanderDir:c,wanderTimer:u,target:_,kbVel:o},events:i}}function pb(n,e){const t=[],i=[];for(const r of n){const s=hb(r,e);t.push(s.mob);for(const o of s.events)i.push(o)}return{mobs:t,events:i}}function mb(n,e){const t=Number.isFinite(e.dt)&&e.dt>0?e.dt:0,i=Math.floor(n.pos.x),r=Math.floor(n.pos.z),s=Math.floor(n.pos.y+1.9),o=e.isSolidAt(i,s,r)||e.isSolidAt(i,s+1,r),a=e.isWaterAt(i,Math.floor(n.pos.y),r),l=n.kind==="zombie"||n.kind==="skeleton",c=e.isDaylight&&!o&&!a,u=c?ob:Math.max(0,n.burn-t);let d=n.hp,f=0;if(l&&c){f=n.burnAcc+t;const h=Math.floor(f);f-=h,d=Math.max(0,d-h*ab)}return{...n,burn:u,burnAcc:f,hp:d}}function gb(n,e,t,i){let r=-1;for(const a of n)a.id>r&&(r=a.id);const s=Math.hypot(t.x,t.y,t.z),o=s>0&&Number.isFinite(s)?ZE/s:0;return[...n,{id:r+1,pos:{x:e.x,y:e.y,z:e.z},vel:{x:t.x*o,y:t.y*o,z:t.z*o},age:0,ownerId:i}]}function _b(n,e,t){const i=e.x-n.x,r=e.y-n.y,s=e.z-n.z,o=i*i+r*r+s*s;let a=o>0?((t.x-n.x)*i+(t.y-n.y)*r+(t.z-n.z)*s)/o:0;return a<0?a=0:a>1&&(a=1),Math.hypot(t.x-(n.x+i*a),t.y-(n.y+r*a),t.z-(n.z+s*a))}function vb(n,e,t,i){const r=Number.isFinite(e)&&e>0?e:0,s=[],o=[],a={x:i.x,y:i.y+eo,z:i.z};for(const l of n){const c=l.age+r;if(c>=QE)continue;const u={x:l.vel.x,y:l.vel.y-$E*r,z:l.vel.z},d=u.x*r,f=u.y*r,h=u.z*r,g=Math.hypot(d,f,h),_=Math.min(JE,Math.max(1,Math.ceil(g/jE))),m=g/_,p=g>0?d/g:0,E=g>0?f/g:0,S=g>0?h/g:0,y={x:l.pos.x,y:l.pos.y,z:l.pos.z};let C=!1;for(let R=0;R<_&&!C;R++){const A={x:y.x,y:y.y,z:y.z};if(y.x+=p*m,y.y+=E*m,y.z+=S*m,t(Math.floor(y.x),Math.floor(y.y),Math.floor(y.z))){C=!0;break}if(_b(A,y,a)<=eb){o.push({type:"damage",target:"player",amount:tb,mobId:l.ownerId}),C=!0;break}}C||s.push({...l,pos:y,vel:u,age:c})}return{arrows:s,events:o}}function cm(n,e,t,i){const r=Math.floor(n),s=Math.floor(e);for(let o=ht-2;o>=1;o--)if(t(r,o,s))return i(r,o,s)===O.BEDROCK?null:o+1;return null}function xb(n,e,t){if(n.length>=ib)return null;const i=Sb(e,t.rng),r=cm(i.x,i.z,t.isSolidAt,t.blockIdAt);return r===null||!OE(t.lightAt(Math.floor(i.x),r,Math.floor(i.z)))?null:ub(yb(t.rng),{x:i.x,y:r,z:i.z})}function Sb(n,e=Math.random){const t=e()*Math.PI*2,i=Fd+e()*(rb-Fd);return{x:n.x+Math.sin(t)*i,z:n.z+Math.cos(t)*i}}function yb(n=Math.random){return n()<.5?"zombie":"skeleton"}function Mb(n){return n==="creative"?5:4.5}function um(n,e,t,i){let r=-1/0,s=1/0;for(const o of["x","y","z"]){const a=n[o],l=e[o];if(l===0){if(a<t[o]||a>i[o])return null;continue}let c=(t[o]-a)/l,u=(i[o]-a)/l;if(c>u&&([c,u]=[u,c]),c>r&&(r=c),u<s&&(s=u),r>s)return null}return s<0?null:Math.max(r,0)}function Eb(n,e,t,i,r){const s=Math.hypot(t.x,t.y,t.z);if(s===0)return null;const o=t.x/s,a=t.y/s,l=t.z/s,c=(r==null?void 0:r.skipOriginBlock)===!0;let u=Math.floor(e.x),d=Math.floor(e.y),f=Math.floor(e.z);const h=o>0?1:o<0?-1:0,g=a>0?1:a<0?-1:0,_=l>0?1:l<0?-1:0,m=h!==0?Math.abs(1/o):1/0,p=g!==0?Math.abs(1/a):1/0,E=_!==0?Math.abs(1/l):1/0,S=w=>w-Math.floor(w);let y=h===0?1/0:h>0?(1-S(e.x))*m:S(e.x)*m,C=g===0?1/0:g>0?(1-S(e.y))*p:S(e.y)*p,R=_===0?1/0:_>0?(1-S(e.z))*E:S(e.z)*E,A=0,P=0,x=0,v=0;if(n.isTargetable(u,d,f)&&!c){const w=Math.abs(o),k=Math.abs(a),B=Math.abs(l);return w>=k&&w>=B?{x:u,y:d,z:f,nx:-h,ny:0,nz:0,t:v}:k>=B?{x:u,y:d,z:f,nx:0,ny:-g,nz:0,t:v}:{x:u,y:d,z:f,nx:0,ny:0,nz:-_,t:v}}for(;v<=i&&(y<C&&y<R?(u+=h,v=y,y+=m,A=-h,P=0,x=0):C<R?(d+=g,v=C,C+=p,A=0,P=-g,x=0):(f+=_,v=R,R+=E,A=0,P=0,x=-_),!(v>i));)if(n.isTargetable(u,d,f))return{x:u,y:d,z:f,nx:A,ny:P,nz:x,t:v};return null}const Cs={chicken:{kind:"chicken",hp:4,width:.4,height:.7,vanillaSpeed:.25,speed:1.9},pig:{kind:"pig",hp:10,width:.9,height:.9,vanillaSpeed:.25,speed:1.9},sheep:{kind:"sheep",hp:8,width:.9,height:1.3,vanillaSpeed:.23,speed:1.7},cow:{kind:"cow",hp:10,width:.9,height:1.4,vanillaSpeed:.2,speed:1.5}},Oa=12,bb=1.4,Ab=5,Fa=2,fm=4,Tb=.3;let zd=-1;function dm(n,e,t=Math.random){zd+=1;const i=Cs[n];return{id:zd,kind:n,hp:i.hp,width:i.width,height:i.height,pos:{x:e.x,y:e.y,z:e.z},vel:{x:0,y:0,z:0},yaw:0,wanderDir:t()*Math.PI*2,wanderTimer:Fa+t()*(fm-Fa),panicTimer:0,panicDir:0,kbVel:{x:0,z:0}}}function aa(n){return n.hp<=0}function wb(n,e,t,i){const r=Number.isFinite(e)&&e>0,s=r?Math.max(0,n.hp-e):n.hp,o={x:n.kbVel.x,z:n.kbVel.z},a=i?Math.hypot(i.x,i.z):0,l=Number.isFinite(a)&&a>0;i&&l&&(o.x+=i.x/a*Ua,o.z+=i.z/a*Ua);const c=r?Ab:n.panicTimer;let u=n.panicDir;return r&&(u=t?Math.atan2(n.pos.x-t.x,n.pos.z-t.z):n.wanderDir+Math.PI),{...n,hp:s,kbVel:o,panicTimer:c,panicDir:u}}function Rb(n,e){const t=Number.isFinite(e.dt)&&e.dt>0?e.dt:0,i=Cs[n.kind],r=e.rng??Math.random,s={x:n.pos.x,y:n.pos.y,z:n.pos.z},o={x:n.vel.x,y:n.vel.y,z:n.vel.z},a={x:n.kbVel.x,z:n.kbVel.z};let l=n.wanderDir,c=n.wanderTimer-t;const u=Math.max(0,n.panicTimer-t);let d,f,h;if(u>0){d=Math.sin(n.panicDir),f=Math.cos(n.panicDir),h=i.speed*bb;const P=e.playerPos.x-s.x,x=e.playerPos.z-s.z;d*P+f*x>0&&(d=-d,f=-f)}else c<=0&&(l=r()*Math.PI*2,c=Fa+r()*(fm-Fa)),d=Math.sin(l),f=Math.cos(l),h=i.speed;let g=d*h,_=f*h;const m=Math.hypot(g,_);let p=!1;if(m>0){const P=m*t+Math.max(Tb,i.width/2),x=Math.floor(s.x+g/m*P),v=Math.floor(s.z+_/m*P),w=e.isSolidAt(x,Math.floor(s.y+.1),v),k=e.isSolidAt(x,Math.floor(s.y+i.height+.1),v);(w||k)&&(g=0,_=0),p=w}const E=Math.floor(s.x),S=Math.floor(s.z),y=e.isWaterAt(E,Math.floor(s.y),S),C=e.isSolidAt(E,Math.floor(s.y-.05),S);if(y||C&&o.y<=0?o.y=0:o.y-=sm*t,p&&C&&!y&&(o.y=om),o.x=g,o.z=_,a.x!==0||a.z!==0){const P=s.x+a.x*t,x=s.z+a.z*t;e.isSolidAt(Math.floor(P),Math.floor(s.y),Math.floor(x))||(s.x=P,s.z=x);const v=Math.pow(am,t);a.x*=v,a.z*=v,Math.hypot(a.x,a.z)<lm&&(a.x=0,a.z=0)}const R=s.y;if(s.x+=o.x*t,s.z+=o.z*t,s.y+=o.y*t,!y&&o.y<=0){const P=Math.floor(s.y-.05);for(let x=Math.floor(R-.05);x>=P;x--)if(e.isSolidAt(Math.floor(s.x),x,Math.floor(s.z))){s.y=x+1,o.y=0;break}}let A=n.yaw;return Math.hypot(o.x,o.z)>.01&&(A=Math.atan2(o.x,o.z)),{...n,pos:s,vel:o,kbVel:a,yaw:A,wanderDir:l,wanderTimer:c,panicTimer:u}}function Cb(n,e){return n.map(t=>Rb(t,e))}function hm(n,e,t,i){if(!Number.isFinite(i)||i<=0||![e.x,e.y,e.z,t.x,t.y,t.z].every(Number.isFinite))return null;const r=Math.hypot(t.x,t.y,t.z);if(r===0)return null;const s={x:t.x/r,y:t.y/r,z:t.z/r};let o=1/0,a=null;for(const l of n){if(![l.pos.x,l.pos.y,l.pos.z].every(Number.isFinite))continue;const c=l.width/2,u=um(e,s,{x:l.pos.x-c,y:l.pos.y,z:l.pos.z-c},{x:l.pos.x+c,y:l.pos.y+l.height,z:l.pos.z+c});u===null||u>i||u<o&&(o=u,a=l.id)}return a}function Pb(n,e,t,i,r,s){const o=hm(n,e,t,i);if(o===null)return{mobs:n,hitId:null};let a=!1;return{mobs:n.map(c=>a||c.id!==o?c:(a=!0,wb(c,r,{x:e.x,z:e.z},s))),hitId:o}}function Ib(n=Math.random){const e=["chicken","pig","sheep","cow"],t=Math.floor(n()*e.length);return e[Math.min(e.length-1,Math.max(0,t))]}const Lb=10,Db=48,Hd=28,Vd=2,Nb=4,la=2;function Ub(n,e=Math.random){const t=e()*Math.PI*2,i=Hd+e()*(Db-Hd);return{x:n.x+Math.sin(t)*i,z:n.z+Math.cos(t)*i,dist:i}}function Gd(n){return n===O.GRASS||n===O.DIRT}function Wd(n,e,t,i){const r=Math.floor(n),s=Math.floor(e),o=cm(r,s,t,i);if(o===null)return null;const a=o-1;if(Gd(i(r,a,s)))return a;for(let l=a-1;l>=1;l--)if(t(r,l,s)&&Gd(i(r,l,s)))return l;return null}function Ob(n,e,t,i,r){const s=Math.ceil(i),o=Math.floor(n),a=Math.floor(t);for(let l=0;l<s;l++)if(r(o,e+l,a))return!1;return!0}function Fb(n,e,t){const i=t.rng??Math.random;if(n.length>=Oa)return n;const r=Ub(e,i);if(Wd(r.x,r.z,t.isSolidAt,t.blockIdAt)===null)return n;const s=Vd+Math.floor(i()*(Nb-Vd+1)),o=Ib(i),a=Cs[o],l=[];for(let c=0;c<s&&!(n.length+l.length>=Oa);c++){const u=i()*la*2-la,d=i()*la*2-la,f=r.x+u,h=r.z+d,g=Wd(f,h,t.isSolidAt,t.blockIdAt);if(g===null)continue;const _=g+1;UE(t.lightAt(Math.floor(f),_,Math.floor(h)))&&Ob(f,_,h,a.height,t.isSolidAt)&&l.push(dm(o,{x:f,y:_,z:h},i))}return l.length===0?n:[...n,...l]}const kb=.1,Bb=.6,zb=4,Hb=.01,Vb={chicken:{body:16053492,head:16053492,leg:15246141,accent:14173503,accent2:15910205},pig:{body:15573936,head:15573936,leg:14388121,accent:13202307,accent2:13202307},sheep:{body:15921900,head:11974317,leg:14474450,accent:16448244,accent2:11974317},cow:{body:7162672,head:7162672,leg:4929060,accent:15921898,accent2:3812125}};function el(n,e,t){const i=n.legH*t,r=n.headSide*Math.min(e,t),s=n.topExtra*t,o=t-s,a=o-r/2,c=o-r+n.headSink*r;return{legH:i,legSize:n.legW*e,legX:n.legX*e,headSide:r,headTop:o,headCenterY:a,headZ:n.headZ*e,headFrontZ:n.headZ*e+r/2,bodyH:Math.max(.05,c-i),bodyCenterY:(i+c)/2,bodyW:n.bodyW*e,bodyD:n.bodyD*e,bodyZ:n.bodyZ*e,topExtra:s}}function Gb(n,e){const i=el({legH:.18,legW:.16,legX:.2,bodyW:.66,bodyD:.52,bodyZ:-.1,headSide:.4,headZ:.1,headSink:.3,topExtra:.09},n,e),r=i.topExtra,s=.16*n;return{legs:[{x:i.legX,height:i.legH,thickness:i.legSize},{x:-i.legX,height:i.legH,thickness:i.legSize}],blocks:[{name:"body",slot:"body",size:{x:i.bodyW,y:i.bodyH,z:i.bodyD},pos:{x:0,y:i.bodyCenterY,z:i.bodyZ}},{name:"head",slot:"head",size:{x:i.headSide,y:i.headSide,z:i.headSide},pos:{x:0,y:i.headCenterY,z:i.headZ}},{name:"comb",slot:"accent",size:{x:.14*n,y:r,z:.26*n},pos:{x:0,y:i.headTop+r/2,z:i.headZ}},{name:"beak",slot:"accent2",size:{x:.18*n,y:.07*e,z:s},pos:{x:0,y:i.headCenterY-.12*i.headSide,z:i.headFrontZ+s/2}}]}}function Wb(n,e){const i=el({legH:.22,legW:.16,legX:.24,bodyW:.72,bodyD:.74,bodyZ:-.06,headSide:.38,headZ:.22,headSink:.3,topExtra:0},n,e),r=.08*n;return{legs:[{x:i.legX,height:i.legH,thickness:i.legSize},{x:-i.legX,height:i.legH,thickness:i.legSize}],blocks:[{name:"body",slot:"body",size:{x:i.bodyW,y:i.bodyH,z:i.bodyD},pos:{x:0,y:i.bodyCenterY,z:i.bodyZ}},{name:"head",slot:"head",size:{x:i.headSide,y:i.headSide,z:i.headSide},pos:{x:0,y:i.headCenterY,z:i.headZ}},{name:"snout",slot:"accent",size:{x:.2*n,y:.14*e,z:r},pos:{x:0,y:i.headCenterY-.1*i.headSide,z:i.headFrontZ+r/2}}]}}function Xb(n,e){const i=el({legH:.2,legW:.15,legX:.21,bodyW:.82,bodyD:.72,bodyZ:-.04,headSide:.32,headZ:.24,headSink:.3,topExtra:0},n,e),r=.08*e,s=i.bodyCenterY+i.bodyH/2;return{legs:[{x:i.legX,height:i.legH,thickness:i.legSize},{x:-i.legX,height:i.legH,thickness:i.legSize}],blocks:[{name:"body",slot:"body",size:{x:i.bodyW,y:i.bodyH,z:i.bodyD},pos:{x:0,y:i.bodyCenterY,z:i.bodyZ}},{name:"wool",slot:"accent",size:{x:.68*n,y:r,z:.44*n},pos:{x:0,y:s+r/2,z:-.15*n}},{name:"head",slot:"head",size:{x:i.headSide,y:i.headSide,z:i.headSide},pos:{x:0,y:i.headCenterY,z:i.headZ}}]}}function qb(n,e){const i=el({legH:.22,legW:.16,legX:.23,bodyW:.7,bodyD:.72,bodyZ:-.04,headSide:.38,headZ:.24,headSink:.3,topExtra:.09},n,e),r=i.topExtra,s=i.bodyCenterY+i.bodyH/2;return{legs:[{x:i.legX,height:i.legH,thickness:i.legSize},{x:-i.legX,height:i.legH,thickness:i.legSize}],blocks:[{name:"body",slot:"body",size:{x:i.bodyW,y:i.bodyH,z:i.bodyD},pos:{x:0,y:i.bodyCenterY,z:i.bodyZ}},{name:"head",slot:"head",size:{x:i.headSide,y:i.headSide,z:i.headSide},pos:{x:0,y:i.headCenterY,z:i.headZ}},{name:"hornL",slot:"accent2",size:{x:.07*n,y:r,z:.07*n},pos:{x:.13*n,y:i.headTop+r/2,z:.2*n}},{name:"hornR",slot:"accent2",size:{x:.07*n,y:r,z:.07*n},pos:{x:-.13*n,y:i.headTop+r/2,z:.2*n}},{name:"spotL",slot:"accent",size:{x:.04*n,y:.2*e,z:.28*n},pos:{x:i.bodyW/2-.01,y:i.bodyCenterY,z:i.bodyZ}},{name:"spotR",slot:"accent",size:{x:.04*n,y:.2*e,z:.28*n},pos:{x:-(i.bodyW/2-.01),y:i.bodyCenterY,z:i.bodyZ}},{name:"spotTop",slot:"accent",size:{x:.24*n,y:.03*e,z:.22*n},pos:{x:0,y:s+.013,z:-.12*n}}]}}const Yb={chicken:Gb,pig:Wb,sheep:Xb,cow:qb};function Kb(n,e,t){const i=e.width,r=e.height,s=Yb[n](i,r),o=Vb[n],a=new Map;function l(h){const g=a.get(h);if(g)return g;const _=new bn({color:o[h]});return a.set(h,_),_}const c=new Dn;c.name=`passive:${n}`;for(const h of s.blocks){const g=new je(t,l(h.slot));g.name=h.name,g.scale.set(h.size.x,h.size.y,h.size.z),g.position.set(h.pos.x,h.pos.y,h.pos.z),c.add(g)}function u(h,g){const _=new Dn;_.name=h,_.position.set(g.x,g.height,0);const m=new je(t,l("leg"));return m.scale.set(g.thickness,g.height,g.thickness),m.position.y=-g.height/2,_.add(m),c.add(_),_}const d=u("legL",s.legs[0]),f=u("legR",s.legs[1]);return c.traverse(h=>{h instanceof je&&(h.castShadow=!0)}),{kind:n,group:c,legL:d,legR:f,materials:[...a.values()]}}function Zb(n){const e=new rn(1,1,1),t=new Map;function i(r){const s=t.get(r);if(s){n.remove(s.group);for(const o of s.materials)o.dispose();t.delete(r)}}return{syncPassiveMobs(r,s){const o=Number.isFinite(s)&&s>0?s:0,a=new Set;for(const l of r){a.add(l.id);let c=t.get(l.id);if(c&&c.kind!==l.kind&&(i(l.id),c=void 0),!c){const p=Cs[l.kind];c={...Kb(l.kind,{width:p.width,height:p.height},e),phase:0,swing:0,flash:0},t.set(l.id,c),n.add(c.group)}const u=Number.isFinite(l.pos.x)?l.pos.x:0,d=Number.isFinite(l.pos.y)?l.pos.y:0,f=Number.isFinite(l.pos.z)?l.pos.z:0;c.group.position.set(u,d,f),c.group.rotation.y=Number.isFinite(l.yaw)?l.yaw:0;const h=Number.isFinite(l.vel.x)?l.vel.x:0,g=Number.isFinite(l.vel.z)?l.vel.z:0,_=Math.hypot(h,g);_>Hb&&o>0?(c.phase+=_*o*zb,c.swing=Math.sin(c.phase)*Bb):o>0&&(c.swing*=Math.pow(.01,o),Math.abs(c.swing)<1e-4&&(c.swing=0,c.phase=0)),c.legL.rotation.x=c.swing,c.legR.rotation.x=-c.swing,c.flash=Math.max(0,c.flash-o);const m=c.flash>0?16777215:0;for(const p of c.materials)p.emissive.setHex(m)}for(const l of[...t.keys()])a.has(l)||i(l)},flashPassiveMob(r){const s=t.get(r);if(s){s.flash=kb;for(const o of s.materials)o.emissive.setHex(16777215)}},dispose(){for(const r of[...t.keys()])i(r);e.dispose()}}}const $b=900,Xd=8900331,jb=800,qd=60,Jb=16772234,Yd=40,Qb=15265266;function eA(n,e=jb){return{sun:{x:n.x*e,y:n.y*e,z:n.z*e},moon:{x:-n.x*e,y:-n.y*e,z:-n.z*e}}}const tA=`
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,nA=`
uniform vec3 horizon;
uniform vec3 zenith;
varying vec3 vDir;
void main() {
  gl_FragColor = vec4(mix(horizon, zenith, clamp(vDir.y * 1.6 + 0.15, 0.0, 1.0)), 1.0);
  #include <colorspace_fragment>
}
`;function iA(n){const e=new Gu($b,32,16),t=new gi({uniforms:{horizon:{value:new et(Xd)},zenith:{value:new et(Xd)}},vertexShader:tA,fragmentShader:nA,side:sn,fog:!1,depthWrite:!1}),i=new je(e,t);i.name="sky-dome",i.renderOrder=-2;const r=new _i(qd,qd),s=new Wi({color:Jb,fog:!1}),o=new je(r,s);o.name="sky-sun";const a=new _i(Yd,Yd),l=new Wi({color:Qb,fog:!1}),c=new je(a,l);return c.name="sky-moon",n.add(i,o,c),{setSky(u,d,f){i.position.set(f.x,f.y,f.z);const h=eA(u);o.position.set(f.x+h.sun.x,f.y+h.sun.y,f.z+h.sun.z),c.position.set(f.x+h.moon.x,f.y+h.moon.y,f.z+h.moon.z),o.lookAt(f.x,f.y,f.z),c.lookAt(f.x,f.y,f.z),t.uniforms.horizon.value.setHex(d.horizon),t.uniforms.zenith.value.setHex(d.zenith)},dispose(){n.remove(i,o,c),e.dispose(),t.dispose(),r.dispose(),s.dispose(),a.dispose(),l.dispose()}}}function bo(n,e,t){let i=(t^Math.imul(n|0,374761393)^Math.imul(e|0,668265263))>>>0;return i=Math.imul(i^i>>>13,1274126177)>>>0,(i^i>>>16)>>>0}function rA(n){let e=n>>>0;return()=>{e=e+1831565813>>>0;let t=e;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}}const Ws=n=>n*n*n*(n*(n*6-15)+10),Un=(n,e,t)=>n+(e-n)*t;function ca(n,e,t){const i=n&7,r=i<4?e:t,s=i<4?t:e;return(i&1?-r:r)+(i&2?-s:s)}function Ci(n,e,t,i){const r=n&15,s=r<8?e:t,o=r<4?t:r===12||r===14?e:i;return(r&1?-s:s)+(r&2?-o:o)}class to{constructor(e){ke(this,"p",new Uint8Array(512));const t=rA(e),i=new Uint8Array(256);for(let r=0;r<256;r++)i[r]=r;for(let r=255;r>0;r--){const s=Math.floor(t()*(r+1));[i[r],i[s]]=[i[s],i[r]]}for(let r=0;r<512;r++)this.p[r]=i[r&255]}noise2(e,t){const i=Math.floor(e)&255,r=Math.floor(t)&255,s=e-Math.floor(e),o=t-Math.floor(t),a=Ws(s),l=Ws(o),c=this.p,u=c[c[i]+r],d=c[c[i]+r+1],f=c[c[i+1]+r],h=c[c[i+1]+r+1],g=Un(ca(u,s,o),ca(f,s-1,o),a),_=Un(ca(d,s,o-1),ca(h,s-1,o-1),a);return Un(g,_,l)}noise3(e,t,i){const r=Math.floor(e)&255,s=Math.floor(t)&255,o=Math.floor(i)&255,a=e-Math.floor(e),l=t-Math.floor(t),c=i-Math.floor(i),u=Ws(a),d=Ws(l),f=Ws(c),h=this.p,g=h[r]+s,_=h[g]+o,m=h[g+1]+o,p=h[r+1]+s,E=h[p]+o,S=h[p+1]+o,y=Un(Ci(h[_],a,l,c),Ci(h[E],a-1,l,c),u),C=Un(Ci(h[m],a,l-1,c),Ci(h[S],a-1,l-1,c),u),R=Un(y,C,d),A=Un(Ci(h[_+1],a,l,c-1),Ci(h[E+1],a-1,l,c-1),u),P=Un(Ci(h[m+1],a,l-1,c-1),Ci(h[S+1],a-1,l-1,c-1),u),x=Un(A,P,d);return Un(R,x,f)}fbm2(e,t,i,r=2,s=.5){let o=1,a=1,l=0,c=0;for(let u=0;u<i;u++)l+=this.noise2(e*a,t*a)*o,c+=o,o*=s,a*=r;return l/c}}function sA(n,e=512,t=16,i=.3){const r=[],s=Math.floor(e/t);for(let o=0;o<s;o++)for(let a=0;a<s;a++){const l=bo(a,o,n^49421);l%100<i*100&&r.push({x:a*16+2,z:o*16+2,w:12,d:12,h:3+(l>>>8)%3})}return r}function Kd(n,e,t=512){return Math.floor((n-e)/t)*t}const oA=150,Zd=512,aA=.6,lA=.1;function cA(n,e){const t=sA(e),i=new rn(1,1,1),r=new bn({color:16777215}),s=new Ny(i,r,t.length);s.name="clouds-mesh",s.frustumCulled=!1,s.castShadow=!1,s.receiveShadow=!1;const o=new St;t.forEach((l,c)=>{o.makeScale(l.w,l.h,l.d),o.setPosition(l.x+l.w/2,oA+l.h/2,l.z+l.d/2),s.setMatrixAt(c,o)}),s.instanceMatrix.needsUpdate=!0;const a=new Dn;return a.name="clouds",a.add(s),n.add(a),{update(l,c,u){const d=u*aA%Zd,f=u*lA%Zd;a.position.set(Kd(l,d)+d,0,Kd(c,f)+f)},setEnabled(l){a.visible=l},dispose(){n.remove(a),s.dispose(),i.dispose(),r.dispose()}}}const $d={wooden_pickaxe:59,wooden_axe:59,wooden_shovel:59,wooden_sword:59,stone_pickaxe:131,stone_axe:131,stone_shovel:131,stone_sword:131,iron_pickaxe:250,iron_axe:250,iron_shovel:250,iron_sword:250,golden_pickaxe:32,golden_axe:32,golden_shovel:32,golden_sword:32,diamond_pickaxe:1561,diamond_axe:1561,diamond_shovel:1561,diamond_sword:1561};function qn(n){return Object.hasOwn($d,n)?$d[n]:0}function pm(n){return qn(n)>0}function mm(n){const e=qn(n.item);if(e===0)return 0;const t=n.dur;return typeof t=="number"&&Number.isInteger(t)&&t>=0&&t<=e?t:e}function lo(n,e){const t=qn(n);if(t!==0&&!(typeof e!="number"||!Number.isFinite(e))&&Number.isInteger(e)&&!(e<0))return e>t?t:e}function uA(n,e){if(!Number.isFinite(e)||e<1)return{stack:{...n},broke:!1};if(qn(n.item)===0)return{stack:{...n},broke:!1};const i=mm(n)-Math.floor(e);return i<=0?{stack:null,broke:!0}:{stack:{...n,dur:i},broke:!1}}const fA={grass:!0,dirt:!0,stone:!0,cobblestone:!0,oak_log:!0,oak_planks:!0,sand:!0,gravel:!0,glass:!0,coal_ore:!0,iron_ore:!0,crafting_table:!0,furnace:!0,chest:!0,stick:!0,coal:!0,iron_ingot:!0,raw_iron:!0,wooden_pickaxe:!0,stone_pickaxe:!0,iron_pickaxe:!0,wooden_axe:!0,stone_axe:!0,iron_axe:!0,wooden_sword:!0,stone_sword:!0,iron_sword:!0,arrow:!0,apple:!0,oak_leaves:!0,snow_block:!0,bedrock:!0,spruce_log:!0,spruce_leaves:!0,birch_log:!0,birch_leaves:!0,dandelion:!0,poppy:!0,short_grass:!0,cactus:!0,ice:!0,wool:!0,raw_chicken:!0,cooked_chicken:!0,raw_porkchop:!0,cooked_porkchop:!0,raw_mutton:!0,cooked_mutton:!0,raw_beef:!0,steak:!0,leather:!0,feather:!0,rotten_flesh:!0,bone:!0,gold_ore:!0,diamond_ore:!0,spruce_planks:!0,birch_planks:!0,raw_gold:!0,gold_ingot:!0,diamond:!0,wooden_shovel:!0,stone_shovel:!0,iron_shovel:!0,golden_pickaxe:!0,golden_axe:!0,golden_sword:!0,golden_shovel:!0,diamond_pickaxe:!0,diamond_axe:!0,diamond_sword:!0,diamond_shovel:!0,torch:!0},gm=Object.keys(fA),_m=[["grass",O.GRASS],["dirt",O.DIRT],["stone",O.STONE],["cobblestone",O.COBBLE],["oak_log",O.LOG],["oak_planks",O.PLANKS],["sand",O.SAND],["glass",O.GLASS],["coal_ore",O.COAL_ORE],["iron_ore",O.IRON_ORE],["oak_leaves",O.LEAVES],["snow_block",O.SNOW],["bedrock",O.BEDROCK],["crafting_table",O.CRAFTING_TABLE],["furnace",O.FURNACE],["spruce_log",O.SPRUCE_LOG],["spruce_leaves",O.SPRUCE_LEAVES],["birch_log",O.BIRCH_LOG],["birch_leaves",O.BIRCH_LEAVES],["dandelion",O.DANDELION],["poppy",O.POPPY],["short_grass",O.SHORT_GRASS],["cactus",O.CACTUS],["ice",O.ICE],["wool",O.WOOL],["gravel",O.GRAVEL],["gold_ore",O.GOLD_ORE],["diamond_ore",O.DIAMOND_ORE],["spruce_planks",O.SPRUCE_PLANKS],["birch_planks",O.BIRCH_PLANKS],["torch",O.TORCH]],dA=new Map(_m),hA=new Map(_m.map(([n,e])=>[e,n])),pA=new Set(["wooden_pickaxe","stone_pickaxe","iron_pickaxe","wooden_axe","stone_axe","iron_axe","wooden_sword","stone_sword","iron_sword","wooden_shovel","stone_shovel","iron_shovel","golden_pickaxe","golden_axe","golden_sword","golden_shovel","diamond_pickaxe","diamond_axe","diamond_sword","diamond_shovel"]);function Hi(n){return pA.has(n)?1:64}function ui(n){return n.split("_").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ")}function vm(n){return hA.get(n)??null}function Ju(n){return dA.get(n)??null}function mA(n,e){const t=vm(n);return t?{item:t,count:Hi(t)}:null}const Ta=9,xm=27,Vi=Ta+xm;function Oi(n){if(n==="survival")return new Array(Vi).fill(null);const e=Qy.map(t=>mA(t));return[...e,...new Array(Vi-e.length).fill(null)]}const gA=new Set(gm),_A=n=>typeof n=="string"&&gA.has(n);function vA(n){if(typeof n!="object"||n===null)return null;const e=n;if(!_A(e.item)||typeof e.count!="number"||!Number.isFinite(e.count)||e.count<=0)return null;const t=qn(e.item);if(t>0){const i=lo(e.item,e.dur);return{item:e.item,count:e.count,dur:i??t}}return{item:e.item,count:e.count}}function fi(n,e){const t=Number.isFinite(e)?Math.max(0,Math.floor(e)):0,i=Array.isArray(n)?n:[],r=[];for(let s=0;s<t;s++)r.push(vA(i[s]));return r}function xA(n){if(n===null)return{kind:"none"};const e=Ju(n);return e!==null?{kind:"block",blockId:e}:{kind:"icon",item:n}}const SA=.25;function yA(n){return{t:0,active:!0}}function MA(n,e){if(!Number.isFinite(e))return n;const t=n.t+e/SA;return t>=1?{t:1,active:!1}:{t,active:n.active}}const EA=n=>n<0?0:n>1?1:n;function bA(n){const e=Math.sin(Math.PI*EA(n));return{rotX:-1.4*e,posY:-.15*e,posZ:-.25*e}}function AA(n){return{posY:.02*Math.sin(n),posX:.015*Math.sin(n/2),rotZ:.03*Math.sin(n)}}const jd=.42,Jd=-.42,Qd=-.75,TA=-.6,Jl=.38,eh=.45,th=["side","side","top","bottom","side","side"];function wA(n,e){const t=en(e),i=n.array;for(let r=0;r<th.length;r++){const s=t[th[r]];for(let o=0;o<4;o++)i[r*4+o]=s}n.needsUpdate=!0}function RA(n,e,t){n.add(e);const i=new Dn;i.name="viewmodel",i.position.set(jd,Jd,Qd),i.rotation.y=TA,e.add(i);const r=new rn(Jl,Jl,Jl),s=new bt(new Float32Array(24),1);r.setAttribute("texIndex",s);const o=new Wi({alphaTest:.1});o.onBeforeCompile=p=>{ju(p,$u())};const a=new je(r,o);a.visible=!1;const l=new _i(eh,eh),c=new Wi({transparent:!0,alphaTest:.1,side:gn}),u=new je(l,c);u.visible=!1,i.add(a,u);let d={t:0,active:!1},f=0;function h(p){var S;const E=xA(p);if(a.visible=E.kind==="block",u.visible=E.kind==="icon",E.kind==="block")wA(s,E.blockId);else if(E.kind==="icon"){const y=new Vu(t(E.item));y.colorSpace=jt,(S=c.map)==null||S.dispose(),c.map=y,c.needsUpdate=!0}}function g(){d=yA(d)}function _(p,E,S){i.visible=E,d.active&&(d=MA(d,p)),f+=S*p;const y=bA(d.t),C=AA(f);i.position.set(jd+C.posX,Jd+y.posY+C.posY,Qd+y.posZ),i.rotation.x=y.rotX,i.rotation.z=C.rotZ}function m(){var p;e.remove(i),r.dispose(),o.dispose(),l.dispose(),(p=c.map)==null||p.dispose(),c.dispose()}return{setItem:h,startSwing:g,update:_,dispose:m}}const CA=13209951,PA=4157365,IA=3490140,LA=2825490,DA=.9;function NA(n){const e=new Dn;e.name="player",e.scale.setScalar(DA);const t=new rn(.5,.5,.5),i=new rn(.5,.75,.25),r=new rn(.25,.75,.25),s=new _i(.4,.25),o=[t,i,r,s],a=new bn({color:CA}),l=new bn({color:PA}),c=new bn({color:IA}),u=new bn({color:LA}),d=[a,l,c,u],f=new je(t,a);f.name="head",f.position.y=1.75;const h=new je(i,l);h.name="body",h.position.y=1.125;const g=new je(r,a);g.name="armL",g.position.set(.375,1.125,0);const _=new je(r,a);_.name="armR",_.position.set(-.375,1.125,0);const m=new je(r,c);m.name="legL",m.position.set(.125,.375,0);const p=new je(r,c);p.name="legR",p.position.set(-.125,.375,0);const E=new je(s,u);return E.name="face",E.position.set(0,1.75,-.26),E.rotation.y=Math.PI,e.add(f,h,g,_,m,p,E),e.traverse(S=>{S instanceof je&&(S.castShadow=!0)}),n.add(e),{group:e,setPose(S,y){e.position.set(Number.isFinite(S.x)?S.x:0,Number.isFinite(S.y)?S.y:0,Number.isFinite(S.z)?S.z:0),e.rotation.y=Number.isFinite(y)?y:0},setVisible(S){e.visible=S},dispose(){n.remove(e);for(const S of o)S.dispose();for(const S of d)S.dispose()}}}const $n=62,UA=2,nh=.001,OA=3,ih=.0022,FA=3,rh=.0045,ka=.002,Sm=3,kA=-.107,BA=.15,zA=.3,HA=.1,VA=8,GA=40,WA=625341585,XA=2146121005,qA=2221713035,YA=2654435769,sh=37.13,oh=91.31,ah=50,Xr=[[-.66,-34],[-.45,-26],[-.28,-17],[-.107,-2],[0,3],[.12,7],[.28,11],[.45,15]],lh=new Map;function Ao(n){let e=lh.get(n);return e||(e={cont:new to(n^WA),ero:new to(n^XA),ridge:new to(n^qA),clim:new to(n^YA)},lh.set(n,e)),e}const Za=class Za{constructor(){ke(this,"layers",new Map)}get(e,t,i){var r,s;return(s=(r=this.layers.get(e))==null?void 0:r.columns.get(t))==null?void 0:s.get(i)}set(e,t,i,r){let s=this.layers.get(e);s||(s={columns:new Map,count:0},this.layers.set(e,s));let o=s.columns.get(t);o||(o=new Map,s.columns.set(t,o)),o.has(i)||(s.count++,s.count>Za.CAP&&(s.columns.clear(),s.count=0,o=new Map,s.columns.set(t,o))),o.set(i,r)}};ke(Za,"CAP",25e4);let Xi=Za;const ch=new Xi,uh=new Xi,fh=new Xi,dh=new Xi,hh=new Xi,ph=new Xi;function Ql(n){return n<0?0:n>1?1:n}function KA(n){const e=Xr[0],t=Xr[Xr.length-1];if(n<=e[0])return e[1];if(n>=t[0])return t[1];for(let i=0;i<Xr.length-1;i++){const[r,s]=Xr[i],[o,a]=Xr[i+1];if(n>=r&&n<=o)return s+(a-s)*(n-r)/(o-r)}return t[1]}function ZA(n,e,t){const i=ch.get(t,n,e);if(i!==void 0)return i;const r=Ao(t).cont.fbm2(n*nh,e*nh,OA);return ch.set(t,n,e,r),r}function $A(n,e,t){const i=uh.get(t,n,e);if(i!==void 0)return i;const r=Ao(t).ero.fbm2(n*ih+sh,e*ih+sh,FA);return uh.set(t,n,e,r),r}function jA(n,e,t){const i=fh.get(t,n,e);if(i!==void 0)return i;const r=Ao(t).ridge.noise2(n*rh+oh,e*rh+oh),s=1-Math.abs(3*Math.abs(r)-2);return fh.set(t,n,e,s),s}function xr(n,e,t){const i=dh.get(t,n,e);if(i!==void 0)return i;const r=ZA(n,e,t),s=$A(n,e,t),o=jA(n,e,t),a=Ql((BA-s)/zA),l=Ql(o),c=Ql((r-kA)/HA),u=$n+UA+KA(r)+c*a*(VA+GA*l),d=Math.max(4,Math.min(ht-10,Math.floor(u)));return dh.set(t,n,e,d),d}function ym(n,e,t){const i=hh.get(t,n,e);if(i!==void 0)return i;const r=Ao(t).clim.fbm2(n*ka,e*ka,Sm);return hh.set(t,n,e,r),r}function JA(n,e,t){const i=ph.get(t,n,e);if(i!==void 0)return i;const r=Ao(t).clim.fbm2(n*ka+ah,e*ka+ah,Sm);return ph.set(t,n,e,r),r}const Xs=[{block:O.COAL_ORE,minY:0,maxY:126,shape:"uniform",peakY:0,halfWidth:0,baseChance:1/120,salt:1369688033},{block:O.IRON_ORE,minY:0,maxY:67,shape:"triangle",peakY:39,halfWidth:39,baseChance:1/260,salt:797646165},{block:O.GOLD_ORE,minY:0,maxY:47,shape:"triangle",peakY:24,halfWidth:24,baseChance:1/900,salt:2082314755},{block:O.DIAMOND_ORE,minY:1,maxY:39,shape:"ramp",peakY:1,halfWidth:0,baseChance:1/1400,salt:996028279},{block:O.GRAVEL,minY:0,maxY:60,shape:"uniform",peakY:0,halfWidth:0,baseChance:1/1200,salt:1822048699}];function QA(n,e){return e<n.minY||e>n.maxY?0:n.shape==="uniform"?1:n.shape==="ramp"?(n.maxY-e)/(n.maxY-n.minY):Math.max(0,1-Math.abs(e-n.peakY)/n.halfWidth)}const eT=4294967296;function tT(n,e,t,i){const r=e*j,s=t*j,o=new Array(Xs.length);for(let a=1;a<ht;a++){let l=!1;for(let c=0;c<Xs.length;c++){const u=QA(Xs[c],a);o[c]=u,u>0&&(l=!0)}if(l)for(let c=0;c<j;c++){const u=s+c;for(let d=0;d<j;d++){const f=Rt(d,a,c);if(n[f]!==O.STONE)continue;const h=r+d;for(let g=0;g<Xs.length;g++){const _=o[g];if(_===0)continue;const m=Xs[g];if(bo(h*73856093^a*19349663^m.salt,u*83492791^(a+1)*2654435761,i)/eT<m.baseChance*_){n[f]=m.block;break}}}}}}const ua=2,nT={ocean:0,plains:45e-5,forest:.044,birch_forest:.08,taiga:.04,snowy_plains:2e-4,desert:0,mountains:.002},iT={ocean:null,plains:"oak",forest:"oak",birch_forest:"birch",taiga:"spruce",snowy_plains:"spruce",desert:null,mountains:"spruce"},rT={oak:O.LOG,spruce:O.SPRUCE_LOG,birch:O.BIRCH_LOG},sT={oak:O.LEAVES,spruce:O.SPRUCE_LEAVES,birch:O.BIRCH_LEAVES},oT=1597668381,aT=461845907,fa=4;function Mm(n){return iT[n]}function pu(n,e,t){return bo(n,e,t^oT)/4294967296}function mh(n,e,t,i){const r=xr(n,e,t);if(r<=$n+1)return!1;const s=tl(i,r);return s!==O.GRASS&&s!==O.SNOW?!1:pu(n,e,t)<nT[i]}function lT(n,e,t){const i=pr(n,e,t);if(Mm(i)===null||!mh(n,e,t,i))return!1;const r=pu(n,e,t);for(let s=-ua;s<=ua;s++)for(let o=-ua;o<=ua;o++){if(o===0&&s===0)continue;const a=n+o,l=e+s;if(pr(a,l,t)===i&&mh(a,l,t,i)&&pu(a,l,t)<r)return!1}return!0}const cT={oak:[4,6],birch:[5,7],spruce:[6,9]},gh=3,uT={oak:[{dy:-2,radius:2,skipCorners:!1},{dy:-1,radius:2,skipCorners:!1},{dy:0,radius:1,skipCorners:!0},{dy:1,radius:1,skipCorners:!0}],birch:[{dy:0,radius:2,skipCorners:!0},{dy:1,radius:2,skipCorners:!0},{dy:2,radius:1,skipCorners:!0}],spruce:[{dy:0,radius:2,skipCorners:!1},{dy:1,radius:1,skipCorners:!1},{dy:2,radius:2,skipCorners:!1},{dy:3,radius:1,skipCorners:!1},{dy:4,radius:0,skipCorners:!1}]};function fT(n,e){const[t,i]=cT[n],r=Number.isFinite(e)?Math.min(gh-1,Math.max(0,Math.floor(e))):0;return{trunkHeight:Math.min(i,t+Math.round(r*(i-t)/(gh-1))),leaves:uT[n].map(s=>({...s}))}}function dT(n,e,t,i){const r=e*j,s=t*j,o=(a,l,c,u)=>{if(a<0||a>=j||c<0||c>=j||l<0||l>=ht)return;const d=Rt(a,l,c);n[d]===O.AIR&&(n[d]=u)};for(let a=-fa;a<j+fa;a++)for(let l=-fa;l<j+fa;l++){const c=r+l,u=s+a;if(!lT(c,u,i))continue;const d=Mm(pr(c,u,i));if(d===null)continue;const f=bo(c,u,i^aT)%3,h=fT(d,f),g=xr(c,u,i),_=rT[d],m=sT[d];for(let E=1;E<=h.trunkHeight;E++)o(l,g+E,a,_);const p=g+h.trunkHeight;for(const E of h.leaves){const S=p+E.dy,y=E.radius;for(let C=-y;C<=y;C++)for(let R=-y;R<=y;R++)E.skipCorners&&Math.abs(C)===y&&Math.abs(R)===y||o(l+C,S,a+R,m)}}}const Em={ocean:0,plains:.0078,forest:.0078,birch_forest:.0117,taiga:.0039,snowy_plains:0,desert:0,mountains:.0039},hT={ocean:0,plains:.1,forest:.12,birch_forest:.12,taiga:.08,snowy_plains:0,desert:0,mountains:.05},pT=.0059,mT=790395453,gT=2007643084,_T=457006719,vT=1821250292,xT=1372833705,ST=4294967296,yT=-.24,_h=11/18,MT=5/18;function To(n,e,t,i){return bo(n,e,t^i)/ST}function bm(n,e,t){return To(n,e,t,mT)}function ET(n,e,t){return To(n,e,t,gT)<.5?"dandelion":"poppy"}function bT(n,e,t){return To(n,e,t,_T)}function AT(n,e,t){return To(n,e,t,vT)}function TT(n,e,t){const i=To(n,e,t,xT);return i<_h?1:i<_h+MT?2:3}function wT(n,e,t){return ym(n,e,t)<yT}function Am(n,e){return e<=$n?!1:tl(n,e)===O.GRASS}function RT(n,e,t,i,r){return!Am(i,r)||bm(n,e,t)>=Em[i]?null:ET(n,e,t)}function CT(n,e,t,i,r){return!Am(i,r)||bm(n,e,t)<Em[i]?!1:bT(n,e,t)<hT[i]}function PT(n,e,t,i,r){return i!=="desert"||r<=$n||tl(i,r)!==O.SAND||AT(n,e,t)>=pT?0:TT(n,e,t)}function IT(n,e,t,i){const r=e*j,s=t*j,o=(a,l,c,u)=>{if(a<0||a>=j||c<0||c>=j||l<0||l>=ht)return;const d=Rt(a,l,c);n[d]===O.AIR&&(n[d]=u)};for(let a=0;a<j;a++)for(let l=0;l<j;l++){const c=r+l,u=s+a,d=xr(c,u,i),f=pr(c,u,i),h=RT(c,u,i,f,d);h!==null?o(l,d+1,a,h==="dandelion"?O.DANDELION:O.POPPY):CT(c,u,i,f,d)&&o(l,d+1,a,O.SHORT_GRASS);const g=PT(c,u,i,f,d);if(g>0)for(let _=1;_<=g;_++)o(l,d+_,a,O.CACTUS);if(d<$n-1&&wT(c,u,i)){const _=Rt(l,$n,a);n[_]===O.WATER&&(n[_]=O.ICE)}}}const LT=$n+1,DT=92,NT=-.24,UT=-.12,OT=-.26,FT=.08,kT=-.08,BT=.2,zT=0,HT=112,VT=104;function GT(n){const{height:e,temp:t,moist:i}=n;return e<=LT?"ocean":e>=DT?"mountains":t<NT?"snowy_plains":t<UT&&i>OT?"taiga":t>FT&&i<kT?"desert":i>BT?"birch_forest":i>zT?"forest":"plains"}const WT={ocean:O.SAND,plains:O.GRASS,forest:O.GRASS,birch_forest:O.GRASS,taiga:O.GRASS,snowy_plains:O.SNOW,desert:O.SAND,mountains:O.GRASS};function tl(n,e){return n==="mountains"?e>=HT?O.SNOW:e>=VT?O.STONE:O.GRASS:WT[n]}const XT={ocean:O.SAND,plains:O.DIRT,forest:O.DIRT,birch_forest:O.DIRT,taiga:O.DIRT,snowy_plains:O.DIRT,desert:O.SAND,mountains:O.DIRT};function qT(n){return XT[n]}function Tm(n,e,t,i){return GT({height:i,temp:ym(n,e,t),moist:JA(n,e,t)})}function pr(n,e,t){return Tm(n,e,t,xr(n,e,t))}function mu(n,e,t){const i=new Uint8Array(j*j*ht),r=new to(t^1374496523),s=n*j,o=e*j;for(let a=0;a<j;a++)for(let l=0;l<j;l++){const c=s+l,u=o+a,d=xr(c,u,t),f=Tm(c,u,t,d);for(let h=0;h<ht;h++){let g=O.AIR;h===0?g=O.BEDROCK:h<d-4?g=O.STONE:h<d?g=qT(f):h===d?g=tl(f,d):h<=$n&&(g=O.WATER),h>3&&h<d-2&&g!==O.BEDROCK&&g!==O.WATER&&r.noise3(c*.05,h*.07,u*.05)>.62&&(g=O.AIR),i[Rt(l,h,a)]=g}}return tT(i,n,e,t),dT(i,n,e,t),IT(i,n,e,t),i}class wm{constructor(e,t=4){ke(this,"worker",null);ke(this,"nextId",1);ke(this,"inflight",new Map);ke(this,"queue",[]);ke(this,"failed",!1);ke(this,"maxConcurrent");ke(this,"deferred",new Map);this.seed=e,this.maxConcurrent=t;try{this.worker=new Worker(new URL(""+new URL("worker-DKytLE9P.js",import.meta.url).href,import.meta.url),{type:"module"}),this.worker.onmessage=i=>this.onResponse(i.data),this.worker.onerror=()=>this.degrade()}catch{this.degrade()}}degrade(){var e;this.failed=!0,(e=this.worker)==null||e.terminate(),this.worker=null,this.drainPendingSync()}drainPendingSync(){const e=[...this.queue,...this.inflight.values()];this.queue=[],this.inflight.clear();for(const t of e){const i=mu(t.cx,t.cz,this.seed).buffer,r={type:"gen",id:t.id,cx:t.cx,cz:t.cz,buffer:i};this.drainDeferred(r)}}onResponse(e){this.inflight.delete(e.id),this.drainDeferred(e),this.pump()}drainDeferred(e){const t=this.deferred.get(e.id)??[];this.deferred.delete(e.id);for(const i of t)i(e)}request(e,t){const i=this.nextId++;if(this.failed||!this.worker){const s=mu(e,t,this.seed).buffer;return Promise.resolve({type:"gen",id:i,cx:e,cz:t,buffer:s})}const r={id:i,cx:e,cz:t};return new Promise(s=>{this.deferred.set(i,[s]),this.queue.push(r),this.pump()})}pump(){if(this.worker)for(;this.inflight.size<this.maxConcurrent&&this.queue.length>0;){const e=this.queue.shift();this.inflight.set(e.id,e);const t={type:"gen",...e,seed:this.seed};this.worker.postMessage(t)}}dispose(){var e;this.failed=!0,this.drainPendingSync(),(e=this.worker)==null||e.terminate(),this.worker=null}}const gu=10,Rm={iron_ore:"iron_ingot",raw_iron:"iron_ingot",gold_ore:"gold_ingot",raw_gold:"gold_ingot",sand:"glass",raw_chicken:"cooked_chicken",raw_porkchop:"cooked_porkchop",raw_mutton:"cooked_mutton",raw_beef:"steak"},Ba={coal:8,oak_log:1.5,oak_planks:1.5,stick:.5,spruce_log:1.5,birch_log:1.5,spruce_planks:1.5,birch_planks:1.5};function Cm(){return{input:null,fuel:null,output:null,progressSec:0,fuelUnits:0}}const vh=n=>!!n&&Number.isFinite(n.count)&&n.count>=1;function YT(n,e){if(!Number.isFinite(e)||e<=0)return{state:n,completed:0};let t=vh(n.input)?{...n.input}:null,i=vh(n.fuel)?{...n.fuel}:null,r=n.output?{...n.output}:null,s=Number.isFinite(n.progressSec)?Math.max(0,n.progressSec):0,o=Number.isFinite(n.fuelUnits)?n.fuelUnits:0,a=0,l=e;for(;l>0;){const c=t?Rm[t.item]:void 0;if(!t||c===void 0||r&&(r.item!==c||r.count>=64))break;if(o<=0){if(!i||Ba[i.item]===void 0)break;const f=Ba[i.item];i=i.count>1?{item:i.item,count:i.count-1}:null,o+=f}const u=gu-s;if(u<=0){t=t.count>1?{item:t.item,count:t.count-1}:null,r=r?{item:r.item,count:r.count+1}:{item:c,count:1},o=Math.max(0,o-1),s=0,a+=1;continue}const d=Math.min(l,u);s+=d,l-=d,s>=gu&&(t=t.count>1?{item:t.item,count:t.count-1}:null,r=r?{item:r.item,count:r.count+1}:{item:c,count:1},o=Math.max(0,o-1),s=0,a+=1)}return{state:{input:t,fuel:i,output:r,progressSec:s,fuelUnits:o},completed:a}}const nl=2;function za(n){return n!==nl}function Pm(n){return typeof n=="number"&&Number.isFinite(n)?n:void 0}function Im({hasLocalSave:n,cloudApplied:e}){return e?"cloud":n?"local":"none"}function Lm(n=[],e="creative"){const t=n.map(r=>{if(!r)return null;const s=qn(r.item),o=s>0?lo(r.item,r.dur)??s:void 0;return{item:r.item,count:r.count,...o!==void 0?{dur:o}:{}}});let i=e;return{slots:t,get mode(){return i},setMode(r){i=r},addItem(r,s,o){if(i==="creative"||s<=0)return 0;const a=Hi(r),l=qn(r),c=l>0?lo(r,o)??l:void 0;let u=s;for(const d of t){if(u<=0)break;if(!d||d.item!==r||d.count>=a)continue;const f=Math.min(a-d.count,u);d.count+=f,u-=f}for(let d=0;d<t.length&&u>0;d++){if(t[d])continue;const f=Math.min(a,u);t[d]={item:r,count:f,...c!==void 0?{dur:c}:{}},u-=f}return u},removeItem(r,s){if(i==="creative"||s<=0)return 0;let o=s;for(let a=0;a<t.length&&o>0;a++){const l=t[a];if(!l||l.item!==r)continue;const c=Math.min(l.count,o);l.count-=c,o-=c,l.count===0&&(t[a]=null)}return s-o},countItem(r){let s=0;for(const o of t)o&&o.item===r&&(s+=o.count);return s},fits(r,s){if(s<=0)return!0;if(!Number.isFinite(s))return!1;const o=Hi(r);let a=0;for(const l of t)l?l.item===r&&l.count<o&&(a+=o-l.count):a+=o;return a>=s},setSlot(r,s){if(r<0||r>=t.length)return;if(!s||!(s.count>=1)){t[r]=null;return}const o=qn(s.item),a=o>0?lo(s.item,s.dur)??o:void 0;t[r]={item:s.item,count:Math.min(Math.floor(s.count),Hi(s.item)),...a!==void 0?{dur:a}:{}}},spendFromSlot(r,s){if(!Number.isInteger(s)||s<1)return!1;if(i==="creative")return!0;const o=t[r];return!o||o.count<s?!1:(o.count-=s,o.count===0&&(t[r]=null),!0)}}}function Sr(){return{hp:20,maxHp:20,hunger:20,maxHunger:20,saturation:5,regenAcc:0,starveAcc:0,exhaustion:0}}const ec=4,KT=.5,Dm=40,xh=4,Sh=4;function _u(n,e){return!Number.isFinite(e)||e<=0?{...n}:{...n,hp:Math.max(0,n.hp-e)}}function ZT(n,e,t){const i=Number.isFinite(e)&&e>0?e:0,r=Number.isFinite(t)&&t>0?t:0;return{...n,hunger:Math.max(0,Math.min(n.maxHunger,Math.floor(n.hunger+i))),saturation:Math.max(0,Math.min(n.maxHunger,n.saturation+r))}}const $T=.1,jT=.05,JT=.2,yh=.1,Nm=.1,QT=.005,e1=6;function Pi(n,e){if(!Number.isFinite(e)||e<=0)return{...n};let t=Math.min(Dm,n.exhaustion+e),i=n.saturation,r=n.hunger;for(;t>xh;)t-=xh,i>0?i=Math.max(0,i-1):r=Math.max(0,r-1);return{...n,exhaustion:t,saturation:i,hunger:r}}function t1(n,e){(!Number.isFinite(e)||e<=0)&&(e=0);let{hp:t,hunger:i,saturation:r,exhaustion:s,regenAcc:o,starveAcc:a}=n;if(t>0&&t<n.maxHp&&(i>=18||r>0)){for(o+=e;t<n.maxHp&&(i>=18||r>0);){const l=i>=n.maxHunger&&r>0?KT:ec;if(o<l)break;o-=l,t+=1;const c=Pi({...n,hp:t,hunger:i,saturation:r,exhaustion:s},e1);i=c.hunger,r=c.saturation,s=c.exhaustion}t>=n.maxHp&&(o=0)}else o=0;if(i===0&&r===0&&t>0){for(a+=e;a>=ec&&t>0;)t-=1,a-=ec;t<=0&&(a=0)}else a=0;return{...n,hp:t,hunger:i,saturation:r,exhaustion:s,regenAcc:o,starveAcc:a}}function n1(n){return n.hp<=0}function i1(n){return!Number.isFinite(n)||n<=0?0:Math.max(0,Math.floor(n-3))}const Mh=n=>typeof n=="number"&&Number.isFinite(n);function co(n){const e=typeof n=="object"&&n!==null?n:{},t=Sr(),i=(a,l,c)=>Mh(a)&&a>=l&&a<=c?a:null,r=(a,l,c,u)=>{const d=Mh(a)?a:u;return Math.min(c,Math.max(l,d))},s=i(e.maxHp,1,t.maxHp)??t.maxHp,o=i(e.maxHunger,1,t.maxHunger)??t.maxHunger;return{hp:r(e.hp,0,s,t.hp),maxHp:s,hunger:r(e.hunger,0,o,t.hunger),maxHunger:o,saturation:r(e.saturation,0,o,t.saturation),regenAcc:r(e.regenAcc,0,Sh,t.regenAcc),starveAcc:r(e.starveAcc,0,Sh,t.starveAcc),exhaustion:r(e.exhaustion,0,Dm,t.exhaustion)}}const tc=Oi("survival").length;function Um(){return{survival:Oi("survival"),creative:Oi("creative"),survivalVitals:Sr()}}function Om(n,e,t,i){const r=t.map(s=>s?{...s}:null);return e==="creative"?{survival:n.survival,creative:r,survivalVitals:n.survivalVitals}:{survival:r,creative:n.creative,survivalVitals:i?{...i}:n.survivalVitals}}function vu(n,e){return(e==="creative"?n.creative:n.survival).map(i=>i?{...i}:null)}function il(n,e){const t=typeof n=="object"&&n!==null?n:{};if("survival"in t||"creative"in t||"survivalVitals"in t)return{survival:"survival"in t?fi(t.survival,tc):Oi("survival"),creative:"creative"in t?fi(t.creative,tc):Oi("creative"),survivalVitals:co(t.survivalVitals)};const i=fi(e.inventory,tc);return{survival:e.mode==="survival"?i:Oi("survival"),creative:e.mode==="creative"?i:Oi("creative"),survivalVitals:e.mode==="survival"?co(e.vitals):co(void 0)}}function r1(){const n=new Map;return{on(e,t){let i=n.get(e);i||(i=new Set,n.set(e,i));const r=t;return i.add(r),()=>i.delete(r)},emit(e,t){const i=n.get(e);if(i)for(const r of[...i])try{r(t)}catch(s){console.error("[bus] listener error",e,s)}}}}const li=.3,Qu=1.8,s1=1.62,Eh=32,o1=9,a1=4.3,l1=5.6,c1=1.3,u1=10,f1=.5,d1=.05;function bh(n,e){const t=e==="x"?n.x:n.z;if(!Number.isFinite(t))return 0;const i=Math.min(1,Math.abs(t));return Math.asin(i)*180/Math.PI}function rl(n,e,t){return{position:{x:n,y:e,z:t},velocity:{x:0,y:0,z:0},yaw:0,pitch:0,onGround:!1,flying:!1,inWater:!1}}function h1(n,e,t,i){return!Number.isFinite(e)||!Number.isFinite(t)||!Number.isFinite(i)?!1:n.isSolid(Math.floor(e),Math.floor(t-.05),Math.floor(i))}function qs(n,e,t,i){const r=e-li,s=e+li,o=t,a=t+Qu,l=i-li,c=i+li;for(let u=Math.floor(r);u<=Math.floor(s-1e-9);u++)for(let d=Math.floor(o);d<=Math.floor(a-1e-9);d++)for(let f=Math.floor(l);f<=Math.floor(c-1e-9);f++)if(n.isSolid(u,d,f))return!0;return!1}function p1(n,e,t,i){if(!Number.isFinite(i))return{wallAngleDeg:null};const r=Math.max(1,Math.ceil(i/d1)),s=i/r;let o=null;for(let a=0;a<r;a++){const l=m1(n,e,t,s);l!==null&&(o===null||l>o)&&(o=l)}return{wallAngleDeg:o}}function m1(n,e,t,i){const r=t.getBlock(Math.floor(n.position.x),Math.floor(n.position.y+.1),Math.floor(n.position.z)),s=t.getBlock(Math.floor(n.position.x),Math.floor(n.position.y+1.6),Math.floor(n.position.z));n.inWater=r===O.WATER||s===O.WATER,e.fly&&!n.flying&&(n.flying=!0,n.velocity.y=0),!e.fly&&n.flying&&(n.flying=!1);const o=Number.isFinite(n.yaw),a=o?Math.sin(n.yaw):0,l=o?Math.cos(n.yaw):1;let c=e.strafe*l-e.fwd*a,u=-e.strafe*a-e.fwd*l;(!o||!Number.isFinite(c))&&(c=0),(!o||!Number.isFinite(u))&&(u=0);const d=Math.hypot(c,u);d>1&&(c/=d,u/=d);let f=a1;n.flying?f=u1:e.sneak?f=c1:e.sprint&&(f=l1),n.inWater&&!n.flying&&(f*=.5),n.flying?(n.velocity.x=c*f,n.velocity.z=u*f,n.velocity.y=(e.flyUp?1:0)*f+(e.flyDown?-1:0)*f):(n.velocity.x=c*f,n.velocity.z=u*f,n.inWater?(n.velocity.y-=Eh*f1*i,n.velocity.y*=.9,e.jump&&(n.velocity.y=4),n.velocity.y=Math.max(n.velocity.y,-4)):(n.velocity.y-=Eh*i,e.jump&&n.onGround&&(n.velocity.y=o1,n.onGround=!1)),n.velocity.y=Math.max(n.velocity.y,-50));const h=e.sneak&&n.onGround&&!n.flying&&!n.inWater,g=nc(n,t,"x",n.velocity.x*i,h),_=nc(n,t,"z",n.velocity.z*i,h);nc(n,t,"y",n.velocity.y*i);let m=null;if(g&&(m=bh({x:c,z:u},"x")),_){const p=bh({x:c,z:u},"z");m=m===null?p:Math.max(m,p)}return m}function nc(n,e,t,i,r=!1){if(i===0)return!1;const s=n.position;if(r&&t!=="y"){const l=t==="x"?s.x+i:s.x,c=t==="z"?s.z+i:s.z;if(!h1(e,l,s.y,c))return!1}if(s[t]+=i,!qs(e,s.x,s.y,s.z))return t==="y"&&(n.onGround=!1),!1;const o=Math.sign(i)*.01;let a=0;for(;qs(e,s.x,s.y,s.z)&&a++<500;)s[t]-=o;if(qs(e,s.x,s.y,s.z)||(s[t]+=o,qs(e,s.x,s.y,s.z)&&(s[t]-=o)),t==="y")if(n.velocity.y=0,i<0){n.onGround=!0;const l=s.y;s.y=Math.floor(s.y+1e-9),qs(e,s.x,s.y,s.z)&&(s.y=l)}else n.onGround=!1;else n.velocity[t]=0;return!0}const g1=.35,_1=6,v1=8;function Fm(){return{active:!1,latched:!1,ctrlHeld:!1,lastCancel:null}}function x1(n){return n!==null&&n>v1}function S1(n){return n.forward?n.sneak?"sneaking":n.flying?"flying":n.inWater?"in-water":n.hunger!==null&&n.hunger<=_1?"hunger":x1(n.wallAngleDeg)?"wall":n.attacked?"attacked":null:"no-forward"}function y1(n,e){const t=n.latched||e.sprintRequested,i=S1(e);return i!==null?{active:!1,latched:!1,ctrlHeld:e.ctrlHeld,lastCancel:i}:{active:t||e.ctrlHeld,latched:t,ctrlHeld:e.ctrlHeld,lastCancel:null}}function M1(n,e){const t=new Set,i={fwd:0,strafe:0,jump:!1,sneak:!1,sprint:!1,fly:!1,flyUp:!1,flyDown:!1,dig:!1,place:!1,placeHeld:!1,slot:0,toggleInventory:!1,toggleDebug:!1,toggleView:!1,requestPause:!1,dropRequest:!1,dropWholeStack:!1,dropHeld:!1,sprintToggle:!1};let r=!1,s=!1,o=Number.NEGATIVE_INFINITY,a=null,l=!1,c=null,u=[];const d=()=>{i.fwd=(t.has("KeyW")?1:0)-(t.has("KeyS")?1:0),i.strafe=(t.has("KeyD")?1:0)-(t.has("KeyA")?1:0),i.jump=t.has("Space"),i.sneak=t.has("ShiftLeft")||t.has("ShiftRight"),i.sprint=t.has("ControlLeft")||t.has("ControlRight"),i.flyUp=l&&t.has("Space"),i.flyDown=l&&i.sneak,i.fly=l},f=A=>{if((A.code==="F3"||A.code==="F5")&&A.preventDefault(),!!s){if(A.code==="Escape"){A.repeat||(i.requestPause=!0);return}if(A.code==="Space"&&!A.repeat&&r){const P=performance.now();P-o<300&&(l=!l),o=P}if(A.code.startsWith("Digit")){const P=Number(A.code.slice(5));P>=1&&P<=9&&(i.slot=P-1)}if(A.code==="KeyW"){const P=performance.now();!A.repeat&&a!==null&&(P-a)/1e3<=g1&&(i.sprintToggle=!0),a=P}A.code==="KeyQ"&&!A.repeat&&(i.dropRequest=!0,i.dropWholeStack=i.sprint,i.dropHeld=!0),A.code==="KeyE"&&!A.repeat&&(i.toggleInventory=!0),A.code==="F3"&&!A.repeat&&(i.toggleDebug=!0),A.code==="F5"&&!A.repeat&&(i.toggleView=!0),t.add(A.code),d()}},h=A=>{t.delete(A.code),d(),A.code==="KeyQ"&&(i.dropHeld=!1)},g=A=>{if(!s)return;const P=.0022*e.sensitivity;c==null||c(A.movementX*P,A.movementY*P)},_=A=>{s&&(A.button===0&&(i.dig=!0),A.button===2&&(i.place=!0,i.placeHeld=!0))},m=A=>{A.button===0&&(i.dig=!1),A.button===2&&(i.placeHeld=!1)},p=A=>{s&&(i.slot=(i.slot+(A.deltaY>0?1:-1)+9)%9)},E=A=>A.preventDefault(),S=()=>{t.clear(),i.dig=!1,i.place=!1,i.placeHeld=!1,i.toggleInventory=!1,i.toggleDebug=!1,i.toggleView=!1,i.requestPause=!1,i.dropRequest=!1,i.dropWholeStack=!1,i.dropHeld=!1,i.sprintToggle=!1,a=null,d()},y=()=>{s=document.pointerLockElement===n,s||S(),u==null||u.forEach(A=>A(s))},C=()=>S(),R=()=>{var A;if(!s){const P=(A=n.requestPointerLock)==null?void 0:A.call(n);P&&typeof P.catch=="function"&&P.catch(()=>{})}};return document.addEventListener("keydown",f),document.addEventListener("keyup",h),document.addEventListener("mousemove",g),n.addEventListener("mousedown",_),document.addEventListener("mouseup",m),n.addEventListener("wheel",p),n.addEventListener("contextmenu",E),document.addEventListener("pointerlockchange",y),n.addEventListener("click",R),window.addEventListener("blur",C),{state:i,get locked(){return s},onLockChange(A){u==null||u.push(A)},setMouseMoveHandler(A){c=A},consumePlace(){const A=i.place;return i.place=!1,A},consumeSprintToggle(){const A=i.sprintToggle;return i.sprintToggle=!1,A},consumeDrop(){if(!i.dropRequest)return null;const A={wholeStack:i.dropWholeStack};return i.dropRequest=!1,i.dropWholeStack=!1,A},consumeToggleInventory(){const A=i.toggleInventory;return i.toggleInventory=!1,A},consumeToggleDebug(){const A=i.toggleDebug;return i.toggleDebug=!1,A},consumeToggleView(){const A=i.toggleView;return i.toggleView=!1,A},consumeRequestPause(){const A=i.requestPause;return i.requestPause=!1,A},setFlyEnabled(A){r=A,!A&&(l=!1,d())},dispose(){document.removeEventListener("keydown",f),document.removeEventListener("keyup",h),document.removeEventListener("mousemove",g),n.removeEventListener("mousedown",_),document.removeEventListener("mouseup",m),n.removeEventListener("wheel",p),n.removeEventListener("contextmenu",E),document.removeEventListener("pointerlockchange",y),n.removeEventListener("click",R),window.removeEventListener("blur",C),document.pointerLockElement===n&&document.exitPointerLock(),c=null,u=null}}}const di=70,E1=.1,b1=.1;function A1(n=di){return Number.isFinite(n)?n*(1+E1):di}function T1(n,e,t){return!Number.isFinite(n)||!Number.isFinite(e)?di:!Number.isFinite(t)||t<=0?n:n+(e-n)*(1-Math.exp(-t/b1))}const da=["first","back","front"],xu=4,w1=.5;function R1(n){const e=da.indexOf(n);return e<0?da[0]:da[(e+1)%da.length]}function Ys(n){return Number.isFinite(n)?n:0}function C1(n,e,t,i){const r=Ys(e.x),s=Ys(e.y),o=Ys(e.z),a=Ys(t),l=Ys(i);if(n==="first")return{pos:{x:r,y:s,z:o},yaw:a,pitch:l};const c=-Math.sin(a),u=-Math.cos(a),d=n==="front",f=(d?c:-c)*xu,h=(d?u:-u)*xu;return{pos:{x:r+f,y:s+w1,z:o+h},yaw:d?a+Math.PI:a,pitch:l}}const P1=.5;function I1(){return{untilSec:Number.NEGATIVE_INFINITY}}function km(n,e){return e>=n.untilSec}function Bm(n,e){return Number.isFinite(e)?{untilSec:e+P1}:{...n}}const L1=1,D1=2;function Ps(){return{cactusAcc:0}}function N1(n,e,t,i){if(!Number.isFinite(e.x)||!Number.isFinite(e.y)||!Number.isFinite(e.z)||!Number.isFinite(t)||!Number.isFinite(i))return!1;const r=Math.floor(e.x-t),s=Math.floor(e.x+t-1e-9),o=Math.floor(e.z-t),a=Math.floor(e.z+t-1e-9),l=Math.floor(e.y-D1),c=Math.floor(e.y+i-1e-9);for(let u=l;u<=c;u++)for(let d=r;d<=s;d++)for(let f=o;f<=a;f++)if(n.getBlock(d,u,f)===O.CACTUS)return!0;return!1}function U1(n,e,t){const i=Number.isFinite(t)&&t>0?t:0;if(!e)return{state:Ps(),damage:0};const s=(Number.isFinite(n.cactusAcc)?n.cactusAcc:0)+i,o=Math.floor(s);return{state:{cactusAcc:s-o},damage:o*L1}}function sl(){return{apexY:null}}function O1(n,e,t,i,r,s){if(!Number.isFinite(e)||!Number.isFinite(t))return{fall:n,distance:null};if(r||s)return{fall:{apexY:null},distance:null};if(!i){const a=n.apexY;return{fall:{apexY:Math.max(a??e,e)},distance:null}}const o=n.apexY!==null?n.apexY-t:null;return{fall:{apexY:null},distance:o}}const F1=20,k1=.5,B1=2,Ah=2.5,z1=1.5,Th=.5,H1=1,V1=1.5,G1=300,W1=.01,X1=.1;function q1(n){return n===O.COAL_ORE?"coal":n===O.IRON_ORE?"raw_iron":n===O.GOLD_ORE?"raw_gold":n===O.DIAMOND_ORE?"diamond":n===O.STONE?"cobblestone":n===O.GRASS?"dirt":n===O.LEAVES||n===O.GLASS||n===O.SNOW||n===O.SPRUCE_LEAVES||n===O.BIRCH_LEAVES||n===O.ICE?null:vm(n)}const Y1=.005;function K1(n,e=Math.random){return n!==O.LEAVES&&n!==O.BIRCH_LEAVES?null:e()<Y1?"apple":null}function mr(n,e,t,i,r={}){let s=-1;for(const o of n)o.id>s&&(s=o.id);return[...n,{id:s+1,item:e,count:t,pos:{x:i.x,y:i.y,z:i.z},vel:r.vel?{x:r.vel.x,y:r.vel.y,z:r.vel.z}:{x:Math.random()*3-1.5,y:3,z:Math.random()*3-1.5},age:0,pickupDelay:r.pickupDelay??k1,bounced:!1,...r.dur!==void 0?{dur:r.dur}:{}}]}function Z1(n,e,t){const i=Number.isFinite(e)&&e>0?e:0,r=[];for(const s of n){const o=s.age+i;if(o>=G1)continue;const a={x:s.pos.x,y:s.pos.y,z:s.pos.z},l={x:s.vel.x,y:s.vel.y,z:s.vel.z};let c=s.bounced;l.y-=F1*i;const u=a.y;a.x+=l.x*i,a.y+=l.y*i,a.z+=l.z*i;const d=Math.pow(X1,i);if(l.x*=d,l.z*=d,l.y<0){const f=Math.floor(u),h=Math.floor(a.y),g=Math.floor(a.x),_=Math.floor(a.z);for(let m=f;m>=h;m--)if(t(g,m,_)){a.y=m+1+W1,!c&&l.y<-3?(l.y=-l.y*.3,c=!0):l.y=0;break}}r.push({...s,pos:a,vel:l,age:o,pickupDelay:Math.max(0,s.pickupDelay-i),bounced:c})}return r}function $1(n,e,t=V1){const i=t*t,r=[];return n.forEach((s,o)=>{if(s.pickupDelay>0)return;const a=s.pos.x-e.x,l=s.pos.y-e.y,c=s.pos.z-e.z;a*a+l*l+c*c<=i&&r.push(o)}),r}function j1(n,e,t){const i=e>=0&&e<n.length?n[e]:void 0;if(!i)return{drops:[...n],overflow:0};const r=t.addItem(i.item,i.count,i.dur);return r>=i.count?{drops:[...n],overflow:i.count}:r<=0?{drops:n.filter((s,o)=>o!==e),overflow:0}:{drops:n.map((s,o)=>o===e?{...s,count:r}:s),overflow:r}}function wh(n,e,t,i,r,s=Math.random){if(e==="creative"||!Hm(t,r))return n;const o=K1(t,s),a=o?mr(n,o,1,i):n,l=q1(t);return l?mr(a,l,1,i):a}const zm={wooden_pickaxe:{kind:"pickaxe",level:0,speed:2},stone_pickaxe:{kind:"pickaxe",level:1,speed:4},iron_pickaxe:{kind:"pickaxe",level:2,speed:6},golden_pickaxe:{kind:"pickaxe",level:0,speed:12},diamond_pickaxe:{kind:"pickaxe",level:3,speed:8},wooden_axe:{kind:"axe",level:0,speed:2},stone_axe:{kind:"axe",level:1,speed:4},iron_axe:{kind:"axe",level:2,speed:6},golden_axe:{kind:"axe",level:0,speed:12},diamond_axe:{kind:"axe",level:3,speed:8},wooden_shovel:{kind:"shovel",level:0,speed:2},stone_shovel:{kind:"shovel",level:1,speed:4},iron_shovel:{kind:"shovel",level:2,speed:6},golden_shovel:{kind:"shovel",level:0,speed:12},diamond_shovel:{kind:"shovel",level:3,speed:8}};function Hm(n,e){const t=en(n).requiredTool;if(t===null)return!0;const i=e?zm[e.item]:void 0;return i!==void 0&&i.kind===t.kind&&i.level>=t.level}function J1(n,e){var s;const t=en(n);if(!Number.isFinite(t.hardness))return 1;const i=((s=t.requiredTool)==null?void 0:s.kind)??t.fastTool,r=e?zm[e.item]:void 0;return r&&i&&r.kind===i?r.speed:1}function Vm(n,e){const t=en(n).hardness;return Number.isFinite(t)?t===0?0:t*(Hm(n,e)?1.5:5)/J1(n,e):1/0}const Q1={wooden_pickaxe:2,stone_pickaxe:3,iron_pickaxe:4,golden_pickaxe:2,diamond_pickaxe:5,wooden_axe:7,stone_axe:9,iron_axe:9,golden_axe:7,diamond_axe:9,wooden_shovel:2.5,stone_shovel:3.5,iron_shovel:4.5,golden_shovel:2.5,diamond_shovel:5.5,wooden_sword:4,stone_sword:5,iron_sword:6,golden_sword:4,diamond_sword:7};function ew(n){if(!n)return 1;const e=Q1[n];return e===void 0?1:e}const ha=.35,tw=1.8;function Gm(n,e,t,i){if(!Number.isFinite(i)||i<=0||![e.x,e.y,e.z,t.x,t.y,t.z].every(Number.isFinite))return null;const r=Math.hypot(t.x,t.y,t.z);if(r===0)return null;const s={x:t.x/r,y:t.y/r,z:t.z/r};let o=1/0,a=null;for(const l of n){if(![l.pos.x,l.pos.y,l.pos.z].every(Number.isFinite))continue;const c=um(e,s,{x:l.pos.x-ha,y:l.pos.y,z:l.pos.z-ha},{x:l.pos.x+ha,y:l.pos.y+tw,z:l.pos.z+ha});c===null||c>i||c<o&&(o=c,a=l.id)}return a}function nw(n,e,t,i,r,s){const o=Gm(n,e,t,i);if(o===null)return{mobs:n,hitId:null};let a=!1;return{mobs:n.map(c=>a||c.id!==o?c:(a=!0,db(c,r,s))),hitId:o}}class iw{constructor(){ke(this,"key","");ke(this,"progress",0)}update(e,t,i,r){const s=`${t.x},${t.y},${t.z},${e}`;s!==this.key&&(this.key=s,this.progress=0),Number.isFinite(r)&&(r<=0||(this.progress=Math.min(1,this.progress+i/r)))}isDone(e,t){return Number.isFinite(t)&&this.progress>=1&&this.key.endsWith(`,${e}`)}reset(){this.key="",this.progress=0}}function rw(n,e,t,i,r,s){const o=Vm(t,s);return Number.isFinite(o)?o===0||n==="creative"?(e.reset(),!0):(e.update(t,i,r,o),e.isDone(t,o)):!1}function sw(n){return Math.abs(n.nx)+Math.abs(n.ny)+Math.abs(n.nz)!==1?{x:n.x,y:n.y,z:n.z}:{x:n.x+n.nx,y:n.y+n.ny,z:n.z+n.nz}}function Wm(n){return n===O.AIR||n===O.WATER||Vp(n)}function ow(n,e){return Wm(e)?{x:n.x,y:n.y,z:n.z}:sw(n)}function aw(n,e,t,i,r){if(t<0||t>=ht)return!1;const s=n.getBlock(e,t,i);if(!Wm(s))return!1;const o=r.x-li,a=r.x+li,l=r.y,c=r.y+Qu,u=r.z-li,d=r.z+li;return!(a>e&&o<e+1&&c>t&&l<t+1&&d>i&&u<i+1)}function lw(n,e,t,i){return t<0||t>=ht||n.getBlock(e,t,i)!==O.AIR?!1:Gs(n,e,t-1,i)?!0:Gs(n,e+1,t,i)||Gs(n,e-1,t,i)||Gs(n,e,t,i+1)||Gs(n,e,t,i-1)}function cw(n,e,t,i,r,s){return s===O.TORCH?lw(n,e,t,i):aw(n,e,t,i,r)}const ef={food:4,saturation:2.4},Rh={apple:ef,raw_chicken:{food:2,saturation:1.2},cooked_chicken:{food:6,saturation:7.2},raw_porkchop:{food:3,saturation:1.8},cooked_porkchop:{food:8,saturation:12.8},raw_mutton:{food:2,saturation:1.2},cooked_mutton:{food:6,saturation:9.6},raw_beef:{food:3,saturation:1.8},steak:{food:8,saturation:12.8},rotten_flesh:{food:4,saturation:.8}};ef.food;ef.saturation;const Xm=1.6;function ol(n){return Object.prototype.hasOwnProperty.call(Rh,n)?Rh[n]??null:null}function uw(n,e){return ol(e)?n.hunger<n.maxHunger:!1}function fw(n,e){const t=n[e];if(!t||!ol(t.item))return{slots:n,ate:!1};const i=n.slice();return i[e]=t.count-1>=1?{item:t.item,count:t.count-1}:null,{slots:i,ate:!0}}class dw{constructor(){ke(this,"elapsed",0);ke(this,"item",null)}reset(){this.elapsed=0,this.item=null}update(e,t,i){if(!i||t===null)return this.reset(),"idle";this.item!==t&&(this.item=t,this.elapsed=0);const r=Number.isFinite(e)&&e>0?e:0;return this.elapsed+=r,this.elapsed>=Xm?(this.elapsed=0,"eaten"):"eating"}}function hw(n,e){return e.held?n.update(e.dtSec,e.item,e.allowed):(n.reset(),"idle")}const pw=.2,mw=.2;function qm(){return{acc:0}}function Ch(n,e,t,i){if(!e)return{state:{acc:0},fired:!1};const r=Number.isFinite(t)&&t>0?t:0,s=n.acc+r;return s>=i?{state:{acc:s-i},fired:!0}:{state:{acc:s},fired:!1}}function gw(n,e,t){if(t==="creative"||!n)return 0;const i=Math.floor(n.count);return!Number.isFinite(i)||i<1?0:e?i:1}function _w(n,e=Math.random){const t=(s,o)=>s+Math.floor(e()*(o-s+1)),i=[],r=(s,o)=>{o>0&&i.push({item:s,count:o})};switch(n){case"zombie":r("rotten_flesh",t(0,2));break;case"skeleton":r("bone",t(0,2)),r("arrow",t(0,2));break;case"chicken":r("raw_chicken",1),r("feather",t(0,2));break;case"pig":r("raw_porkchop",t(1,3));break;case"sheep":r("raw_mutton",t(1,2)),r("wool",1);break;case"cow":r("raw_beef",t(1,3)),r("leather",t(0,2));break}return i}function Ym(n,e=Math.random){const t=[];for(const i of n)for(const r of _w(i.kind,e))t.push({item:r.item,count:r.count,pos:{x:i.pos.x,y:i.pos.y+.9,z:i.pos.z}});return t}const Ks=n=>typeof n=="number"&&Number.isFinite(n);function vw(n){return typeof n=="string"&&Object.prototype.hasOwnProperty.call(Cs,n)}function Km(n){return n.map(e=>({kind:e.kind,x:e.pos.x,y:e.pos.y,z:e.pos.z,hp:e.hp,yaw:e.yaw}))}function Zm(n){if(typeof n!="object"||n===null)return null;const e=n;if(!vw(e.kind))return null;const{x:t,y:i,z:r}=e;if(!Ks(t)||!Ks(i)||!Ks(r))return null;const s=e.hp;return!Ks(s)||s<=0?null:{kind:e.kind,x:t,y:i,z:r,hp:Math.min(Cs[e.kind].hp,s),yaw:Ks(e.yaw)?e.yaw:0}}function tf(n){if(!Array.isArray(n))return[];const e=[];for(const t of n){if(e.length>=Oa)break;const i=Zm(t);i&&e.push(i)}return e}function $m(n,e){return e?[]:tf(n)}function jm(n){const e=[];for(const t of n){if(e.length>=Oa)break;const i=Zm(t);if(!i)continue;const r=dm(i.kind,{x:i.x,y:i.y,z:i.z});e.push({...r,hp:i.hp,yaw:i.yaw,vel:{x:0,y:0,z:0},kbVel:{x:0,z:0}})}return e}const un=32;let Ph=null;function yr(n){if(Ph===!1)return null;let e=null;try{e=n.getContext("2d")}catch{e=null}return Ph=!!e,e}let ic=null;function xw(){return ic||(ic=Zu()),ic}const Ih=new Map;function Mr(n){const e=Ih.get(n);if(e)return e;const t=document.createElement("canvas");t.width=un,t.height=un;const i=yr(t);if(!i)return t;const r=Ju(n);return r!==null?Sw(i,r):Aw(i,n),Ih.set(n,t),t}function Sw(n,e){const t=en(e),i=xw(),r=t.side%_s,s=Math.floor(t.side/_s),o=n.createImageData(tt,tt);for(let c=0;c<tt;c++)for(let u=0;u<tt;u++){const d=((s*tt+c)*Ui+r*tt+u)*4,f=(c*tt+u)*4;o.data[f]=i.data[d],o.data[f+1]=i.data[d+1],o.data[f+2]=i.data[d+2],o.data[f+3]=i.data[d+3]}const a=document.createElement("canvas");a.width=tt,a.height=tt;const l=yr(a);l&&(l.putImageData(o,0,0),n.imageSmoothingEnabled=!1,n.drawImage(a,0,0,un,un))}const er="#8a5a2b",yw="#b8945f",Mw="#9a9a9a",Ew="#7f8fa1",bw={wooden:{head:yw,edge:"#d8d8d8"},stone:{head:Mw,edge:"#c6c6c6"},iron:{head:Ew,edge:"#b9c6d4"},golden:{head:"#f0c83c",edge:"#ffe89a"},diamond:{head:"#78dce8",edge:"#bff2f7"}};function pa(n){return bw[n.slice(0,n.indexOf("_"))]}function pn(n,e,t,i,r,s,o){n.strokeStyle=s,n.lineWidth=o,n.lineCap="round",n.beginPath(),n.moveTo(e,t),n.lineTo(i,r),n.stroke()}function Zs(n,e){const t=e;n.beginPath(),n.moveTo(8-t,18-t),n.quadraticCurveTo(6-t,10-t,14-t,7-t),n.quadraticCurveTo(24-t,5-t,26-t,13-t),n.quadraticCurveTo(28-t,21-t,20-t,24-t),n.quadraticCurveTo(11-t,26-t,8-t,18-t),n.closePath()}function Aw(n,e){switch(e){case"stick":{pn(n,9,23,23,9,er,4);break}case"coal":{n.fillStyle="#333333",n.beginPath(),n.arc(16,17,9,0,Math.PI*2),n.fill(),n.fillStyle="#5f5f5f",n.beginPath(),n.arc(12,13,2.5,0,Math.PI*2),n.fill();break}case"iron_ingot":{n.fillStyle="#d8d8d8",n.beginPath(),n.moveTo(10,12),n.lineTo(22,12),n.lineTo(27,22),n.lineTo(5,22),n.closePath(),n.fill(),n.fillStyle="#f2f2f2",n.fillRect(10,12,12,3);break}case"raw_iron":{n.fillStyle="#d8b28e",n.beginPath(),n.arc(13,14,5,0,Math.PI*2),n.fill(),n.beginPath(),n.arc(20,12,4,0,Math.PI*2),n.fill(),n.fillStyle="#c4915f",n.beginPath(),n.arc(19,20,4,0,Math.PI*2),n.fill();break}case"gravel":{n.fillStyle="#9a968e",n.fillRect(4,10,24,16),n.fillStyle="#6f6b64",n.fillRect(7,13,4,4),n.fillRect(16,11,3,3),n.fillRect(21,19,4,4),n.fillRect(11,20,3,3);break}case"raw_gold":{n.fillStyle="#f0c83c",n.beginPath(),n.arc(13,14,5,0,Math.PI*2),n.fill(),n.beginPath(),n.arc(20,12,4,0,Math.PI*2),n.fill(),n.fillStyle="#c99a1e",n.beginPath(),n.arc(19,20,4,0,Math.PI*2),n.fill();break}case"gold_ingot":{n.fillStyle="#f7d774",n.beginPath(),n.moveTo(10,12),n.lineTo(22,12),n.lineTo(27,22),n.lineTo(5,22),n.closePath(),n.fill(),n.fillStyle="#c99a1e",n.fillRect(5,19,22,3),n.fillStyle="#ffe89a",n.fillRect(10,12,12,3);break}case"diamond":{n.fillStyle="#78dce8",n.beginPath(),n.moveTo(16,4),n.lineTo(27,14),n.lineTo(16,28),n.lineTo(5,14),n.closePath(),n.fill(),n.strokeStyle="#3f9aa6",n.lineWidth=2,n.stroke(),n.fillStyle="#bff2f7",n.beginPath(),n.moveTo(16,7),n.lineTo(22,13),n.lineTo(16,13),n.closePath(),n.fill();break}case"apple":{n.fillStyle="#d43b3b",n.beginPath(),n.arc(16,18,9,0,Math.PI*2),n.fill(),pn(n,16,10,18,6,"#6b4a1f",2),n.fillStyle="#3f9b4f",n.fillRect(19,5,5,3);break}case"arrow":{pn(n,8,24,22,10,er,3),n.fillStyle="#c9c9c9",n.beginPath(),n.moveTo(27,5),n.lineTo(19,11),n.lineTo(23,15),n.closePath(),n.fill(),pn(n,5,21,11,27,"#e8e8e8",2);break}case"chest":{n.fillStyle="#a5713d",n.fillRect(4,8,24,18),n.strokeStyle="#6b4a1f",n.lineWidth=2,n.strokeRect(5,9,22,16),pn(n,5,15,27,15,"#6b4a1f",2),n.fillStyle="#d8d8d8",n.fillRect(14,13,4,6);break}case"wooden_pickaxe":case"stone_pickaxe":case"iron_pickaxe":case"golden_pickaxe":case"diamond_pickaxe":{const{head:t}=pa(e);pn(n,10,26,20,10,er,3),n.strokeStyle=t,n.lineWidth=5,n.lineCap="round",n.beginPath(),n.moveTo(6,12),n.quadraticCurveTo(16,3,26,12),n.stroke();break}case"wooden_axe":case"stone_axe":case"iron_axe":case"golden_axe":case"diamond_axe":{const{head:t}=pa(e);pn(n,10,26,19,11,er,3),n.fillStyle=t,n.beginPath(),n.moveTo(17,5),n.lineTo(27,9),n.lineTo(23,18),n.lineTo(16,13),n.closePath(),n.fill();break}case"wooden_shovel":case"stone_shovel":case"iron_shovel":case"golden_shovel":case"diamond_shovel":{const{head:t}=pa(e);pn(n,10,26,16,10,er,3),n.fillStyle=t,n.beginPath(),n.moveTo(12,10),n.lineTo(21,6),n.lineTo(24,12),n.lineTo(15,16),n.closePath(),n.fill();break}case"wooden_sword":case"stone_sword":case"iron_sword":case"golden_sword":case"diamond_sword":{const{head:t,edge:i}=pa(e),r=e.startsWith("wooden")?i:t;pn(n,22,8,12,18,r,4),pn(n,9,15,15,21,er,3),pn(n,12,18,8,22,er,3);break}case"raw_chicken":case"cooked_chicken":{n.fillStyle=e==="raw_chicken"?"#e8a0a0":"#d9a05b",Zs(n,0),n.fill(),n.fillStyle=e==="raw_chicken"?"#f4c4c4":"#e8bd85",n.beginPath(),n.arc(14,13,3,0,Math.PI*2),n.fill();break}case"raw_porkchop":case"cooked_porkchop":{n.fillStyle="#f7f2ec",Zs(n,2),n.fill(),n.fillStyle=e==="raw_porkchop"?"#f0a8b0":"#c98a5c",Zs(n,0),n.fill(),n.fillStyle=e==="raw_porkchop"?"#f8ccd2":"#dda57a",n.beginPath(),n.arc(14,13,3,0,Math.PI*2),n.fill();break}case"raw_mutton":case"cooked_mutton":{n.fillStyle=e==="raw_mutton"?"#e39a9a":"#b9793f",Zs(n,0),n.fill(),n.fillStyle=e==="raw_mutton"?"#f0bcbc":"#cf9463",n.beginPath(),n.arc(14,13,3,0,Math.PI*2),n.fill();break}case"raw_beef":case"steak":{n.fillStyle=e==="raw_beef"?"#c05a5a":"#8a4a2c",Zs(n,0),n.fill(),n.fillStyle=e==="raw_beef"?"#d58080":"#a8683f",n.beginPath(),n.arc(14,13,3,0,Math.PI*2),n.fill(),e==="steak"&&(n.fillStyle="#f0e6d2",n.fillRect(9,17,12,2),n.fillRect(12,21,9,2));break}case"leather":{n.fillStyle="#9a6b3f",n.fillRect(5,6,22,20),n.strokeStyle="#6b4a2f",n.lineWidth=2,n.setLineDash([2,2]),n.strokeRect(7,8,18,16),n.setLineDash([]);break}case"feather":{n.fillStyle="#f2f2f2",n.beginPath(),n.moveTo(9,24),n.quadraticCurveTo(6,12,20,5),n.quadraticCurveTo(24,15,12,25),n.closePath(),n.fill(),pn(n,9,25,21,5,"#c9c9c9",2);break}case"rotten_flesh":{n.fillStyle="#6f7a4a",n.beginPath(),n.arc(15,16,9,0,Math.PI*2),n.fill(),n.fillStyle="#4d5a33",n.beginPath(),n.arc(12,13,2.5,0,Math.PI*2),n.fill(),n.beginPath(),n.arc(18,18,2,0,Math.PI*2),n.fill(),n.beginPath(),n.arc(15,21,1.5,0,Math.PI*2),n.fill();break}case"bone":{n.fillStyle="#efe9d8",n.beginPath(),n.arc(9,21,4,0,Math.PI*2),n.fill(),n.beginPath(),n.arc(23,11,4,0,Math.PI*2),n.fill(),pn(n,9,21,23,11,"#efe9d8",5);break}default:{n.fillStyle="#7a7a7a",n.fillRect(8,8,16,16);break}}}const $s={green:"#00ff00",yellow:"#ffff00",orange:"#ff8000",red:"#ff0000"};function Tw(n){return!n||!pm(n.item)?0:mm(n)/qn(n.item)}function ww(n){return Number.isFinite(n)?n>.5?$s.green:n>.25?$s.yellow:n>.1?$s.orange:$s.red:$s.red}function Ha(n,e){var o;if((o=n.querySelector(".ui-dur"))==null||o.remove(),!e||!pm(e.item))return;const t=Tw(e);if(t>=1)return;const i=document.createElement("div");i.className="ui-dur";const r=document.createElement("span");r.className="ui-dur-fill",r.style.width=`${Math.round(t*100)}%`;const s=ww(t);r.style.backgroundColor=s,r.dataset.durColor=s,i.appendChild(r),n.appendChild(i)}function Rw(n){return[`WeCraft (dev)  ${n.fps} fps`,`XYZ: ${n.x.toFixed(2)} / ${n.y.toFixed(2)} / ${n.z.toFixed(2)}`,`Block: ${Math.floor(n.x)} ${Math.floor(n.y)} ${Math.floor(n.z)}`,`Chunks: ${n.chunks}`,`Seed: ${n.seed}`,`Biome: ${n.biome}`,`Triangles: ${n.triangles}`,`Mode: ${n.mode}${n.flying?" (flying)":""}`]}function Cw(n){const e=document.createElement("div");e.className="ui-crosshair";const t=document.createElement("div");t.className="ui-hotbar";const i=[];for(let u=0;u<9;u++){const d=document.createElement("div");d.className="ui-slot";const f=document.createElement("span");f.className="num",f.textContent=String(u+1);const h=document.createElement("canvas"),g=document.createElement("span");g.className="count",d.append(f,h,g),t.appendChild(d),i.push(d)}const r=document.createElement("div");r.className="ui-item-name";const s=document.createElement("div");s.className="ui-debug",s.style.display="none",n.append(e,t,r,s);const o=new Array(9).fill(null);let a=null;const l=(u,d)=>!u||!d?!u&&!d:u.item===d.item&&u.count===d.count&&(u.dur??null)===(d.dur??null),c=(u,d)=>{const f=yr(u);f&&(u.width=un,u.height=un,d&&(f.imageSmoothingEnabled=!1,f.drawImage(Mr(d.item),0,0)))};return{root:n,setHotbar(u,d){for(let f=0;f<i.length;f++){const h=i[f],g=u[f]??null;if(h.classList.toggle("selected",f===d),l(o[f],g))continue;o[f]=g?{...g}:null;const _=h.querySelector("canvas");_&&c(_,g);const m=h.querySelector(".count");m&&(m.textContent=g&&g.count>1?String(g.count):""),Ha(h,g)}},setSelected(u){i.forEach((d,f)=>d.classList.toggle("selected",f===u))},setDebug(u){const d=u?u.join(`
`):null;if(d!==a){if(a=d,d===null){s.style.display="none",s.textContent="";return}s.style.display="block",s.textContent=d}},showItemName(u){r.textContent=u??""},dispose(){e.remove(),t.remove(),r.remove(),s.remove()}}}const Lh=10,Su=8,Pw=Su/2,Iw="#e02020",Lw="#3f3f3f",Dw="#c87830",Nw="#3f3f3f",Uw={row:"hearts",icon:"heart",fill:Iw,empty:Lw,grid:[".##..##.","########","########","########",".######.","..####..","...##...","........"]},Ow={row:"hunger",icon:"hunger-icon",fill:Dw,empty:Nw,grid:["..####..",".######.","########","########","#######.","####....","##......","#......."]};function Fw(n,e){return n>=e*2+2?"full":n>=e*2+1?"half":"empty"}function kw(n,e){const t=[];for(let i=0;i<n.grid.length;i++)for(let r=0;r<n.grid[i].length;r++){if(n.grid[i][r]!=="#")continue;const s=e==="full"||e==="half"&&r<Pw?n.fill:n.empty;t.push(`<rect x="${r}" y="${i}" width="1" height="1" fill="${s}"/>`)}return`<svg class="${n.icon} ${e}" viewBox="0 0 ${Su} ${Su}" shape-rendering="crispEdges" aria-hidden="true">${t.join("")}</svg>`}function Dh(n,e){const t=Number.isFinite(e)?Math.max(0,Math.min(e,Lh*2)):0,i=document.createElement("div");i.className=n.row;let r="";for(let s=0;s<Lh;s++)r+=kw(n,Fw(t,s));return i.innerHTML=r,i}function Nh(n,e){if(!e){n.replaceChildren();return}n.replaceChildren(Dh(Uw,e.hp),Dh(Ow,e.hunger))}const kn=Object.freeze({seed:1337,renderDistance:10,sensitivity:1,volume:.8,mode:"survival",dayLengthSec:La,shadows:!0,clouds:!0}),Jm="wecraft.settings",js=(n,e)=>typeof n=="number"&&Number.isFinite(n)?n:e;function nf(n){const e=js(n.seed,kn.seed);return{seed:Math.floor(e)||0,renderDistance:Math.min(16,Math.max(6,Math.round(js(n.renderDistance,kn.renderDistance)))),sensitivity:Math.min(3,Math.max(.1,js(n.sensitivity,kn.sensitivity))),volume:Math.min(1,Math.max(0,js(n.volume,kn.volume))),mode:n.mode==="creative"?"creative":"survival",dayLengthSec:Math.min(Zp,Math.max(Kp,js(n.dayLengthSec,La))),shadows:typeof n.shadows=="boolean"?n.shadows:kn.shadows,clouds:typeof n.clouds=="boolean"?n.clouds:kn.clouds}}function Gn(){try{const n=localStorage.getItem(Jm);if(!n)return{...kn};const e=JSON.parse(n);return nf({...kn,...e})}catch{return{...kn}}}function Gi(n){const e=nf({...Gn(),...n});try{localStorage.setItem(Jm,JSON.stringify(e))}catch(t){console.warn("Failed to persist settings",t)}return e}function Uh(){const n=document.getElementById("game-canvas");if(!(!n||typeof n.requestPointerLock!="function"))try{const e=n.requestPointerLock();e&&typeof e.catch=="function"&&e.catch(()=>{})}catch{}}function rc(n,e,t){const i=document.createElement("div");i.className="row";const r=document.createElement("label");r.textContent=n;const s=document.createElement("input");return s.type="range",s.min=String(e.min),s.max=String(e.max),s.step=String(e.step),s.value=String(e.value),s.addEventListener("change",()=>t(Number(s.value))),i.append(r,s),i}function Bw(n){let e=null,t=null;const i=()=>{t&&(document.removeEventListener("keydown",t),t=null)},r=()=>{i(),e==null||e.remove(),e=null},s=(f,h)=>{const g=document.createElement("button");return g.className="ui-btn interactive",g.textContent=f,g.addEventListener("click",h),g},o=f=>{e=f,n.appendChild(f)},a=f=>{const h=document.createElement("div");h.className="ui-overlay interactive";const g=document.createElement("div");g.className="ui-logo",g.style.fontSize="36px",g.textContent="設定";const _=document.createElement("div");_.className="ui-settings";const m=Gn();return _.append(rc("視距",{min:6,max:16,step:1,value:m.renderDistance},p=>Gi({renderDistance:p})),rc("靈敏度",{min:.1,max:3,step:.1,value:m.sensitivity},p=>Gi({sensitivity:p})),rc("音量",{min:0,max:1,step:.05,value:m.volume},p=>Gi({volume:p})),s("返回",f)),h.append(g,_),h},l=()=>Gn().mode==="creative"?"Creative":"Survival",c=()=>Gn().shadows?"開":"關",u=()=>Gn().clouds?"開":"關",d=f=>{const h=document.createElement("div");return h.className=f,h.textContent=`Mode: ${l()}`,h};return{showTitle({saveState:f,statusText:h,onContinue:g,onNewGame:_}){r();const m=document.createElement("div");m.className="ui-overlay title-screen interactive";const p=document.createElement("div");if(p.className="ui-logo",p.textContent="WeCraft",m.append(p),f==="yes"||f==="pending"){const E=s("繼續遊戲",g);f==="pending"&&(E.disabled=!0),m.append(E)}if(m.append(s("單人遊戲",_),d("ui-mode")),h){const E=document.createElement("div");E.className="ui-mode",E.textContent=h,m.append(E)}o(m)},showConfirm({message:f,onConfirm:h,onCancel:g}){r();const _=document.createElement("div");_.className="ui-overlay interactive";const m=document.createElement("div");m.className="ui-settings ui-confirm";const p=document.createElement("div");p.className="ui-confirm-msg",p.textContent=f;let E=!1;const S=y=>{E||(E=!0,r(),y())};m.append(p,s("確定",()=>S(h)),s("取消",()=>S(g))),_.append(m),o(_),i(),t=y=>{y.code==="Escape"&&S(g)},document.addEventListener("keydown",t)},showConflictChoice({message:f,onKeepLocal:h,onTakeCloud:g,onMerge:_}){r();const m=document.createElement("div");m.className="ui-overlay interactive";const p=document.createElement("div");p.className="ui-settings ui-confirm";const E=document.createElement("div");E.className="ui-confirm-msg",E.textContent=f;let S=!1;const y=C=>{S||(S=!0,r(),C())};p.append(E,s("保留本機",()=>y(h)),s("採用雲端",()=>y(g)),s("合併",()=>y(_))),m.append(p),o(m),i(),t=C=>{C.code==="Escape"&&y(h)},document.addEventListener("keydown",t)},showPause({onResume:f,onQuit:h,onSaveQuit:g,onToggleMode:_,onToggleShadows:m,onToggleClouds:p,cloudStatus:E,cloudRetryable:S,onRetryCloud:y}){r();const C=()=>{i(),t=P=>{P.code==="Escape"&&(f(),Uh())},document.addEventListener("keydown",t)},R=()=>{const P=document.createElement("div");P.className="ui-cloud-row";const x=document.createElement("div");x.className="ui-cloud";let v=!1;switch(E){case"guest":x.textContent="雲端：訪客本機遊玩",x.classList.add("ui-cloud-guest");break;case"unsupported":case"unknown":x.textContent="雲端：不支援";break;case"ready":x.textContent="雲端：已同步";break;case"syncing":x.textContent="雲端：尚未同步",v=S;break;case"conflict":x.textContent="雲端：有新進度",v=S;break;case"format":x.textContent="雲端：格式不相容";break;case"error":default:x.textContent=S?"雲端：同步失敗（重試）":"雲端：同步失敗",v=S;break}if(P.append(x),v){const w=document.createElement("button");w.className="ui-btn ui-cloud-retry interactive",w.textContent="重試",w.addEventListener("click",y),P.append(w)}return P},A=()=>{r();const P=document.createElement("div");P.className="ui-overlay interactive";const x=document.createElement("div");x.className="ui-logo",x.style.fontSize="36px",x.textContent="遊戲已暫停";const v=document.createElement("div");v.className="ui-hint",v.textContent="操作：雙擊 W 疾跑（Ctrl 也能疾跑，但 Ctrl+W 是瀏覽器保留鍵，可能被瀏覽器吃掉）｜Q 丟棄 1 個、Ctrl+Q 丟整疊｜右鍵長按連續放置｜F5 切換第一人稱／面後／面前視角",P.append(x,s("繼續遊戲",()=>{f(),Uh()}),s(`Mode: ${l()}`,()=>{_(),A()}),s(`陰影：${c()}`,()=>{m(),A()}),s(`雲：${u()}`,()=>{p(),A()}),s("設定",()=>{r(),o(a(A))}),s("儲存並離開",g),s("回到標題",h),v,R()),o(P),C()};A()},hideAll:r,isVisible:()=>e!==null}}function zw(n){switch(n){case"fall":return"你從高處摔落";case"zombie":return"你被殭屍殺死了";case"skeleton":return"你被骷髏射死了";case"starve":return"你餓死了";case"cactus":return"你被仙人掌刺死了";case"unknown":return"你死了";case null:return""}}function Hw(n){let e=null;const t=()=>{e==null||e.remove(),e=null},i=(r,s)=>{const o=document.createElement("button");return o.className="ui-btn interactive",o.textContent=r,o.addEventListener("click",s),o};return{show({onRespawn:r,onQuit:s,cause:o}){t();const a=document.createElement("div");a.className="death-screen interactive";const l=document.createElement("h1");if(l.className="death-title",l.textContent="You died!",a.appendChild(l),o){const c=document.createElement("p");c.className="death-cause",c.textContent=o,a.appendChild(c)}a.append(i("Respawn",r),i("回到標題",s)),e=a,n.appendChild(a)},hide:t,isVisible:()=>e!==null}}const Vw=["oak_planks","spruce_planks","birch_planks"],Wt=Vw,Ne="stick",kt="cobblestone",Gw="coal",xn="iron_ingot",Sn="gold_ingot",yn="diamond",Ww=[{id:"log_to_planks",kind:"shapeless",inputs:["oak_log"],result:{item:"oak_planks",count:4}},{id:"spruce_log_to_planks",kind:"shapeless",inputs:["spruce_log"],result:{item:"spruce_planks",count:4}},{id:"birch_log_to_planks",kind:"shapeless",inputs:["birch_log"],result:{item:"birch_planks",count:4}},{id:"planks_to_stick",kind:"shaped",pattern:[[Wt],[Wt]],result:{item:"stick",count:4}},{id:"planks_to_table",kind:"shaped",pattern:[[Wt,Wt],[Wt,Wt]],result:{item:"crafting_table",count:1}},{id:"wooden_pickaxe",kind:"shaped",pattern:[[Wt,Wt,Wt],[null,Ne,null],[null,Ne,null]],result:{item:"wooden_pickaxe",count:1}},{id:"wooden_axe",kind:"shaped",pattern:[[Wt,Wt],[Wt,Ne],[null,Ne]],result:{item:"wooden_axe",count:1}},{id:"wooden_axe_mirrored",kind:"shaped",pattern:[[Wt,Wt],[Ne,Wt],[Ne,null]],result:{item:"wooden_axe",count:1}},{id:"wooden_sword",kind:"shaped",pattern:[[Wt],[Wt],[Ne]],result:{item:"wooden_sword",count:1}},{id:"wooden_shovel",kind:"shaped",pattern:[[Wt],[Ne],[Ne]],result:{item:"wooden_shovel",count:1}},{id:"stone_pickaxe",kind:"shaped",pattern:[[kt,kt,kt],[null,Ne,null],[null,Ne,null]],result:{item:"stone_pickaxe",count:1}},{id:"stone_axe",kind:"shaped",pattern:[[kt,kt],[kt,Ne],[null,Ne]],result:{item:"stone_axe",count:1}},{id:"stone_axe_mirrored",kind:"shaped",pattern:[[kt,kt],[Ne,kt],[Ne,null]],result:{item:"stone_axe",count:1}},{id:"stone_sword",kind:"shaped",pattern:[[kt],[kt],[Ne]],result:{item:"stone_sword",count:1}},{id:"stone_shovel",kind:"shaped",pattern:[[kt],[Ne],[Ne]],result:{item:"stone_shovel",count:1}},{id:"iron_pickaxe",kind:"shaped",pattern:[[xn,xn,xn],[null,Ne,null],[null,Ne,null]],result:{item:"iron_pickaxe",count:1}},{id:"iron_axe",kind:"shaped",pattern:[[xn,xn],[xn,Ne],[null,Ne]],result:{item:"iron_axe",count:1}},{id:"iron_axe_mirrored",kind:"shaped",pattern:[[xn,xn],[Ne,xn],[Ne,null]],result:{item:"iron_axe",count:1}},{id:"iron_sword",kind:"shaped",pattern:[[xn],[xn],[Ne]],result:{item:"iron_sword",count:1}},{id:"iron_shovel",kind:"shaped",pattern:[[xn],[Ne],[Ne]],result:{item:"iron_shovel",count:1}},{id:"golden_pickaxe",kind:"shaped",pattern:[[Sn,Sn,Sn],[null,Ne,null],[null,Ne,null]],result:{item:"golden_pickaxe",count:1}},{id:"golden_axe",kind:"shaped",pattern:[[Sn,Sn],[Sn,Ne],[null,Ne]],result:{item:"golden_axe",count:1}},{id:"golden_axe_mirrored",kind:"shaped",pattern:[[Sn,Sn],[Ne,Sn],[Ne,null]],result:{item:"golden_axe",count:1}},{id:"golden_sword",kind:"shaped",pattern:[[Sn],[Sn],[Ne]],result:{item:"golden_sword",count:1}},{id:"golden_shovel",kind:"shaped",pattern:[[Sn],[Ne],[Ne]],result:{item:"golden_shovel",count:1}},{id:"diamond_pickaxe",kind:"shaped",pattern:[[yn,yn,yn],[null,Ne,null],[null,Ne,null]],result:{item:"diamond_pickaxe",count:1}},{id:"diamond_axe",kind:"shaped",pattern:[[yn,yn],[yn,Ne],[null,Ne]],result:{item:"diamond_axe",count:1}},{id:"diamond_axe_mirrored",kind:"shaped",pattern:[[yn,yn],[Ne,yn],[Ne,null]],result:{item:"diamond_axe",count:1}},{id:"diamond_sword",kind:"shaped",pattern:[[yn],[yn],[Ne]],result:{item:"diamond_sword",count:1}},{id:"diamond_shovel",kind:"shaped",pattern:[[yn],[Ne],[Ne]],result:{item:"diamond_shovel",count:1}},{id:"furnace",kind:"shaped",pattern:[[kt,kt,kt],[kt,null,kt],[kt,kt,kt]],result:{item:"furnace",count:1}},{id:"torch",kind:"shaped",pattern:[[Gw],[Ne]],result:{item:"torch",count:4}}];function Xw(n){return new Array(n*n).fill(null)}function Va(n){return!!n&&Number.isFinite(n.count)&&n.count>=1}function qw(n,e){return n===null?e===null:e===null?!1:typeof n=="string"?n===e:n.includes(e)}const Qm=(n,e,t)=>e*n+t;function Yw(n,e){let t=e,i=e,r=-1,s=-1;for(let o=0;o<e;o++)for(let a=0;a<e;a++)n[Qm(e,o,a)]&&(o<t&&(t=o),a<i&&(i=a),o>r&&(r=o),a>s&&(s=a));return r<0?null:[t,i,r,s]}function Kw(n,e){const t=new Map;for(const r of e.inputs)t.set(r,(t.get(r)??0)+1);const i=new Map;for(const r of n)Va(r)&&i.set(r.item,(i.get(r.item)??0)+r.count);if(t.size!==i.size)return!1;for(const[r,s]of t)if(i.get(r)!==s)return!1;return!0}function Zw(n,e,t){const i=n.map(Va),r=Yw(i,e);if(!r)return!1;const s=t.pattern.length;let o=0;for(const h of t.pattern)h.length>o&&(o=h.length);const a=(h,g)=>{var _;return((_=t.pattern[h])==null?void 0:_[g])??null},l=$w(a,s,o);if(!l)return!1;const c=r[2]-r[0]+1,u=r[3]-r[1]+1,d=l[2]-l[0]+1,f=l[3]-l[1]+1;if(c!==d||u!==f)return!1;for(let h=l[0];h<=l[2];h++)for(let g=l[1];g<=l[3];g++){const _=a(h,g),m=r[0]+(h-l[0]),p=r[1]+(g-l[1]),E=n[Qm(e,m,p)],S=Va(E)?E.item:null;if(!qw(_,S))return!1}return!0}function $w(n,e,t){let i=e,r=t,s=-1,o=-1;for(let a=0;a<e;a++)for(let l=0;l<t;l++)n(a,l)!==null&&(a<i&&(i=a),l<r&&(r=l),a>s&&(s=a),l>o&&(o=l));return s<0?null:[i,r,s,o]}function jw(n,e){if(e!==2&&e!==3||n.length!==e*e)return null;for(const t of Ww)if(t.kind==="shapeless"?Kw(n,t):Zw(n,e,t))return t;return null}function Oh(n,e){const t=jw(n,e);return t?{...t.result}:null}function Jw(n){return n.map(e=>Va(e)&&e.count>1?{item:e.item,count:e.count-1}:null)}const Ii=n=>!!n&&Number.isFinite(n.count)&&n.count>=1,Qw=9;function sc(n,e){const t=document.createElement("canvas");t.width=un,t.height=un;const i=yr(t);i&&Ii(e)&&(i.imageSmoothingEnabled=!1,i.drawImage(Mr(e.item),0,0));const r=document.createElement("span");r.className="count",r.textContent=Ii(e)&&e.count>1?String(e.count):"",n.append(t,r),Ha(n,e)}function eg(n,e){const t=e.sourceCount??Qw;let i=Number.isInteger(e.selected)&&e.selected>=0&&e.selected<t?e.selected:0;const r=document.createElement("div");r.className="ui-craft";const s=()=>{const l=Oh(e.grid,e.size),c=document.createElement("div");c.className="ui-craft-row";const u=document.createElement("div");u.className=`ui-craft-grid size-${e.size}`;for(let g=0;g<e.size*e.size;g++){const _=document.createElement("div");_.className="ui-slot",_.dataset.cell=String(g);const m=e.grid[g];_.title=Ii(m)?ui(m.item):"",sc(_,Ii(m)?m:null),_.addEventListener("click",()=>o(g)),u.appendChild(_)}const d=document.createElement("div");d.className="ui-craft-arrow",d.textContent="→";const f=document.createElement("div");f.className="ui-slot ui-craft-result",f.title=l?ui(l.item):"",sc(f,l),f.addEventListener("click",a),c.append(u,d,f);const h=document.createElement("div");h.className="ui-craft-hotbar",e.slots.slice(0,t).forEach((g,_)=>{const m=document.createElement("div");m.className=_===i?"ui-slot selected":"ui-slot",m.dataset.slot=String(_),m.title=Ii(g)?ui(g.item):"",sc(m,Ii(g)?g:null),m.addEventListener("click",()=>{var p;i=_,(p=e.onSlotSelect)==null||p.call(e,_),s()}),h.appendChild(m)}),r.replaceChildren(c,h)},o=l=>{const c=e.grid[l];if(Ii(c)){if(e.onGiveBack(c.item,c.dur)>0){s();return}e.grid[l]=c.count>1?{item:c.item,count:c.count-1}:null}else{const u=e.slots[i];if(!Ii(u)||!e.onSpend(i,u.item))return;e.grid[l]={item:u.item,count:1,...u.dur!==void 0?{dur:u.dur}:{}}}s()},a=()=>{const l=Oh(e.grid,e.size);if(!l||!e.onTake(l))return;const c=Jw(e.grid);for(let u=0;u<e.grid.length;u++)e.grid[u]=c[u];s()};return s(),n.appendChild(r),{unmount:()=>r.remove(),refresh:()=>s()}}function eR(n){let e=null,t=null,i=null;const r=()=>{i&&(document.removeEventListener("keydown",i),i=null),t==null||t.unmount(),t=null,e==null||e.remove(),e=null};return{open(s){r();const o=s.onClose;e=document.createElement("div"),e.className="ui-overlay ui-craft-backdrop interactive",e.addEventListener("click",c=>{c.target===e&&(this.close(),o==null||o())}),i=c=>{c.key==="Escape"&&(this.close(),o==null||o())},document.addEventListener("keydown",i);const a=document.createElement("div");a.className="ui-craft-panel interactive";const l=document.createElement("h3");l.textContent=s.size===3?"工作台（3×3）":"合成（2×2）",a.appendChild(l),e.appendChild(a),n.appendChild(e),t=eg(a,s)},close(){r()},isOpen:()=>e!==null,refresh(){t==null||t.refresh()}}}function oc(n,e){if(!e||!Number.isFinite(e.count)||e.count<1){n.replaceChildren(),Ha(n,null);return}const t=document.createElement("canvas");t.width=un,t.height=un;const i=yr(t);i&&(i.imageSmoothingEnabled=!1,i.drawImage(Mr(e.item),0,0));const r=document.createElement("span");r.className="count",r.textContent=e.count>1?String(e.count):"",n.replaceChildren(t,r),Ha(n,e)}function tR(n){let e=null,t=null,i=null,r=null,s,o=[],a=()=>{},l=0,c=!0,u=[],d=[],f=null,h=null;const g=x=>!!x&&Number.isFinite(x.count)&&x.count>=1,_=x=>{const v=o[x];return g(v)?v:null},m=(x,v)=>{var w;(w=s==null?void 0:s.onSlotChange)==null||w.call(s,x,v)},p=(x,v)=>{oc(x,g(v)?{...v}:null),x.title=g(v)?ui(v.item):""},E=()=>{u.forEach((x,v)=>p(x,o[v])),d.forEach((x,v)=>p(x,o[Ta+v]))},S=()=>{var x;if(!r){f==null||f.remove(),f=null;return}f||(f=document.createElement("div"),f.className="ui-cursor-stack",f.style.left="-100px",f.style.top="-100px"),f.title=ui(r.item),oc(f,{...r}),e&&((x=e.querySelector(".ui-inventory"))==null||x.appendChild(f))},y=x=>{const v=_(x);if(r)if(v){const w={...v};m(x,r),r=w}else m(x,r),r=null;else{if(!v)return;r={...v},m(x,null)}E(),S()},C=x=>{const v=_(x);if(r)v?v.item===r.item&&v.count<Hi(v.item)&&(m(x,{item:v.item,count:v.count+1}),r=r.count>1?{item:r.item,count:r.count-1}:null):(m(x,{item:r.item,count:1,...r.dur!==void 0?{dur:r.dur}:{}}),r=r.count>1?{item:r.item,count:r.count-1}:null);else{if(!v)return;const w=Math.ceil(v.count/2),k=v.count-w;r={item:v.item,count:w,...v.dur!==void 0?{dur:v.dur}:{}},m(x,k>=1?{item:v.item,count:k}:null)}E(),S()},R=(x,v)=>{x.className="ui-slot",x.addEventListener("click",()=>y(v)),x.addEventListener("contextmenu",w=>{w.preventDefault(),C(v)})},A=x=>{var w;f&&(f.style.left=`${x.clientX}px`,f.style.top=`${x.clientY}px`);const v=(w=x.target instanceof Element?x.target:null)==null?void 0:w.closest(".ui-slot");v!==h&&(h==null||h.classList.remove("ui-cursor-target"),v instanceof HTMLElement&&v.classList.add("ui-cursor-target"),h=v instanceof HTMLElement?v:null)},P=()=>{h==null||h.classList.remove("ui-cursor-target"),h=null};return{open(x,v,w,k,B,X="creative",J){this.close(),s=J,o=x,l=v,a=w,c=X==="survival",e=document.createElement("div"),e.className="ui-overlay ui-inv-backdrop interactive",e.addEventListener("click",Q=>{Q.target===e&&(this.close(),k==null||k())}),t=Q=>{Q.key==="Escape"&&(this.close(),k==null||k())},document.addEventListener("keydown",t);const H=document.createElement("div");H.className="ui-inventory interactive";const te=document.createElement("h3");te.textContent=c?"背包":`方塊（點選放入欄位 ${l+1}）`,H.appendChild(te),B&&(i=eg(H,B));const I=document.createElement("div");I.className="ui-inv-main",d=[];for(let Q=0;Q<xm;Q++){const se=document.createElement("div");R(se,Ta+Q),I.appendChild(se),d.push(se)}const Z=document.createElement("div");Z.className="ui-inv-bar",u=[];for(let Q=0;Q<Ta;Q++){const se=document.createElement("div");R(se,Q),Z.appendChild(se),u.push(se)}if(H.append(I,Z),!c){const Q=document.createElement("div");Q.className="ui-inv-list";for(const se of gm){const Me=document.createElement("div");Me.className="ui-slot",Me.title=ui(se),oc(Me,{item:se,count:Hi(se)}),Me.addEventListener("click",()=>a(l,{item:se,count:Hi(se)})),Q.appendChild(Me)}H.appendChild(Q)}H.addEventListener("mousemove",A),H.addEventListener("mouseleave",P),E(),e.appendChild(H),n.appendChild(e),S()},close(){if(r){let x=r;s!=null&&s.onReturnCursor&&(x=s.onReturnCursor(r)),r=x}s=void 0,h=null,t&&(document.removeEventListener("keydown",t),t=null),i==null||i.unmount(),i=null,f&&(f.remove(),f=null),o=[],u=[],d=[],e==null||e.remove(),e=null},isOpen:()=>e!==null,refreshCrafting(){e&&(E(),i==null||i.refresh())},returnCursor(){const x=r;return r=null,f==null||f.remove(),f=null,x}}}function nR(n,e,t){const i=[...n.excess];n.excess.length=0;for(const s of n.grid)s&&Number.isFinite(s.count)&&s.count>=1&&i.push({...s});n.grid.length=0,n.grid.push(...Xw(e));let r=0;for(const s of i){const o=t.giveItem(s.item,s.count,s.dur);if(o<=0)continue;const a={item:s.item,count:o,...s.dur!==void 0?{dur:s.dur}:{}};t.dropOverflow?t.dropOverflow(a):r<n.grid.length?n.grid[r++]=a:n.excess.push(a)}}const Ga=n=>!!n&&Number.isFinite(n.count)&&n.count>=1;function iR(n,e){const t=document.createElement("canvas");t.width=un,t.height=un;const i=yr(t);i&&Ga(e)&&(i.imageSmoothingEnabled=!1,i.drawImage(Mr(e.item),0,0));const r=document.createElement("span");r.className="count",r.textContent=Ga(e)&&e.count>1?String(e.count):"",n.append(t,r)}const ac=n=>Ga(n)?`${n.item}×${n.count}`:"";function rR(n,e){let t=null,i=null,r=null,s=null,o=null,a=null,l=null,c="";const u=()=>{i&&(document.removeEventListener("keydown",i),i=null),t==null||t.remove(),t=null,r=s=o=a=l=null,c=""},d=(h,g)=>{h.replaceChildren();const _=Ga(g)?g:null;h.title=_?ui(_.item):"",iR(h,_)},f=h=>{if(!r||!s||!o||!a||!l)return;const g=[ac(h.input),ac(h.fuel),ac(h.output)].join("|");g!==c&&(c=g,d(r,h.input),d(s,h.fuel),d(o,h.output));const _=Number.isFinite(h.progressSec)?Math.max(0,Math.min(1,h.progressSec/gu)):0;a.style.width=`${_*100}%`;const m=h.fuelUnits>0||!!h.fuel&&h.fuel.item in Ba;l.classList.toggle("lit",m)};return{open(h){if(!t){t=document.createElement("div"),t.className="ui-overlay ui-furnace-backdrop interactive",t.addEventListener("click",E=>{E.target===t&&(this.close(),e.onClose())}),i=E=>{E.key!=="Escape"&&E.code!=="KeyE"||(this.close(),e.onClose())},document.addEventListener("keydown",i);const g=document.createElement("div");g.className="furnace-panel interactive";const _=document.createElement("h3");_.textContent="熔爐",g.appendChild(_);const m=document.createElement("div");m.className="furnace-row",r=document.createElement("div"),r.className="ui-slot furnace-input",r.dataset.fslot="input",r.addEventListener("click",()=>{var E;return(E=e.onSlotClick)==null?void 0:E.call(e,"input")}),s=document.createElement("div"),s.className="ui-slot furnace-fuel",s.dataset.fslot="fuel",s.addEventListener("click",()=>{var E;return(E=e.onSlotClick)==null?void 0:E.call(e,"fuel")});const p=document.createElement("div");p.className="furnace-progress",a=document.createElement("div"),a.className="furnace-progress-fill",p.appendChild(a),l=document.createElement("div"),l.className="furnace-burn",l.textContent="🔥",o=document.createElement("div"),o.className="ui-slot furnace-output",o.dataset.fslot="output",o.addEventListener("click",()=>e.onTakeOutput()),m.append(r,s,p,l,o),g.appendChild(m),t.appendChild(g),n.appendChild(t)}f(h)},close(){u()},dispose(){u()}}}const sR=4e3,oR=5;function aR(n,e){const t=sR,i=Math.max(1,oR),r=document.createElement("div");r.className="toasts",n.appendChild(r);const s=[],o=new Map,a=c=>{const u=o.get(c);u!==void 0&&clearTimeout(u),o.delete(c);const d=s.indexOf(c);d!==-1&&s.splice(d,1),c.remove()};let l=!1;return{push({title:c,description:u,icon:d}){if(l)return;for(;s.length>=i;)a(s[0]);const f=document.createElement("div");f.className="toast";const h=document.createElement("canvas");h.className="toast-icon",h.width=un,h.height=un;const g=yr(h);g&&(g.imageSmoothingEnabled=!1,g.drawImage(Mr(d),0,0));const _=document.createElement("div");_.className="toast-text";const m=document.createElement("div");m.className="toast-title",m.textContent=c;const p=document.createElement("div");p.className="toast-desc",p.textContent=u,_.append(m,p),f.append(h,_),r.appendChild(f),s.push(f),o.set(f,setTimeout(()=>a(f),t))},dispose(){l=!0;for(const c of[...s])a(c);r.remove()}}}const lR=300;function cR(n){let e=null,t;return{flash(){e||(e=document.createElement("div"),e.className="hurt-flash",n.appendChild(e)),clearTimeout(t),t=setTimeout(()=>{e==null||e.remove(),e=null},lR)}}}function uR(n){return Number.isFinite(n)?Math.min(1,Math.max(0,n)):n>0?1:0}function fR(n){let e=null,t=null;return{show(i){e||(e=document.createElement("div"),e.className="eat-progress",t=document.createElement("div"),t.className="eat-progress-fill",e.appendChild(t),n.appendChild(e)),t&&(t.style.width=`${uR(i)*100}%`)},hide(){e==null||e.remove(),e=null,t=null}}}const dR="地形已改變",hR="世界生成器已更新：舊存檔的地形會整片改觀（你的建築可能浮空、埋入或入水）。",pR="grass";function tg(n){n.push({title:dR,description:hR,icon:pR})}const mR={ocean:11061480,plains:16777215,forest:12771506,birch_forest:13822140,taiga:12113096,snowy_plains:15267071,desert:16767392,mountains:14477042},gR=16777215;function Fh(n,e,t=.25){const i=mR[e];return i>>>0===gR||!Number.isFinite(t)||t<=0?n:Aa(n,i,t)}function _R(){const n=window;return n.AudioContext??n.webkitAudioContext}const vR=n=>Math.min(1,Math.max(0,n));function xR(n={}){let e=null,t=null,i=1;const r=a=>{try{a().catch(()=>{})}catch{}};function s(){if(n.createContext)return n.createContext();const a=_R();return a?new a:null}function o(){if(e)return;let a;try{a=s()}catch{return}a&&(e=a,t=a.createGain(),t.gain.value=i,t.connect(a.destination),a.state==="suspended"&&r(()=>a.resume()))}return{get started(){return e!==null},get context(){return e},get master(){return t},ensureStarted:o,setVolume(a){i=Number.isFinite(a)?vR(a):0,t&&(t.gain.value=i)},suspend(){const a=e;a&&r(()=>a.suspend())},resume(){const a=e;a&&r(()=>a.resume())},dispose(){const a=e;e=null,t=null,a&&r(()=>a.close())}}}const SR={[O.GRASS]:"grass",[O.DIRT]:"dirt",[O.SAND]:"sand",[O.SNOW]:"snow",[O.STONE]:"stone",[O.COBBLE]:"stone",[O.COAL_ORE]:"stone",[O.IRON_ORE]:"stone",[O.BEDROCK]:"stone",[O.LOG]:"wood",[O.PLANKS]:"wood",[O.CRAFTING_TABLE]:"wood",[O.FURNACE]:"stone",[O.LEAVES]:"leaves",[O.GLASS]:"glass",[O.WATER]:"water",[O.SPRUCE_LOG]:"wood",[O.SPRUCE_LEAVES]:"leaves",[O.BIRCH_LOG]:"wood",[O.BIRCH_LEAVES]:"leaves",[O.DANDELION]:"grass",[O.POPPY]:"grass",[O.SHORT_GRASS]:"grass",[O.CACTUS]:"grass",[O.ICE]:"glass",[O.WOOL]:"leaves",[O.GRAVEL]:"sand",[O.GOLD_ORE]:"stone",[O.DIAMOND_ORE]:"stone",[O.SPRUCE_PLANKS]:"wood",[O.BIRCH_PLANKS]:"wood",[O.TORCH]:"wood"};function wa(n){return SR[n]??"dirt"}const kh=3,lc=20;function yR(n){return Number.isFinite(n)?n<=kh?1:n>=lc?0:(lc-n)/(lc-kh):0}function MR(n){return!Number.isFinite(n)||n<=.1?1/0:Math.min(.55,Math.max(.3,1.35/n))}const ER={dirt:{filter:"lowpass",freq:700,q:.7},grass:{filter:"lowpass",freq:900,q:.7},sand:{filter:"lowpass",freq:1200,q:.7},snow:{filter:"lowpass",freq:600,q:.7},stone:{filter:"bandpass",freq:1100,q:1.2},wood:{filter:"bandpass",freq:800,q:1},leaves:{filter:"highpass",freq:1800,q:.8},glass:{filter:"highpass",freq:3e3,q:1},water:{filter:"lowpass",freq:500,q:.6}},bR={filter:"lowpass",freq:500,q:.7,durationSec:.25,gain:.8},AR={dig:{durationSec:.12,gain:.5,scale:1},break:{durationSec:.18,gain:.6,scale:.85},place:{durationSec:.09,gain:.5,scale:.7},step:{durationSec:.08,gain:.25,scale:.9},tool_break:{durationSec:.25,gain:.8,scale:1}};function TR(n,e){if(e==="tool_break")return{...bR};const t=ER[n],i=AR[e];return{filter:t.filter,freq:Math.round(t.freq*i.scale),q:t.q,durationSec:i.durationSec,gain:i.gain}}const wR=.005,Bh=.05,RR=300,CR=.04,PR=1800,IR=2600,cc=.15,LR=.12,DR=4e3,zh=.08,NR=.15,UR=200,OR=800,uc=.8,FR=.2;function kR(n){const e=Math.floor(n.sampleRate),t=n.createBuffer(1,e,n.sampleRate),i=t.getChannelData(0);for(let r=0;r<e;r++)i[r]=Math.random()*2-1;return t}function BR(n,e,t,i,r){const s=n.currentTime,o=i*t.gain,a=n.createBufferSource();a.buffer=r;const l=n.createBiquadFilter();l.type=t.filter,l.frequency.value=t.freq,l.Q.value=t.q;const c=n.createGain();c.gain.setValueAtTime(0,s),c.gain.linearRampToValueAtTime(o,s+wR),c.gain.setValueAtTime(o,s+t.durationSec),c.gain.linearRampToValueAtTime(0,s+t.durationSec+Bh),a.connect(l),l.connect(c),c.connect(e),a.start(),a.stop(s+t.durationSec+Bh)}function zR(n,e,t){const i=n.createBufferSource();i.buffer=t,i.loop=!0;const r=n.createBiquadFilter();r.type="lowpass",r.frequency.value=RR;const s=n.createGain();s.gain.value=CR,i.connect(r),r.connect(s),s.connect(e),i.start();let o=!1;return{stop(){o||(o=!0,i.stop(),i.disconnect(),r.disconnect(),s.disconnect())}}}function HR(n,e){const t=n.currentTime,i=n.createOscillator();i.type="sine",i.frequency.setValueAtTime(PR,t),i.frequency.linearRampToValueAtTime(IR,t+cc);const r=n.createGain();r.gain.setValueAtTime(0,t),r.gain.linearRampToValueAtTime(LR,t+.02),r.gain.linearRampToValueAtTime(0,t+cc),i.connect(r),r.connect(e),i.start(),i.stop(t+cc)}function VR(n,e,t){const i=n.currentTime,r=n.createBufferSource();r.buffer=t;const s=n.createBiquadFilter();s.type="highpass",s.frequency.value=DR;const o=n.createGain();o.gain.setValueAtTime(0,i),o.gain.linearRampToValueAtTime(NR,i+.01),o.gain.linearRampToValueAtTime(0,i+zh),r.connect(s),s.connect(o),o.connect(e),r.start(),r.stop(i+zh)}function GR(n,e,t){const i=n.currentTime,r=n.createBufferSource();r.buffer=t;const s=n.createBiquadFilter();s.type="bandpass",s.frequency.setValueAtTime(UR,i),s.frequency.linearRampToValueAtTime(OR,i+uc);const o=n.createGain();o.gain.setValueAtTime(0,i),o.gain.linearRampToValueAtTime(FR,i+.05),o.gain.linearRampToValueAtTime(0,i+uc),r.connect(s),s.connect(o),o.connect(e),r.start(),r.stop(i+uc)}const WR={day:[4,9],night:[3,7]},XR=80,qR=64;function YR(n={}){const e=xR(n);let t=null,i=null,r=null,s="day",o=Number.NEGATIVE_INFINITY;const a=n.now??(()=>performance.now()),l=[];function c(p){return t||(t=kR(p)),t}function u(){r!==null&&(clearTimeout(r),r=null)}function d(){const[p,E]=WR[s],S=(p+Math.random()*(E-p))*1e3;r=setTimeout(()=>{r=null;const y=e.context,C=e.master;!y||!C||(s==="day"?HR(y,C):VR(y,C,c(y)),d())},S)}function f(p,E,S={}){l.push({kind:p,group:E,...S.pos?{pos:{...S.pos}}:{}}),l.length>qR&&l.shift();const y=e.context,C=e.master;if(!y||!C)return;if(p==="break"){const v=a();if(v-o<XR)return;o=v}const R=S.listener??S.pos,A=R&&S.pos?Math.hypot(S.pos.x-R.x,S.pos.y-R.y,S.pos.z-R.z):0,P=S.volume??1,x=(Number.isFinite(P)?P:0)*yR(A);BR(y,C,TR(E,p),x,c(y))}function h(){const p=e.context,E=e.master;!p||!E||i||(i=zR(p,E,c(p)),d())}function g(){u(),i&&(i.stop(),i=null)}function _(p){s=p;const E=e.context,S=e.master;E&&S&&GR(E,S,c(E)),i&&(u(),d())}function m(){g(),t=null,o=Number.NEGATIVE_INFINITY,e.dispose()}return{ensureStarted(){e.ensureStarted()},setVolume(p){e.setVolume(p)},handleVisibility(p){p?e.suspend():e.resume()},play:f,played:()=>l,startAmbience:h,stopAmbience:g,setPhase:_,dispose:m}}const ng=[{id:"getting_wood",title:"取得原木",description:"第一次拾取原木",icon:"oak_log"},{id:"crafting_table",title:"合成台",description:"合成一個工作台",icon:"crafting_table"},{id:"wooden_tool",title:"木製工具",description:"合成一把木製工具",icon:"wooden_pickaxe"},{id:"stone_tool",title:"石製工具",description:"合成一把石製工具",icon:"stone_pickaxe"},{id:"iron_tool",title:"鐵製工具",description:"合成一把鐵製工具",icon:"iron_pickaxe"},{id:"stone_age",title:"鵝卵石",description:"取得鵝卵石",icon:"cobblestone"},{id:"coal_miner",title:"煤炭開採",description:"取得煤炭",icon:"coal"},{id:"iron_age",title:"鐵礦",description:"取得鐵礦",icon:"iron_ore"},{id:"gold_age",title:"黃金時代",description:"取得金錠",icon:"gold_ingot"},{id:"diamond_age",title:"鑽石時代",description:"取得鑽石",icon:"diamond"},{id:"golden_tool",title:"金製工具",description:"合成一把金製工具",icon:"golden_pickaxe"},{id:"diamond_tool",title:"鑽製工具",description:"合成一把鑽製工具",icon:"diamond_pickaxe"},{id:"hot_stuff",title:"燃燒吧",description:"從熔爐取出冶煉成品",icon:"furnace"},{id:"pasture",title:"牧場",description:"取得生肉或羊毛",icon:"raw_beef"},{id:"tasty",title:"吃個蘋果",description:"吃掉一個蘋果",icon:"apple"},{id:"monster_hunter",title:"怪物獵人",description:"擊殺一隻怪物",icon:"stone_sword"},{id:"first_night",title:"度過第一夜",description:"活著看見黎明",icon:"grass"}];function al(){return{done:{},nightSeen:!1}}const KR={oak_log:"getting_wood",spruce_log:"getting_wood",birch_log:"getting_wood",crafting_table:"crafting_table",wooden_pickaxe:"wooden_tool",wooden_axe:"wooden_tool",wooden_sword:"wooden_tool",stone_pickaxe:"stone_tool",stone_axe:"stone_tool",stone_sword:"stone_tool",iron_pickaxe:"iron_tool",iron_axe:"iron_tool",iron_sword:"iron_tool",golden_pickaxe:"golden_tool",golden_axe:"golden_tool",golden_sword:"golden_tool",golden_shovel:"golden_tool",diamond_pickaxe:"diamond_tool",diamond_axe:"diamond_tool",diamond_sword:"diamond_tool",diamond_shovel:"diamond_tool",cobblestone:"stone_age",coal:"coal_miner",iron_ore:"iron_age",raw_iron:"iron_age",raw_gold:"gold_age",gold_ingot:"gold_age",diamond:"diamond_age",raw_chicken:"pasture",raw_porkchop:"pasture",raw_mutton:"pasture",raw_beef:"pasture",wool:"pasture"};function ZR(n,e){if(e.type==="phase")return e.phase==="night"?n.nightSeen?{state:n,unlocked:[]}:{state:{done:{...n.done},nightSeen:!0},unlocked:[]}:!n.nightSeen||n.done.first_night?{state:n,unlocked:[]}:{state:{done:{...n.done,first_night:!0},nightSeen:!0},unlocked:["first_night"]};if(e.mode==="creative")return{state:n,unlocked:[]};const t=e.type==="obtain"?KR[e.item]:e.type==="smelt-take"?"hot_stuff":e.type==="ate"?e.item==="apple"?"tasty":void 0:"monster_hunter";return!t||n.done[t]?{state:n,unlocked:[]}:{state:{done:{...n.done,[t]:!0},nightSeen:n.nightSeen},unlocked:[t]}}const $R=new Set(ng.map(n=>n.id));function ig(n){if(typeof n!="object"||n===null)return al();const e=n,t={};if(typeof e.done=="object"&&e.done!==null)for(const[i,r]of Object.entries(e.done))$R.has(i)&&typeof r=="boolean"&&(t[i]=r);return{done:t,nightSeen:e.nightSeen===!0}}function jR(n){return{version:5,savedAt:n.savedAt??Date.now(),worldSeed:n.world.seed,modified:n.world.serializeModified(),player:{pos:[n.player.pos[0],n.player.pos[1],n.player.pos[2]],yaw:n.player.yaw,mode:n.player.mode,vitals:n.vitals?{...n.vitals}:null,inventory:fi(n.player.inventory,Vi)},time:{t:n.clockT},advancements:{done:{...n.advancements.done},nightSeen:n.advancements.nightSeen},stash:{survival:fi(n.stash.survival,Vi),creative:fi(n.stash.creative,Vi),survivalVitals:{...n.stash.survivalVitals}},worldgenVersion:nl,passiveMobs:Km(n.passiveMobs)}}function JR(n){if(typeof n!="object"||n===null)return!1;const e=n;if(e.version!==1&&e.version!==2&&e.version!==3&&e.version!==4&&e.version!==5)return!1;const t=e.player;if(typeof t!="object"||t===null||!Array.isArray(t.pos)||t.pos.length!==3||!t.pos.every(s=>typeof s=="number"&&Number.isFinite(s))||typeof t.yaw!="number"||!Number.isFinite(t.yaw)||t.mode!=="survival"&&t.mode!=="creative"||!Array.isArray(t.inventory))return!1;for(const s of t.inventory){if(s===null)continue;if(typeof s!="object"||s===null)return!1;const o=s;if(typeof o.item!="string"||typeof o.count!="number"||!Number.isFinite(o.count))return!1}const i=t.vitals;if(i!==null&&(typeof i!="object"||i===null||typeof i.hp!="number"||!Number.isFinite(i.hp))||!Array.isArray(e.modified))return!1;const r=e.time;return!(typeof r!="object"||r===null||typeof r.t!="number"||!Number.isFinite(r.t))}const QR="wecraft-save",eC=1,vs="games",rg="slot1";function sg(n){return new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error??new Error("IndexedDB request failed"))})}function og(){return new Promise((n,e)=>{const t=indexedDB.open(QR,eC);t.onupgradeneeded=()=>{const i=t.result;i.objectStoreNames.contains(vs)||i.createObjectStore(vs)},t.onsuccess=()=>n(t.result),t.onerror=()=>e(t.error??new Error("Failed to open save database")),t.onblocked=()=>e(new Error("Save database open blocked"))})}async function ll(n){const e={...n,savedAt:Date.now()},t=await og();try{const i=t.transaction(vs,"readwrite");await sg(i.objectStore(vs).put(e,rg)),await new Promise((r,s)=>{i.oncomplete=()=>r(),i.onabort=()=>s(i.error??new Error("Save transaction aborted")),i.onerror=()=>s(i.error??new Error("Save transaction failed"))})}finally{t.close()}}async function tC(){try{const n=await og();try{const e=n.transaction(vs,"readonly"),t=await sg(e.objectStore(vs).get(rg));if(t==null||typeof t!="object"||!JR(t))return null;const i=t.version===1?{...t,version:2,advancements:al()}:{...t,version:2,advancements:ig(t.advancements)},r={...i,version:3,stash:il(t.stash,{mode:t.player.mode,inventory:t.player.inventory,vitals:t.player.vitals}),player:{...i.player,vitals:i.player.vitals===null?null:co(i.player.vitals)}},o={...{...r,version:4,player:{...r.player,inventory:fi(r.player.inventory,Vi)}},version:5},{worldgenVersion:a,passiveMobs:l,...c}=o,u=Pm(a);return{...c,...u===void 0?{}:{worldgenVersion:u},passiveMobs:tf(l)}}finally{n.close()}}catch{return null}}const nC=3,iC=[1,2,3];function rf(n){return iC.includes(n)}function uo(n){const e=[];for(let t=0;t<Vi;t++){const i=t<n.length?n[t]:null;e.push(i===null?null:{...i})}return e}function Ra(n){const e=qn(n.item);if(e<=0)return{item:n.item,count:n.count};const t=lo(n.item,n.dur);return{item:n.item,count:n.count,dur:t??e}}const ag=65536;function rC(n){const e=Array.isArray(n.pos)&&n.pos.length===3&&n.pos.every(i=>typeof i=="number"&&Number.isFinite(i))?[n.pos[0],n.pos[1],n.pos[2]]:[0,0,0],t=typeof n.yaw=="number"&&Number.isFinite(n.yaw)?n.yaw:0;return{seed:n.seed,pos:e,yaw:t,vitals:n.vitals===null?null:{...n.vitals},clockT:n.clockT,inventory:uo(n.inventory).map(i=>i===null?null:Ra(i)),advancements:{done:{...n.advancements.done},nightSeen:n.advancements.nightSeen},settings:{renderDistance:n.settings.renderDistance,sensitivity:n.settings.sensitivity,volume:n.settings.volume,mode:n.settings.mode,dayLengthSec:n.settings.dayLengthSec,shadows:n.settings.shadows,clouds:n.settings.clouds},stash:{survival:uo(n.stash.survival).map(i=>i===null?null:Ra(i)),creative:uo(n.stash.creative).map(i=>i===null?null:Ra(i)),survivalVitals:{...n.stash.survivalVitals}},worldgenVersion:nl,passiveMobs:Km(n.passiveMobs)}}function lg(n){return new TextEncoder().encode(JSON.stringify(n)).length}const On=n=>typeof n=="number"&&Number.isFinite(n);function cg(n){if(typeof n!="object"||n===null)return!1;const e=n;if(!On(e.seed)||!Array.isArray(e.pos)||e.pos.length!==3||!e.pos.every(On)||!On(e.yaw)||!On(e.clockT)||!Array.isArray(e.inventory))return!1;for(const i of e.inventory){if(i===null)continue;if(typeof i!="object"||i===null)return!1;const r=i;if(typeof r.item!="string"||!On(r.count))return!1}if(e.vitals!==null&&(typeof e.vitals!="object"||e.vitals===null||!On(e.vitals.hp))||typeof e.advancements!="object"||e.advancements===null||e.stash!==void 0&&(typeof e.stash!="object"||e.stash===null)||typeof e.settings!="object"||e.settings===null)return!1;const t=e.settings;return!(!On(t.renderDistance)||!On(t.sensitivity)||!On(t.volume)||t.mode!=="survival"&&t.mode!=="creative"||!On(t.dayLengthSec)||typeof t.shadows!="boolean"||typeof t.clouds!="boolean"||e.worldgenVersion!==void 0&&Pm(e.worldgenVersion)===void 0||e.passiveMobs!==void 0&&!Array.isArray(e.passiveMobs))}function sf(n){if(!cg(n))return null;const e=nf({...kn,...n.settings}),t=n.worldgenVersion;return{seed:n.seed,pos:[n.pos[0],n.pos[1],n.pos[2]],yaw:n.yaw,vitals:n.vitals===null?null:co(n.vitals),clockT:n.clockT,inventory:uo(n.inventory).map(i=>i===null?null:Ra(i)),advancements:ig(n.advancements),stash:il(n.stash,{mode:e.mode,inventory:n.inventory,vitals:n.vitals}),settings:{renderDistance:e.renderDistance,sensitivity:e.sensitivity,volume:e.volume,mode:e.mode,dayLengthSec:e.dayLengthSec,shadows:e.shadows,clouds:e.clouds},...t===void 0?{}:{worldgenVersion:t},passiveMobs:tf(n.passiveMobs)}}function sC(n,e){const t=new Set;for(const a of n.inventory)a&&t.add(a.item);const i=[];for(const a of e.inventory)!a||t.has(a.item)||i.includes(a.item)||i.push(a.item);const r=a=>{var f,h,g,_;const l=Lm(uo(n.inventory),"survival");for(const m of a){let p=0;for(const E of e.inventory)E&&E.item===m&&(p+=E.count);if(l.fits(m,p))for(const E of e.inventory)E&&E.item===m&&l.addItem(m,E.count,E.dur)}const c=((f=n.advancements)==null?void 0:f.done)??{},u=((h=e.advancements)==null?void 0:h.done)??{},d={...c};for(const[m,p]of Object.entries(u))p===!0&&(d[m]=!0);return{seed:n.seed,pos:[n.pos[0],n.pos[1],n.pos[2]],yaw:n.yaw,vitals:n.vitals===null?null:{...n.vitals},clockT:n.clockT,inventory:l.slots.map(m=>m?{...m}:null),advancements:{done:d,nightSeen:((g=n.advancements)==null?void 0:g.nightSeen)===!0||((_=e.advancements)==null?void 0:_.nightSeen)===!0},settings:{...n.settings},...n.stash===void 0?{}:{stash:{survival:n.stash.survival.map(m=>m?{...m}:null),creative:n.stash.creative.map(m=>m?{...m}:null),survivalVitals:{...n.stash.survivalVitals}}},...n.worldgenVersion===void 0?{}:{worldgenVersion:n.worldgenVersion},...n.passiveMobs===void 0?{}:{passiveMobs:n.passiveMobs.map(m=>({...m}))}}};let s=i,o=r(s);for(;lg(o)>ag&&s.length>0;)s=s.slice(0,-1),o=r(s);return o}function oC(n){return n.revision!==null}function ug(n){if(n==null)return"UNAVAILABLE";const e=typeof n=="object"||typeof n=="function"?n:{},t=typeof e.machineCode=="string"?e.machineCode:null;return t==="SAVE_REVISION_CONFLICT"?"CONFLICT":t==="SAVE_FORMAT_INCOMPATIBLE"?"FORMAT":t==="REQUEST_ID_REUSED"?"REQUEST_REUSED":e.code===401||e.code===403||e.status===401||e.status===403||t!==null&&(t.includes("AUTH")||t.includes("PERMISSION"))?"AUTH":(typeof n=="number"?n:e.code)===409||e.status===409?"CONFLICT":"NETWORK"}const aC=1e4;function lC(n,e){let t;const i=new Promise((s,o)=>{t=setTimeout(()=>o(new Error("playroom ready timeout")),e)}),r=n.then(s=>(clearTimeout(t),s),s=>{throw clearTimeout(t),s});return Promise.race([r,i])}async function cC(){try{if(typeof window<"u"&&window.parent===window||typeof document>"u")return null;const n=document.baseURI;if(!n||n==="about:blank")return null;const i=(await import(new URL("playroom-sdk.js",n).href)).Playroom;return!i||typeof i.ready!="function"||typeof i.loadProgress!="function"||typeof i.saveProgress!="function"?null:i}catch{return null}}function Hh(n){const e=ug(n);return e==="CONFLICT"?"conflict":e==="FORMAT"?"format":"error"}function uC(n={}){const e=n.loadModule??cC;let t="unknown",i=null,r=null;return{get status(){return t},get readyInfo(){return i},async init(){try{const s=await e();if(!s)return r=null,i=null,t="unsupported",t;r=s;const o=await lC(r.ready(),aC);return i=o,!o||o.progressAvailable===!1?(t="guest",t):(t="ready",t)}catch{return r=null,i=null,t="unsupported",t}},async load(){if(!r||!i||i.progressAvailable===!1)return null;try{const s=await r.loadProgress();return s?(t="ready",{data:s.data,revision:s.revision,formatVersion:s.formatVersion}):null}catch(s){throw t=Hh(s),s}},async save(s,o,a,l){if(!r||!i||i.progressAvailable===!1)return{status:"unavailable"};try{const c=await r.saveProgress({data:s,revision:o,formatVersion:a,requestId:l});return c?c.saved!==!0?{status:"unconfirmed"}:(t="ready",{status:"saved",revision:c.revision}):{status:"unavailable"}}catch(c){throw t=Hh(c),c}}}}class fC{constructor(e){ke(this,"transport");ke(this,"formatVersion");ke(this,"newRequestId");ke(this,"revisionValue",null);ke(this,"pendingValue",null);ke(this,"busyValue",!1);ke(this,"retryableValue",!1);ke(this,"failureKindValue",null);ke(this,"lockedValue",!1);ke(this,"authStoppedValue",!1);ke(this,"conflictValue",null);ke(this,"unconfirmedValue",!1);this.transport=e.transport,this.formatVersion=e.formatVersion,this.newRequestId=e.newRequestId??(()=>crypto.randomUUID())}get revision(){return this.revisionValue}get pending(){return this.pendingValue}get busy(){return this.busyValue}get retryable(){return this.retryableValue}get failureKind(){return this.failureKindValue}get locked(){return this.lockedValue}get authStopped(){return this.authStoppedValue}get conflict(){return this.conflictValue}setConflict(e){this.conflictValue=e}get unconfirmed(){return this.unconfirmedValue}setRevision(e){this.revisionValue=e}lock(e){this.lockedValue=!0,this.failureKindValue=e,this.retryableValue=!1,this.pendingValue=null}stopAuth(){this.authStoppedValue=!0,this.failureKindValue="AUTH",this.retryableValue=!1,this.pendingValue=null}markReadFailure(e="NETWORK"){this.failureKindValue=e,this.retryableValue=!0,this.unconfirmedValue=!1}clearReadFailure(){this.failureKindValue=null,this.retryableValue=!1,this.unconfirmedValue=!1}async checkpoint(e){this.lockedValue||this.authStoppedValue||this.revisionValue!==null&&(this.busyValue||this.writesBlockedByConflict()||(this.pendingValue||(this.pendingValue={data:e,requestId:this.newRequestId()}),await this.send(this.pendingValue)))}async retry(){this.lockedValue||this.authStoppedValue||this.revisionValue!==null&&(this.busyValue||this.writesBlockedByConflict()||this.pendingValue&&await this.send(this.pendingValue))}writesBlockedByConflict(){return this.conflictValue!==null||this.failureKindValue==="CONFLICT"}async resolveConflict(e){var s;const t=this.conflictValue;if(!t)return;if(this.conflictValue=null,e==="take-cloud"){this.revisionValue=t.revision,this.pendingValue=null,this.retryableValue=!1,this.failureKindValue=null,this.unconfirmedValue=!1;return}const i=(s=this.pendingValue)==null?void 0:s.data,r=e==="merge"&&cg(i)?sC(i,t.data):i;if(r===void 0){this.revisionValue=t.revision,this.pendingValue=null,this.failureKindValue=null,this.retryableValue=!1;return}this.revisionValue=t.revision,this.pendingValue={data:r,requestId:this.newRequestId()},await this.send(this.pendingValue)}async send(e){this.busyValue=!0;try{const t=await this.transport.save(e.data,this.revisionValue,this.formatVersion,e.requestId);t.status==="saved"?(this.revisionValue=t.revision,this.pendingValue=null,this.retryableValue=!1,this.failureKindValue=null,this.unconfirmedValue=!1):t.status==="unconfirmed"?(this.retryableValue=!0,this.failureKindValue="NETWORK",this.unconfirmedValue=!0):(this.pendingValue=null,this.retryableValue=!1,this.failureKindValue=null,this.unconfirmedValue=!1)}catch(t){const i=ug(t);this.failureKindValue=i,this.unconfirmedValue=!1,i==="FORMAT"||i==="REQUEST_REUSED"?(this.lockedValue=!0,this.retryableValue=!1,this.pendingValue=null):i==="AUTH"?(this.authStoppedValue=!0,this.retryableValue=!1,this.pendingValue=null):i==="CONFLICT"?this.retryableValue=!0:this.retryableValue=!0}finally{this.busyValue=!1}}}function dC(n,e){return e==="guest"?{status:"guest",retryable:!1}:e==="unknown"||e==="unsupported"?{status:"unsupported",retryable:!1}:n.locked||e==="format"?{status:"format",retryable:!1}:n.conflict||e==="conflict"||n.failureKind==="CONFLICT"?{status:"conflict",retryable:n.retryable}:n.unconfirmed?{status:"syncing",retryable:n.retryable}:e==="error"||n.failureKind!==null?{status:"error",retryable:n.retryable}:{status:"ready",retryable:!1}}const hC=1e4;function fg(n){return n==="save-quit"?{title:"儲存失敗",description:"已停留在遊戲，請再試一次",keepInGame:!0,retryInMs:0}:{title:"本機存檔失敗",description:"稍後自動重試",keepInGame:!0,retryInMs:hC}}const rs=document.getElementById("game-canvas"),jn=document.getElementById("ui-root"),Be=Wy(rs),$e=Gn(),Ce=new HM,cl=new iE(Be.scene),pC=Xy(Be.scene,Mr),fc=$y(Be.scene),Vh=Zb(Be.scene),mC=PE(Be.scene),Gh=cE(Be.scene),gC=iA(Be.scene),ul=cA(Be.scene,$e.seed),qr=RA(Be.scene,Be.camera,Mr),Wh=NA(Be.scene);let yu=new wm($e.seed),Mu=0;const st=M1(rs,$e),mt=Cw(jn),ss=Bw(jn),xs=tR(jn),Ss=eR(jn),Wa=rR(jn,{onTakeOutput:vC,onSlotClick:xC,onClose:()=>{Ct("playing"),_r()}}),Xh=Hw(jn),qi=aR(jn),dg=cR(jn),Eu=fR(jn),It=YR();rs.addEventListener("pointerdown",()=>It.ensureStarted(),{once:!0});const Bt=r1();let Pt="title",le=rl(.5,90,.5),ln=Um(),Ye=$e.mode;st.setFlyEnabled(Ye==="creative");const At=Lm(Oi($e.mode),$e.mode),Ie=At.slots;let Ue=0,dc=!1,oi="first";function fl(){oi="first"}let qh;const Yr=new iw,$r=new dw;let Li=Fm(),bu=null,no=!1,Kr=di,Yh=qm(),Kh=qm();function hg(){Kr=di,Be.camera.fov=di,Be.camera.updateProjectionMatrix()}function Is(){Li=Fm(),bu=null,hg()}let pg=[],mg=[],gr=al();function jr(n){const e=ZR(gr,n);gr=e.state;for(const t of e.unlocked){const i=ng.find(r=>r.id===t);i&&qi.push({title:i.title,description:i.description,icon:i.icon})}e.unlocked.length>0&&pl()}function ys(n,e,t){if(At.mode!=="creative")return At.addItem(n,e,t);const i=Hi(n);let r=e;for(let s=0;s<Ie.length&&r>0;s++){const o=Ie[s];if(!o||o.item!==n||o.count>=i)continue;const a=Math.min(i-o.count,r);At.setSlot(s,{item:n,count:o.count+a,...t!==void 0?{dur:t}:{}}),r-=a}for(let s=0;s<Ie.length&&r>0;s++){if(Ie[s])continue;const o=Math.min(i,r);At.setSlot(s,{item:n,count:o,...t!==void 0?{dur:t}:{}}),r-=o}return r}function Xa(n,e){nR({grid:pg,excess:mg},n,{giveItem:ys,dropOverflow:e}),mt.setHotbar(Ie,Ue),Ss.isOpen()&&Ss.refresh(),xs.isOpen()&&xs.refreshCrafting()}function _C(n){!Number.isFinite(n.count)||n.count<1||(_t=mr(_t,n.item,n.count,le.position,{...n.dur!==void 0?{dur:n.dur}:{}}))}function dl(n){xs.close();const e=xs.returnCursor();e&&n&&n(e),Xa(Ss.isOpen()?3:2,n??(()=>{})),mg.length=0}function Zh(n){return{size:n,grid:pg,slots:Ie,selected:Ue,onSpend:(e,t)=>{const i=Ie[e];return!i||i.item!==t||!Number.isFinite(i.count)||i.count<1?!1:(At.setSlot(e,i.count>1?{item:i.item,count:i.count-1}:null),mt.setHotbar(Ie,Ue),!0)},onGiveBack:(e,t)=>{const i=ys(e,1,t);return mt.setHotbar(Ie,Ue),i},onTake:e=>At.fits(e.item,e.count)?(ys(e.item,e.count),mt.setHotbar(Ie,Ue),jr({type:"obtain",item:e.item,mode:Ye}),!0):!1}}const cn=new Map;let An=null;const gg=(n,e,t)=>`${n},${e},${t}`;function vC(){if(!An)return;const n=cn.get(An),e=n==null?void 0:n.output;if(!n||!e||!Number.isFinite(e.count)||e.count<1||!At.fits(e.item,e.count))return;ys(e.item,e.count);const t={...n,output:null};cn.set(An,t),mt.setHotbar(Ie,Ue),jr({type:"smelt-take",mode:Ye}),Wa.open(t)}function xC(n){if(!An)return;const e=cn.get(An);if(!e)return;const t=n==="input"?e.input:e.fuel;let i=null;if(t&&Number.isFinite(t.count)&&t.count>=1){if(ys(t.item,1,t.dur)>0)return;const r=t.count>1?{item:t.item,count:t.count-1}:null;i=n==="input"?{...e,input:r}:{...e,fuel:r}}else{const r=Ie[Ue];if(!r||!Number.isFinite(r.count)||r.count<1||!(n==="input"?r.item in Rm:r.item in Ba)||!At.spendFromSlot(Ue,1))return;const o={item:r.item,count:1};i=n==="input"?{...e,input:o}:{...e,fuel:o}}cn.set(An,i),mt.setHotbar(Ie,Ue),Wa.open(i)}function SC(n,e,t){var i;An=gg(n,e,t),cn.has(An)||cn.set(An,Cm()),Ct("furnace"),(i=document.exitPointerLock)==null||i.call(document)}function of(){let n=!1;for(const e of cn.values())if(e.input||e.fuel||e.output){n=!0;break}if(cn.clear(),n)try{qi.push({title:"熔爐進度已重置",description:"",icon:"furnace"})}catch{}}const $h=.6,yC=3.5;let Ni=0,Yn=null,_o=sl(),_t=[];function jh(n){const e=ow(n,Ce.getBlock(n.x,n.y,n.z)),t=Ie[Ue],i=t?Ju(t.item):null;i===null||!cw(Ce,e.x,e.y,e.z,le.position,i)||At.spendFromSlot(Ue,1)&&(Ce.setBlock(e.x,e.y,e.z,i),mt.setHotbar(Ie,Ue),It.play("place",wa(i),{pos:{x:e.x+.5,y:e.y+.5,z:e.z+.5}}))}function MC(){const n=Ie[Ue];return n!==null&&ol(n.item)!==null}function Jh(n){const e=Ie[Ue],t=gw(e,n,Ye);if(!e||t<=0||!At.spendFromSlot(Ue,t))return;const i=-Math.sin(le.yaw),r=-Math.cos(le.yaw);_t=mr(_t,e.item,t,{x:le.position.x+i*Th,y:le.position.y+H1,z:le.position.z+r*Th},{pickupDelay:B1,vel:{x:i*Ah,y:z1,z:r*Ah},dur:e.dur}),mt.setHotbar(Ie,Ue),Bt.emit("drops-changed",{})}function hc(n){if(Ye==="creative")return!1;const e=Ie[Ue];if(!e)return!1;const t=uA(e,n);return t.broke?(At.setSlot(Ue,null),It.play("tool_break","wood",{listener:le.position}),qi.push({title:"工具損壞",description:`${ui(e.item)} 壞掉了`,icon:e.item}),!0):(t.stack&&t.stack.dur!==e.dur&&At.setSlot(Ue,t.stack),!1)}let dt=[],os=[],pc=0,Dt=[],mc=0,tr=[],ma=0;const EC=.1,Au=.25;let Qh=null,ga=Au,gc=0;const bC=.25;let _c=0,Nt=Xu($e.dayLengthSec),io=pr(le.position.x,le.position.z,$e.seed),vc=0;const AC=.5;let hi=null,as="pending",Tu=!1,_g=Promise.resolve(),Er=!1,xc=0;const TC=30;let fo=0,Sc=!1,ep=0;const wC=2e3,Wn=uC(),it=new fC({transport:{save:(n,e,t,i)=>Wn.save(n,e,t,i)},formatVersion:nC});let Ms=!1,yc=0;const RC=60,CC="chest";function pi(n){try{qi.push({title:n,description:"",icon:CC})}catch{}}let qa=!1,Es=!1;function af(){Es=!1}function PC(n){za(n)&&(Es||(qa=!0))}function vg(){qa&&(qa=!1,!Es&&(Es=!0,tg(qi)))}const Jr=document.createElement("div");Jr.className="vitals";jn.appendChild(Jr);let Qe=null,ls=I1(),bs=Ps();function Xt(n){const e=Qe;if(Qe=n,!n){Nh(Jr,null),Jr.style.display="none";return}(!e||Math.floor(e.hp)!==Math.floor(n.hp)||Math.floor(e.hunger)!==Math.floor(n.hunger))&&(Nh(Jr,n),Jr.style.display="",Bt.emit("vitals-changed",{hp:n.hp,maxHp:n.maxHp,hunger:n.hunger,maxHunger:n.maxHunger}))}Xt(At.mode==="survival"?Sr():null);Bt.on("vitals-changed",({hp:n,maxHp:e,hunger:t,maxHunger:i})=>{Qe&&Xt({...Qe,hp:n,maxHp:e,hunger:t,maxHunger:i})});Bt.on("mode-changed",({mode:n})=>{ln=Om(ln,Ye,[...Ie],Qe),Ye=n,st.setFlyEnabled(Ye==="creative"),Is(),fl(),$e.mode=n,Gi({mode:n}),At.setMode(n),n==="creative"?(vu(ln,n).forEach((e,t)=>At.setSlot(t,e)),mt.setHotbar(Ie,Ue),Xt(null)):(vu(ln,n).forEach((e,t)=>At.setSlot(t,e)),mt.setHotbar(Ie,Ue),Xt({...ln.survivalVitals}))});function lf(){Be.setDayFogFar($e.renderDistance*j)}lf();Be.setShadowsEnabled($e.shadows);ul.setEnabled($e.clouds);It.setVolume($e.volume);const Fi=[],cs=[];let ur=[];const vo=new Set,ro=new Set;function*IC(){const n=j-1;for(let e=0;e<=n;e++){for(let t=0;t<=e;t++)yield[t,e];for(let t=0;t<e;t++)yield[e,t]}}function LC(n){for(const[e,t]of IC()){const i=xr(e,t,n);if(i>$n)return{x:e,z:t,h:i}}return null}function DC(){var a;if(((a=Ce.getChunk(0,0))==null?void 0:a.generated)!==!0){const l=new Wu(0,0,mu(0,0,$e.seed));l.generated=!0,l.dirty=!0,Ce.addChunk(l),Ce.reapplyModifiedInChunk(0,0),l.topY=em(l),Yu(Ce,0,0);for(let c=-2;c<=2;c++)for(let u=-2;u<=2;u++)Qp(Ce,u,c)}vo.add(Vn(0,0));const n=xr(.5,.5,$e.seed);let e=.5,t=.5,i=n+1;if(n<=$n){const l=LC($e.seed);l?(e=l.x+.5,t=l.z+.5,i=l.h+1):console.warn("[WeCraft] 出生點：區塊 (0,0) 整塊都在水裡 → 退回原本的高度公式（玩家可能出生在水裡）")}const r=Math.floor(e),s=Math.floor(t),o=l=>Ce.isSolid(r,Math.floor(l),s)||Ce.isSolid(r,Math.floor(l+.9),s)||Ce.isSolid(r,Math.floor(l+1.7),s);for(;i<ht-3&&o(i);)i++;return{x:e,y:i,z:t}}function NC(){const n=xb(dt,le.position,{lightAt:(e,t,i)=>tm(Ce,e,t,i,Nt.t),isSolidAt:(e,t,i)=>Ce.isSolid(e,t,i),blockIdAt:(e,t,i)=>Ce.getBlock(e,t,i)});n&&(dt=[...dt,n])}function tp(n,e=!1){var i;if(n.type==="shoot"){os=gb(os,n.from,n.dir,n.mobId);return}if(!Qe)return;const t=performance.now()/1e3;km(ls,t)&&(ls=Bm(ls,t),e?Yn="skeleton":Yn=((i=dt.find(s=>s.id===n.mobId))==null?void 0:i.kind)??"unknown",Xt(Pi(_u(Qe,n.amount),Nm)),dg.flash())}function np(n){if(Ye!=="survival")return!1;let e=!1;for(const t of Ym(n))_t=mr(_t,t.item,t.count,t.pos),e=!0;return e}function ip(n){if(Ye!=="survival")return!1;let e=!1;const t=n.map(i=>({kind:i.kind,pos:i.pos}));for(const i of Ym(t))_t=mr(_t,i.item,i.count,i.pos),e=!0;return e}function rp(){const n=Math.floor(le.position.x/j),e=Math.floor(le.position.z/j),t=$e.renderDistance,i=t+1;Fi.length=0,cs.length=0,ur.length=0;for(let r=-i;r<=i;r++)for(let s=-i;s<=i;s++){const o=n+s,a=e+r,l=Vn(o,a),c=Ce.getChunk(o,a);(c==null?void 0:c.generated)!==!0&&!vo.has(l)?Fi.push([o,a]):Math.abs(s)<=t&&Math.abs(r)<=t&&c&&(c.lightDirty&&ur.push([o,a]),c.dirty&&cs.push([o,a]))}Fi.sort((r,s)=>_a(r,n,e)-_a(s,n,e)),cs.sort((r,s)=>_a(r,n,e)-_a(s,n,e)),ur=NM(ur,n,e);for(const r of[...Ce.chunks.keys()]){const[s,o]=r.split(",").map(Number);if(Math.abs(s-n)>t+2||Math.abs(o-e)>t+2){if(s===0&&o===0)continue;cl.remove(s,o),Ce.removeChunk(s,o),vo.delete(r)}}}function _a([n,e],t,i){return(n-t)**2+(e-i)**2}function UC(n,e){var t,i,r,s;return((t=Ce.getChunk(n+1,e))==null?void 0:t.generated)===!0&&((i=Ce.getChunk(n-1,e))==null?void 0:i.generated)===!0&&((r=Ce.getChunk(n,e+1))==null?void 0:r.generated)===!0&&((s=Ce.getChunk(n,e-1))==null?void 0:s.generated)===!0}function sp(){let n=2;const e=2;let t=2;const i=DM(ur,e);ur.splice(0,i.length);for(const[r,s]of i){const o=Ce.getChunk(r,s);o!=null&&o.lightDirty&&Qp(Ce,r,s)}for(;n>0&&Fi.length>0;){const[r,s]=Fi[0],o=Vn(r,s);if(ro.has(o)){Fi.shift();continue}Fi.shift(),ro.add(o);const a=Mu;yu.request(r,s).then(l=>{if(ro.delete(o),a!==Mu)return;const c=new Uint8Array(l.buffer),u=Ce.getChunk(r,s);if(u){if(u.generated)return;u.data.set(c),u.generated=!0,u.dirty=!0}else{const f=new Wu(r,s,c);f.generated=!0,f.dirty=!0,Ce.addChunk(f)}vo.add(o),Ce.reapplyModifiedInChunk(r,s);const d=Ce.getChunk(r,s);d&&(d.topY=em(d),Yu(Ce,r,s))}).catch(()=>ro.delete(o)),n--}for(;t>0&&cs.length>0;){const[r,s]=cs.shift(),o=Ce.getChunk(r,s);o!=null&&o.dirty&&!o.lightDirty&&UC(r,s)&&(cl.rebuild(Ce,r,s),o.dirty=!1,t--)}}function _r(){var e;const n=(e=rs.requestPointerLock)==null?void 0:e.call(rs);n&&typeof n.catch=="function"&&n.catch(()=>{})}function Ct(n){var e,t;if(Pt==="playing"&&n!=="playing"&&(no=!1,hg(),Eu.hide(),$r.reset()),Pt=n,ss.hideAll(),xs.close(),Ss.close(),Wa.close(),Xh.hide(),n==="title")ss.showTitle({saveState:as,statusText:Tu?"檢查進度中…":as==="pending"?"正在檢查雲端進度…":void 0,onContinue:YC,onNewGame:qC}),(e=document.exitPointerLock)==null||e.call(document);else if(n==="paused")ss.showPause({onResume:()=>{const i=$e.renderDistance;Object.assign($e,Gn()),It.setVolume($e.volume),$e.renderDistance!==i&&lf(),Ct("playing")},onQuit:Ka,onSaveQuit:OC,onToggleMode:()=>{const i=Ye==="survival"?"creative":"survival";Bt.emit("mode-changed",{mode:i})},onToggleShadows:()=>{const i=!Gn().shadows;$e.shadows=i,Gi({shadows:i}),Be.setShadowsEnabled(i)},onToggleClouds:()=>{const i=!Gn().clouds;$e.clouds=i,Gi({clouds:i}),ul.setEnabled(i)},...GC()});else if(n==="dead")Xh.show({onRespawn:KC,onQuit:ZC,cause:zw(Yn)}),(t=document.exitPointerLock)==null||t.call(document),Bt.emit("player-died",{});else if(n==="inventory")Xa(2),xs.open(Ie,Ue,(i,r)=>{At.setSlot(i,r),mt.setHotbar(Ie,Ue)},()=>{Ct("playing"),_r()},Ye==="survival"?Zh(2):void 0,Ye,{onSlotChange:(i,r)=>{At.setSlot(i,r),mt.setHotbar(Ie,Ue)},onReturnCursor:i=>{const r=ys(i.item,i.count,i.dur);return mt.setHotbar(Ie,Ue),r>0?{item:i.item,count:r,...i.dur!==void 0?{dur:i.dur}:{}}:null}});else if(n==="crafting")Xa(3),Ss.open({...Zh(3),sourceCount:Vi,onClose:()=>{Ct("playing"),_r()}});else if(n==="furnace"&&An){let i=cn.get(An);i||(i=Cm(),cn.set(An,i)),Wa.open(i)}}function cf(){const n=DC();le=rl(n.x,n.y,n.z),Yn=null,_o=sl(),Ni=0}function xg(){ln=Om(ln,Ye,Ie,Qe)}function hl(){return Xa(Ss.isOpen()?3:2),Qe&&Qe.hp<=0?null:(xg(),jR({world:{seed:$e.seed,serializeModified:()=>Ce.serializeModified()},player:{pos:[le.position.x,le.position.y,le.position.z],yaw:le.yaw,mode:Ye,inventory:[...Ie]},vitals:Qe,clockT:Nt.t,advancements:gr,stash:ln,passiveMobs:Dt}))}function OC(){ss.hideAll();const n=hl();if(!n){Ka();return}ll(n).then(()=>{hi=n,pl(),Ka()},FC)}function FC(){const n=fg("save-quit");qi.push({title:n.title,description:n.description,icon:"chest"}),Ct("paused")}function wu(){const n=hl();n&&ll(n).then(()=>{hi=n,fo=0,Sc=!1}).catch(()=>{const e=fg("autosave");Sc||(Sc=!0,qi.push({title:e.title,description:e.description,icon:"chest"})),fo=Date.now()+e.retryInMs})}function Sg(n){dl(),Gi({seed:n.seed,...n.settings});const e=$e.renderDistance;Object.assign($e,Gn()),It.setVolume($e.volume),$e.renderDistance!==e&&lf(),Be.setShadowsEnabled($e.shadows),ul.setEnabled($e.clouds),Mu+=1,yu.dispose(),yu=new wm($e.seed),yg(),uf(),Dt=jm($m(n.passiveMobs,za(n.worldgenVersion))),le=rl(n.pos[0],n.pos[1],n.pos[2]),le.yaw=n.yaw,_o=sl(),Ni=0,Yn=null,io=pr(le.position.x,le.position.z,$e.seed),Ye=n.settings.mode,st.setFlyEnabled(Ye==="creative"),At.setMode(Ye);const t=fi(n.inventory,Ie.length);for(let i=0;i<Ie.length;i++)At.setSlot(i,t[i]);mt.setHotbar(Ie,Ue),Xt(Ye==="survival"?n.vitals?{...n.vitals}:Sr():null),ln=il(n.stash,{mode:n.settings.mode,inventory:n.inventory,vitals:n.vitals}),gr=n.advancements,Nt=Xu($e.dayLengthSec),Nt.t=n.clockT,It.setPhase(hr(Nt.t)),PC(n.worldgenVersion)}async function pl(n){try{if(!oC({revision:it.revision})||it.revision===null||it.locked||it.authStopped)return;xg();const e=rC({seed:$e.seed,pos:[le.position.x,le.position.y,le.position.z],yaw:le.yaw,vitals:Qe?{...Qe}:null,clockT:Nt.t,inventory:[...Ie],advancements:gr,settings:$e,stash:ln,passiveMobs:Dt});if(lg(e)>ag){pi("雲端空間不足，僅本機存檔");return}await Ya(()=>it.checkpoint(e))}catch{}}async function Ya(n){await n();const e=it.failureKind;if(e==="CONFLICT"){await zC();return}e==="FORMAT"?pi("雲端格式不相容，僅本機存檔"):e==="REQUEST_REUSED"?pi("雲端同步失敗，僅本機存檔"):e==="AUTH"&&pi("請重新登入")}async function kC(){await Ya(()=>it.retry())}function Mc(){Pt==="paused"&&!it.conflict&&Ct("paused")}function BC(){var n;Pt==="playing"&&((n=document.exitPointerLock)==null||n.call(document),Pt==="playing"&&Ct("paused"))}async function zC(){try{const n=await Wn.load();if(n&&!rf(n.formatVersion)){it.lock("FORMAT"),pi("雲端格式不相容，僅本機存檔");return}const e=n?sf(n.data):null;if(!n||!e){it.markReadFailure();return}it.setConflict({data:e,revision:n.revision}),BC(),pi("雲端有其他裝置的進度，請選擇處理方式"),ss.showConflictChoice({message:"雲端有其他裝置的進度，要保留本機、採用雲端，還是合併？",onKeepLocal:()=>{Ya(()=>it.resolveConflict("keep-local")).finally(Mc)},onTakeCloud:()=>{(async()=>(await it.resolveConflict("take-cloud"),Sg(e),vg(),pi("已採用雲端進度"),Mc()))()},onMerge:()=>{Ya(()=>it.resolveConflict("merge")).finally(Mc)}})}catch{it.markReadFailure()}}async function HC(){if(!(Wn.status==="guest"||Wn.status==="unsupported"))try{const n=await Wn.load();if(!n){it.setRevision(0),it.clearReadFailure();return}if(!rf(n.formatVersion)){it.lock("FORMAT");return}if(!sf(n.data)){it.markReadFailure();return}it.setRevision(n.revision),it.clearReadFailure()}catch{it.markReadFailure()}}function VC(){if(it.busy)return;if(it.revision===null&&!it.locked&&!it.authStopped){HC().finally(()=>{Pt==="paused"&&Ct("paused")});return}(it.pending?kC():pl()).finally(()=>{Pt==="paused"&&Ct("paused")})}function GC(){const n=dC(it,Wn.status);return{cloudStatus:n.status,cloudRetryable:n.retryable,onRetryCloud:VC}}function Ka(){It.stopAmbience(),Er=!1,dl(_C),cf(),Is(),Ct("title")}function uf(){dt=[],Dt=[],_t=[],os=[]}function yg(){for(const n of[...Ce.chunks.keys()]){const[e,t]=n.split(",").map(Number);cl.remove(e,t)}Ce.clear(),vo.clear(),ro.clear(),Fi.length=0,cs.length=0,ur.length=0,uf(),of(),bs=Ps(),$r.reset()}function xo(){dl(),yg(),ln=Um();const n=vu(ln,Ye);for(let e=0;e<Ie.length;e++)At.setSlot(e,n[e]??null);Ue=0,mt.setHotbar(Ie,Ue),Xt(Ye==="survival"?{...ln.survivalVitals}:null),Nt=Xu($e.dayLengthSec),It.ensureStarted(),It.startAmbience(),It.setPhase(hr(Nt.t)),gr=al(),Yn=null,bs=Ps(),Is(),fl(),Ms=!1,af(),qa=!1,Er=!0,cf(),Ct("playing"),_r()}function WC(n){dl(),Ce.applyModified(n.modified),uf(),Dt=jm($m(n.passiveMobs,za(n.worldgenVersion))),of();const[e,t,i]=n.player.pos;le=rl(e,t,i),le.yaw=n.player.yaw,_o=sl(),Ni=0,Yn=null,bs=Ps(),Ye=n.player.mode,st.setFlyEnabled(Ye==="creative"),$e.mode=Ye,Gi({mode:Ye}),At.setMode(Ye),ln=il(n.stash,{mode:n.player.mode,inventory:n.player.inventory,vitals:n.player.vitals});const r=fi(n.player.inventory,Ie.length);for(let s=0;s<Ie.length;s++){const o=r[s];At.setSlot(s,o?{...o}:null)}if(mt.setHotbar(Ie,Ue),Xt(Ye==="survival"?n.player.vitals?{...n.player.vitals}:Sr():null),gr=n.advancements,Nt.t=n.time.t,Is(),fl(),It.ensureStarted(),It.startAmbience(),It.setPhase(hr(Nt.t)),Ms=!1,af(),Er=!0,za(n.worldgenVersion)){Es||(Es=!0,tg(qi));const s=hl();if(s){const o={...s,worldgenVersion:nl};ll(o).then(()=>{hi=o},()=>{})}}Ct("playing"),_r()}function XC(){Ms=!1,af(),Is(),fl(),bs=Ps(),It.ensureStarted(),It.startAmbience(),It.setPhase(hr(Nt.t)),vg(),Er=!0,Ct("playing"),_r()}function Ec(){ss.showConfirm({message:"將覆蓋現有進度。確定要開始新遊戲嗎？",onConfirm:xo,onCancel:()=>Ct("title")})}function qC(){if(as!=="pending"){as==="yes"?Ec():xo();return}if(hi!==null){Ec();return}Tu=!0,Pt==="title"&&Ct("title"),_g.then(()=>{Tu=!1,Pt==="title"&&(as==="yes"?Ec():xo())})}function YC(){const n=Im({hasLocalSave:hi!==null,cloudApplied:Ms});if(n==="cloud"){XC();return}if(n==="local"&&hi){try{WC(hi)}catch(e){console.warn("[WeCraft] Continue failed — falling back to a new game",e),xo()}return}xo()}function KC(){Xt(Sr()),cf(),of(),Ct("playing"),_r()}function ZC(){Qe&&Xt(Sr()),Ka()}st.onLockChange(n=>{n||Pt==="playing"&&Ct("paused")});document.addEventListener("pointerlockerror",()=>{Pt==="playing"&&!st.locked&&Ct("paused")});document.addEventListener("visibilitychange",()=>{if(It.handleVisibility(document.visibilityState==="hidden"),document.visibilityState!=="hidden"||!Er)return;const n=Date.now();n-ep<wC||(ep=n,wu())});window.addEventListener("beforeunload",()=>{if(!Er)return;const n=hl();n&&ll(n).catch(()=>{})});st.setMouseMoveHandler((n,e)=>{le.yaw-=n,le.pitch-=e;const t=Math.PI/2-.01;le.pitch=Math.max(-t,Math.min(t,le.pitch))});let op=performance.now(),ap=60,va=0,bc=0;function ff(){const n=document.documentElement.clientWidth||window.innerWidth,e=document.documentElement.clientHeight||window.innerHeight;!Number.isFinite(n)||!Number.isFinite(e)||n<=0||e<=0||(Be.setSize(n,e),Be.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)))}window.addEventListener("resize",ff);typeof ResizeObserver<"u"&&new ResizeObserver(()=>ff()).observe(document.documentElement);var lp;(lp=window.visualViewport)==null||lp.addEventListener("resize",ff);mt.setHotbar(Ie,Ue);window.__wecraft={sprint:()=>Li.active,fov:()=>Be.camera.fov,hunger:()=>Qe?Qe.hunger:null,pos:()=>({x:le.position.x,y:le.position.y,z:le.position.z}),hotbar:()=>Ie.map(n=>n?{item:n.item,count:n.count,...n.dur!==void 0?{dur:n.dur}:{}}:null),drops:()=>_t.length,modified:()=>Ce.modified.size,viewMode:()=>oi,mobs:()=>dt.length,passiveMobs:()=>Dt.length,clock:()=>Nt.t,passiveMobPositions:()=>Dt.map(n=>({x:n.pos.x,y:n.pos.y,z:n.pos.z})),passiveMobStates:()=>Dt.map(n=>({id:n.id,kind:n.kind,x:n.pos.x,y:n.pos.y,z:n.pos.z,hp:n.hp})),mobStates:()=>dt.map(n=>({id:n.id,kind:n.kind,x:n.pos.x,y:n.pos.y,z:n.pos.z,hp:n.hp,burn:n.burn})),vitalsState:()=>Qe?{hp:Qe.hp,maxHp:Qe.maxHp,hunger:Qe.hunger,maxHunger:Qe.maxHunger,saturation:Qe.saturation}:null};async function $C(){try{hi=await tC()}catch{}try{await Wn.init()}catch{}if(Wn.status!=="guest"&&Wn.status!=="unsupported")try{const n=await Wn.load();if(!n)it.setRevision(0);else if(!rf(n.formatVersion))it.setRevision(null),it.lock("FORMAT");else{const e=sf(n.data);e?(Pt==="title"&&!Er&&(Sg(e),Ms=!0),it.setRevision(n.revision)):(it.markReadFailure(),pi("雲端讀取失敗，本機繼續"))}}catch{it.markReadFailure(),pi("雲端讀取失敗，本機繼續")}else it.setRevision(null);as=Im({hasLocalSave:hi!==null,cloudApplied:Ms})!=="none"?"yes":"no",Pt==="title"&&Ct("title")}Ct("title");_g=$C();Be.renderer.setAnimationLoop(()=>{var r,s,o,a,l,c;const n=performance.now();let e=(n-op)/1e3;if(e=Math.min(.1,Math.max(0,e)),op=n,va+=e,bc++,va>=.5&&(ap=Math.round(bc/va),va=0,bc=0),Pt==="playing"){const u=hr(Nt.t);Nt=AM(Nt,e);const d=hr(Nt.t);vc+=e,vc>=AC&&(vc=0,io=pr(le.position.x,le.position.z,$e.seed));const f=TM(Nt.t),h=wM(Nt.t),g={...h,fog:Fh(h.fog,io),sky:Fh(h.sky,io)};Be.setDayNight(f,g),gC.setSky(f,{zenith:h.zenith,horizon:h.sky},Be.camera.position),cl.setSkyScale(OM(Nt.t)),d!==u&&(Bt.emit("time-changed",{phase:d,t:Nt.t}),jr({type:"phase",phase:d}),It.setPhase(d)),Li=y1(Li,{forward:st.state.fwd>0,sneak:st.state.sneak,ctrlHeld:st.state.sprint,sprintRequested:st.consumeSprintToggle(),hunger:Qe?Qe.hunger:null,flying:le.flying,inWater:le.inWater,wallAngleDeg:bu,attacked:no}),no=!1;const _=st.state.jump&&le.onGround&&!le.flying&&!le.inWater,m=le.position.y,p=le.position.x,E=le.position.z,S={fwd:st.state.fwd,strafe:st.state.strafe,jump:st.state.jump,sneak:st.state.sneak,sprint:Li.active,fly:st.state.fly,flyUp:st.state.flyUp,flyDown:st.state.flyDown};bu=p1(le,S,Ce,e).wallAngleDeg;const C=O1(_o,m,le.position.y,le.onGround,le.flying,le.inWater);if(_o=C.fall,C.distance!==null&&Ye==="survival"&&Qe){const I=i1(C.distance);I>0&&(Yn="fall",Xt(_u(Qe,I)))}const R=U1(bs,N1(Ce,le.position,li,Qu),e);if(bs=R.state,R.damage>0&&Qe){const I=performance.now()/1e3;km(ls,I)&&(ls=Bm(ls,I),Yn="cactus",Xt(Pi(_u(Qe,R.damage),Nm)),dg.flash())}const A=Math.hypot(le.velocity.x,le.velocity.z);if(le.onGround&&!le.flying&&!le.inWater&&A>.5&&(_c+=e,_c>=MR(A))){_c=0;const I=Ce.getBlock(Math.floor(le.position.x),Math.floor(le.position.y-.05),Math.floor(le.position.z));It.play("step",wa(I),{pos:le.position,listener:le.position})}const P=_t.length;if(_t=Z1(_t,e,(I,Z,Q)=>Ce.isSolid(I,Z,Q)),_t.length!==P&&Bt.emit("drops-changed",{}),Ye!=="creative"){const I=$1(_t,le.position);let Z=!1;const Q=[];for(let se=I.length-1;se>=0;se--){const Me=I[se],Je=(r=_t[Me])==null?void 0:r.item,K=((s=_t[Me])==null?void 0:s.count)??0,re=j1(_t,Me,At);_t=re.drops,Je&&re.overflow<K&&(Z=!0,Q.push(Je))}Z&&(mt.setHotbar(Ie,Ue),Bt.emit("drops-changed",{}));for(const se of Q)jr({type:"obtain",item:se,mode:Ye})}tr=CE(tr,e,(I,Z,Q)=>Ce.isSolid(I,Z,Q));for(const[I,Z]of cn){const Q=YT(Z,e);Q.state!==Z&&cn.set(I,Q.state)}const x=dt.length,v=(I,Z,Q)=>Ce.isSolid(I,Z,Q),w=(I,Z,Q)=>Ce.getBlock(I,Z,Q)===O.WATER,k=pb(dt,{playerPos:le.position,isSolidAt:v,dt:e});dt=k.mobs;for(const I of k.events)tp(I);const B={isDaylight:DE(Nt.t),isSolidAt:v,isWaterAt:w,dt:e};dt=dt.map(I=>mb(I,B));const X=vb(os,e,v,le.position);os=X.arrows;for(const I of X.events)tp(I,!0);const J=dt.filter(I=>oa(I)),H=J.length>0&&np(J);dt=dt.filter(I=>!oa(I)&&fb(I.pos,le.position)<=sb),dt.length!==x&&Bt.emit("mobs-changed",{count:dt.length}),H&&Bt.emit("drops-changed",{}),Dt=Cb(Dt,{playerPos:le.position,isSolidAt:v,isWaterAt:w,dt:e});const te=Dt.filter(I=>aa(I));if(te.length>0&&(Dt=Dt.filter(I=>!aa(I)),ip(te)&&Bt.emit("drops-changed",{})),Qe){let I=Qe;const Z=I.hp,Q=st.state.fwd!==0||st.state.strafe!==0;if(Li.active&&Q&&!le.flying&&!le.inWater){const se=Math.hypot(le.position.x-p,le.position.z-E);I=Pi(I,se*$T)}_&&(I=Pi(I,Li.active&&Q?JT:jT)),I=t1(I,e),I.hp<Z&&I.hunger<=0&&(Yn="starve"),Xt(I),n1(I)&&Pt==="playing"&&(Is(),Ct("dead"))}if(Pt==="playing"){if(pc+=e,pc>=nb){pc=0;const T=dt.length;NC(),dt.length!==T&&Bt.emit("mobs-changed",{count:dt.length})}mc+=e,mc>=Lb&&(mc=0,Dt=Fb(Dt,le.position,{lightAt:(T,M,F)=>tm(Ce,T,M,F,Nt.t),isSolidAt:(T,M,F)=>Ce.isSolid(T,M,F),blockIdAt:(T,M,F)=>Ce.getBlock(T,M,F)})),xc+=e,xc>=TC&&(xc=0,wu()),fo!==0&&Date.now()>=fo&&(fo=0,wu()),yc+=e,yc>=RC&&(yc=0,pl());const I={x:le.position.x,y:le.position.y+s1,z:le.position.z},Z=C1(oi,I,le.yaw,le.pitch);Be.camera.position.set(Z.pos.x,Z.pos.y,Z.pos.z),Be.camera.rotation.order="YXZ",Be.camera.rotation.y=Z.yaw,Be.camera.rotation.x=Z.pitch,Be.camera.rotation.z=0;const Q=Li.active?A1(di):di,se=T1(Kr,Q,e);Number.isFinite(se)&&se>0?(Kr=se,Math.abs(Be.camera.fov-Kr)>.01&&(Be.camera.fov=Kr,Be.camera.updateProjectionMatrix())):Kr=di;const Me={x:-Math.sin(Z.yaw)*Math.cos(Z.pitch),y:Math.sin(Z.pitch),z:-Math.cos(Z.yaw)*Math.cos(Z.pitch)},Je={x:Be.camera.position.x,y:Be.camera.position.y,z:Be.camera.position.z},K=oi==="first"?0:xu,re=Mb(Ye)+K,ne=Eb(Ce,Je,Me,re,{skipOriginBlock:oi!=="first"}),ce=yC+K;Ni=Math.max(0,Ni-e);let Re=!1;if(st.state.dig)if(Ni>0)Re=Gm(dt,Je,Me,ce)!==null||hm(Dt,Je,Me,ce)!==null;else{const T=Ie[Ue],M=ew((T==null?void 0:T.item)??null),F=nw(dt,Je,Me,ce,M,Me);if(qr.startSwing(),F.hitId!==null){Re=!0,dt=F.mobs,Ni=$h,fc.flashMob(F.hitId),no=!0,Qe&&Xt(Pi(Qe,yh)),hc(1),mt.setHotbar(Ie,Ue);const Y=dt.length,$=dt.filter(q=>oa(q));dt=dt.filter(q=>!oa(q)),dt.length!==Y&&(Bt.emit("mobs-changed",{count:dt.length}),jr({type:"mob-killed",mode:Ye}),np($)&&Bt.emit("drops-changed",{}))}else{const Y=Pb(Dt,Je,Me,ce,M,Me);if(Y.hitId!==null){Re=!0,Dt=Y.mobs,Ni=$h,Vh.flashPassiveMob(Y.hitId),no=!0,Qe&&Xt(Pi(Qe,yh)),hc(1),mt.setHotbar(Ie,Ue);const $=Dt.filter(q=>aa(q));$.length>0&&(Dt=Dt.filter(q=>!aa(q)),ip($)&&Bt.emit("drops-changed",{}))}}}const De=Yr.progress;let ye=null;if(ne&&st.state.dig&&!Re){const T=Ce.getBlock(ne.x,ne.y,ne.z),M=Ie[Ue];if(Number.isFinite(Vm(T,M))&&(ye=ne),rw(Ye,Yr,T,ne,e,M)){Ce.setBlock(ne.x,ne.y,ne.z,O.AIR);const F=wh(_t,Ye,T,{x:ne.x+.5,y:ne.y+.5,z:ne.z+.5},M);F.length!==_t.length&&Bt.emit("drops-changed",{}),_t=F;for(const Y of zM(Ce,ne.x,ne.y,ne.z)){const $=wh(_t,Ye,O.TORCH,{x:Y.x+.5,y:Y.y+.5,z:Y.z+.5},M);$.length!==_t.length&&Bt.emit("drops-changed",{}),_t=$}if(Qe&&Xt(Pi(Qe,QT)),hc(1),mt.setHotbar(Ie,Ue),T===O.FURNACE){const Y=gg(ne.x,ne.y,ne.z),$=cn.get(Y);if($){cn.delete(Y);let q=!1;for(const ve of[$.input,$.fuel,$.output])!ve||!Number.isFinite(ve.count)||ve.count<1||(_t=mr(_t,ve.item,ve.count,{x:ne.x+.5,y:ne.y+.5,z:ne.z+.5},{dur:ve.dur}),q=!0);q&&Bt.emit("drops-changed",{})}}tr=wE(tr,T,{x:ne.x+.5,y:ne.y+.5,z:ne.z+.5}),qr.startSwing(),It.play("break",wa(T),{pos:{x:ne.x+.5,y:ne.y+.5,z:ne.z+.5},listener:le.position}),Yr.reset(),ye=null}}else Yr.reset();if(ye){if(ma+=e,ma>=EC){ma=0;const T=Ce.getBlock(ye.x,ye.y,ye.z);tr=RE(tr,T,{x:ye.x+.5+ye.nx,y:ye.y+.5+ye.ny,z:ye.z+.5+ye.nz})}}else ma=0;if(ye&&Yr.progress>De&&(gc+=e,gc>=bC)){gc=0;const T=Ce.getBlock(ye.x,ye.y,ye.z);It.play("dig",wa(T),{pos:{x:ye.x+.5,y:ye.y+.5,z:ye.z+.5},listener:le.position})}if(Gh.set(ye,Yr.progress),ye?(ga+=e,ga>=Au&&(ga=0,qr.startSwing())):ga=Au,st.consumePlace()){const T=ne?Ce.getBlock(ne.x,ne.y,ne.z):null;Ye==="survival"&&ne&&T===O.CRAFTING_TABLE?(Ct("crafting"),(o=document.exitPointerLock)==null||o.call(document)):ne&&T===O.FURNACE?SC(ne.x,ne.y,ne.z):Ye==="survival"&&Qe!==null&&MC()?$r.reset():ne&&(qr.startSwing(),jh(ne))}const Ke=Ch(Yh,st.state.placeHeld,e,pw);Yh=Ke.state,Ke.fired&&ne&&jh(ne);const yt=Ie[Ue],D=yt?yt.item:null,Ot=Ye==="survival"?Qe:null,Ze=Ot!==null&&D!==null&&uw(Ot,D),ze=hw($r,{held:st.state.placeHeld,item:D,allowed:Ze,dtSec:e});if(ze==="eating"&&$r.elapsed>0?Eu.show($r.elapsed/Xm):Eu.hide(),ze==="eaten"&&Ot!==null&&D!==null){const T=ol(D),M=fw(Ie,Ue);M.ate&&T!==null&&(At.setSlot(Ue,M.slots[Ue]??null),Xt(ZT(Ot,T.food,T.saturation)),mt.setHotbar(Ie,Ue),It.play("place","grass",{pos:le.position}),jr({type:"ate",item:D,mode:Ye}))}const Te=st.consumeDrop();Te&&Jh(Te.wholeStack);const ct=Ch(Kh,st.state.dropHeld,e,mw);Kh=ct.state,ct.fired&&Jh(st.state.sprint),st.consumeToggleDebug()&&(dc=!dc),st.consumeToggleView()&&(oi=R1(oi)),st.consumeToggleInventory()&&(Ct("inventory"),(a=document.exitPointerLock)==null||a.call(document)),st.consumeRequestPause()&&Pt==="playing"&&(Ct("paused"),(l=document.exitPointerLock)==null||l.call(document));const Pe=st.state.slot;if(Pe!==Ue){Ue=Pe,mt.setSelected(Ue);const T=Ie[Ue];mt.showItemName(T?ui(T.item):null),clearTimeout(qh),qh=setTimeout(()=>mt.showItemName(null),1200)}if(dc){const T=le.position;mt.setDebug(Rw({fps:ap,x:T.x,y:T.y,z:T.z,chunks:Ce.chunks.size,seed:$e.seed,biome:io,mode:Ye,flying:le.flying,triangles:Be.renderer.info.render.triangles}))}else mt.setDebug(null);rp(),sp()}}else if(Pt==="title"){mt.setDebug(null);const u=n/1e3;Be.camera.position.set(.5+Math.cos(u*.1)*24,96,.5+Math.sin(u*.1)*24),Be.camera.lookAt(.5,82,.5),rp(),sp()}else mt.setDebug(null);const t=Be.camera.position;Be.setUnderwater(Ce.getBlock(Math.floor(t.x),Math.floor(t.y),Math.floor(t.z))===O.WATER),Be.setSunFocus(t.x,t.z),ul.update(t.x,t.z,n/1e3);const i=((c=Ie[Ue])==null?void 0:c.item)??null;i!==Qh&&(Qh=i,qr.setItem(i)),qr.update(Pt==="playing"?e:0,Pt==="playing"&&oi==="first",Math.hypot(le.velocity.x,le.velocity.z)),Wh.setPose(le.position,le.yaw),Wh.setVisible(Pt==="playing"&&oi!=="first"),pC.syncDrops(_t),mC.sync(tr,Be.camera),fc.syncMobs(dt,Pt==="playing"?e:0),fc.syncArrows(os),Vh.syncPassiveMobs(Dt,Pt==="playing"?e:0),Pt!=="playing"&&Gh.set(null,0),Be.renderer.render(Be.scene,Be.camera)});
